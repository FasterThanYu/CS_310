// CHANGELOG: 

// Tests for HW3.

/* To run them on the command line, make sure that the junit-310.jar
   is in the project directory.
 
   demo$ javac -cp .:junit-cs310.jar *.java     # compile everything
   demo$ java  -cp .:junit-cs310.jar HW3Tests   # run tests
 
   On Windows replace : with ; (colon with semicolon)
   demo$ javac -cp .;junit-cs310.jar *.java     # compile everything
   demo$ java  -cp .;junit-cs310.jar HW3Tests   # run tests
*/

import org.junit.*;
import org.junit.Test; // fixes some compile problems with annotations
import static org.junit.Assert.*;
import java.util.*;
import java.io.*;

public class HW3Tests {
  public static void main(String args[]){
    org.junit.runner.JUnitCore.main("HW3Tests");
  }
  

  ////////////////////////////////////////////////////////////////////////////////
  // NEW TESTS Day Nov XX 00:00:0 EDT 2015 
  // @Test(timeout=1000,expected=SomeException.class)


// test ArrayNode.insertedSorted

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_insertSorted1(){
  // Check insert in sorted order: insert 1 into []
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,1);
  n.insertSorted(new Integer(1));
  Object[] actual = n.getArray();
  Object[] expect = {1};
    if(!Arrays.deepEquals(actual,expect)){
       failFmt("insertSorted:\n"+
               "Expect: "+printArray(expect) +"\n"+
               "Actual: "+printArray(actual)+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_insertSorted2(){
  // Check insert in sorted order: insert 4 into [2]
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(2));
  n.insertSorted(new Integer(4));
  Object[] actual = n.getArray();
  Object[] expect = {2,4};
    if(!Arrays.deepEquals(actual,expect)){
       failFmt("insertSorted:\n"+
               "Expect: "+printArray(expect) +"\n"+
               "Actual: "+printArray(actual)+"\n"+"");
    }

  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_insertSorted3(){
  // Check insert in sorted order: insert 1 into [2,4]
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,3);
  n.insertSorted(new Integer(2));
  n.insertSorted(new Integer(4));
  n.insertSorted(new Integer(1));
  Object[] actual = n.getArray();
  Object[] expect = {1,2,4};
    if(!Arrays.deepEquals(actual,expect)){
       failFmt("insertSorted:\n"+
               "Expect: "+printArray(expect) +"\n"+
               "Actual: "+printArray(actual)+"\n"+"");
    }

  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_insertSorted4(){
  // Check insert in sorted order: insert 3 into [1,2,4]
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,4);
  n.insertSorted(new Integer(2));
  n.insertSorted(new Integer(4));
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(3));
  Object[] actual = n.getArray();
  Object[] expect = {1,2,3,4};
    if(!Arrays.deepEquals(actual,expect)){
       failFmt("insertSorted:\n"+
               "Expect: "+printArray(expect) +"\n"+
               "Actual: "+printArray(actual)+"\n"+"");
    }

  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_insertSorted5(){
  // Check insert in sorted order: insert 5 into [1,2,3,4]
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,5);
  n.insertSorted(new Integer(2));
  n.insertSorted(new Integer(4));
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(3));
  n.insertSorted(new Integer(5));
  Object[] actual = n.getArray();
  Object[] expect = {1,2,3,4,5};
    if(!Arrays.deepEquals(actual,expect)){
       failFmt("insertSorted:\n"+
               "Expect: "+printArray(expect) +"\n"+
               "Actual: "+printArray(actual)+"\n"+"");
    }

  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_insertSorted6(){
  // Check insert in sorted order: array capcity > size
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,10);
  n.insertSorted(new Integer(2));
  n.insertSorted(new Integer(4));
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(3));
  n.insertSorted(new Integer(5));
  Object[] actual = n.getArray();
  Object[] expect = {1,2,3,4,5,null,null,null,null,null};
    if(!Arrays.deepEquals(actual,expect)){
       failFmt("insertSorted:\n"+
               "Expect: "+printArray(expect) +"\n"+
               "Actual: "+printArray(actual)+"\n"+"");
    }

  }

// Test getArraySize

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_getArraySize1(){
  // Check getArraySize: on []
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  int actual = n.getArraySize();
  int expect = 0;
    if(actual != expect) {
       failFmt("getArraySize:\n"+
               "Expect: "+expect +"\n"+
               "Actual: "+actual+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_getArraySize2(){
  // Check getArraySize: on [1]
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(1));
  int actual = n.getArraySize();
  int expect = 1;
    if(actual != expect) {
       failFmt("getArraySize:\n"+
               "Expect: "+expect +"\n"+
               "Actual: "+actual+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_getArraySize3(){
  // Check getArraySize: on [1,2]
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,3);
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(2));
  int actual = n.getArraySize();
  int expect = 2;
    if(actual != expect) {
       failFmt("getArraySize:\n"+
               "Expect: "+expect +"\n"+
               "Actual: "+actual+"\n"+"");
    }
  }


// Test ArrayNode.IndexOf

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_indexOf1(){
  // Check indexOf: index of 1 in [1]
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,1);
  n.insertSorted(new Integer(1));
  int actual = n.indexOf(1);
  int expect = 0;
    if(n.indexOf(1) != expect) {
       failFmt("indexOf:\n"+
               "Expect: "+expect +"\n"+
               "Actual: "+actual+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_indexOf2(){
  // Check indexOf: index of 2 in [1,2]; capacity of array > size of array
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(2));
  int actual = n.indexOf(2);
  int expect = 1;
    if(actual != expect) {
       failFmt("indexOf:\n"+
               "Expect: "+expect +"\n"+
               "Actual: "+actual+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_indexOf3(){
  // Check indexOf: index of 0 in [1,2]; capacity of array > size of array
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,3);
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(2));
  int actual = n.indexOf(0);
  int expect = -1; 
  if(actual != expect) {
       failFmt("indexOf:\n"+
               "Expect: "+expect +"\n"+
               "Actual: "+actual+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_indexOf4(){
  // Check indexOf: index of 3 in [1,2]; capacity of array > size of array
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,3);
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(2));
  int actual = n.indexOf(0);
  int expect = -1; 
  if(actual != expect) {
       failFmt("indexOf:\n"+
               "Expect: "+expect +"\n"+
               "Actual: "+actual+"\n"+"");
    }
  }

// test ArrayNode.getFirst

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_getFirst1(){
  // Check getFirst: getFirst of [1,2];
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(2));
  Comparable actual = n.getFirst();
  Integer expect = 1;
  if(actual.compareTo(expect)!= 0) {
       failFmt("getFirst:\n"+
               "Expect: "+expect +"\n"+
               "Actual: "+actual+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_getFirst2(){
  // Check getFirst: getFirst of [1]; capacity of array > size of array
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(1));
  Comparable actual = n.getFirst();
  Integer expect = 1; 
  if(actual.compareTo(expect)!= 0) {
       failFmt("getFirst:\n"+
               "Expect: "+expect +"\n"+
               "Actual: "+actual+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_getFirst3(){
  // Check getFirst: getFirst of []; capacity of array > size of array
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  boolean thrown = false;
  try {Comparable actual = n.getFirst();}
  catch (IndexOutOfBoundsException e) {thrown = true;}
  if(!thrown) {
       failFmt("getFirst:\n"+
               "Expect: "+"IndexOutOfBoundsException" +"\n"+
               "Actual: "+" IndexOutOfBoundsException not thrown"+"\n"+"");
    }
  }

// test ArrayNode.getLast

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_getLast1(){
  // Check getFirst: getLast of [1,2];
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(2));
  Comparable actual = n.getLast();
  Integer expect = 2; 
  if(actual.compareTo(expect)!= 0) {
       failFmt("getLast:\n"+
               "Expect: "+expect +"\n"+
               "Actual: "+actual+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_getLast2(){
  // Check getFirst: getLast of [1]; capacity of array > size of array
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(1));
  Comparable actual = n.getLast();
  Integer expect = 1; 
  if(actual.compareTo(expect)!= 0) {
       failFmt("getLast:\n"+
               "Expect: "+expect +"\n"+
               "Actual: "+actual+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_getLast3(){
  // Check getFirst: getLast of []; capacity of array > size of array
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  boolean thrown = false;
  try {Comparable actual = n.getLast();}
  catch (IndexOutOfBoundsException e) {thrown = true;}
  if(!thrown) {
       failFmt("getLast:\n"+
               "Expect: "+"IndexOutOfBoundsException" +"\n"+
               "Actual: "+" IndexOutOfBoundsException not thrown"+"\n"+"");
    }
  }

// test ArrayNode.get

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_get1(){
  // Check get: get index 0 in [2,1];
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(2));
  n.insertSorted(new Integer(1));
  Comparable actual = n.get(1);
  Integer expect = 2; 
  if(actual.compareTo(expect)!= 0) {
       failFmt("get:\n"+
               "Expect: "+expect +"\n"+
               "Actual: "+actual+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_get2(){
  // Check get: get index 1 in [1,2]; capacity of array > size of array
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,3);
  n.insertSorted(new Integer(2));
  n.insertSorted(new Integer(1));
  Comparable actual = n.get(1);
  Integer expect = 2; 
  if(actual.compareTo(expect)!= 0) {
       failFmt("get:\n"+
               "Expect: "+expect +"\n"+
               "Actual: "+actual+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_get3(){
  // Check getFirst: get index 0 in []; capacity of array > size of array
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  boolean thrown = false;
  try {Comparable actual = n.get(0);}
  catch (IndexOutOfBoundsException e) {thrown = true;}
  if(!thrown) {
       failFmt("get:\n"+
               "Expect: "+"IndexOutOfBoundsException" +"\n"+
               "Actual: "+" IndexOutOfBoundsException not thrown"+"\n"+"");
    }
  }

// test ArrayNode.removeFirst (and also test getArraySize after some removes)

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_removeFirst1(){
  // Check : removeFirst for [1,2];
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(2));
  Comparable actualValue = n.removeFirst();
  Integer expectedValue = 1;
  int actualArraySize = n.getArraySize();
  int expectedArraySize = 1;

  if(actualValue.compareTo(expectedValue)!= 0) {
       failFmt("removeFirst:\n"+
               "ExpectValue: "+expectedValue +"\n"+
               "ActualValue: "+actualValue+"\n"+"");
    }
  if(actualArraySize != expectedArraySize) {
       failFmt("removeFirst:\n"+
               "ExpectedArraySize: "+expectedArraySize +"\n"+
               "ActualArrayValue: "+actualArraySize+"\n"+"");
    }
  if (actualArraySize > 0) {
	  Comparable actualArrayElement = n.getFirst();
	  Integer expectedArrayElement = 2;
	  if(actualArrayElement.compareTo(expectedArrayElement)!= 0) {
       failFmt("removeFirst:\n"+
               "ExpectedArrayElement: "+expectedArrayElement +"\n"+
               "ActualArrayElement: "+actualArrayElement+"\n"+"");
		}
  }

  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_removeFirst2(){
  // Check : removeFirst for [2];
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(2));
  Comparable actualValue = n.removeFirst();
  Integer expectedValue = 2;
  int actualArraySize = n.getArraySize();
  int expectedArraySize = 0;
  if(actualValue.compareTo(expectedValue)!= 0) {
       failFmt("removeFirst:\n"+
               "ExpectValue: "+expectedValue +"\n"+
               "ActualValue: "+actualValue+"\n"+"");
    }
  if(actualArraySize != expectedArraySize) {
       failFmt("removeFirst:\n"+
               "ExpectedArraySize: "+expectedArraySize +"\n"+
               "ActualArrayValue: "+actualArraySize+"\n"+"");
    }

  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_removeFirst3(){
  // Check removeFirst: removeFirst for []; capacity of array > size of array
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  boolean thrown = false;
  try {Comparable actual = n.removeFirst();}
  catch (IndexOutOfBoundsException e) {thrown = true;}
  if(!thrown) {
       failFmt("removeFirst:\n"+
               "Expect: "+"IndexOutOfBoundsException" +"\n"+
               "Actual: "+" IndexOutOfBoundsException not thrown"+"\n"+"");
    }
  }


// test ArrayNode.removeLast

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_removeLast1(){
  // Check : removeLast for [1,2];
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(2));
  Comparable actualValue = n.removeLast();
  Integer expectedValue = 2;
  int actualArraySize = n.getArraySize();
  int expectedArraySize = 1;

  if(actualValue.compareTo(expectedValue)!= 0) {
       failFmt("removeLast:\n"+
               "ExpectValue: "+expectedValue +"\n"+
               "ActualValue: "+actualValue+"\n"+"");
    }
  if(actualArraySize != expectedArraySize) {
       failFmt("removeLast:\n"+
               "ExpectedArraySize: "+expectedArraySize +"\n"+
               "ActualArrayValue: "+actualArraySize+"\n"+"");
    }
  if (actualArraySize>0) {
	  Comparable actualArrayElement = n.getFirst();
	  Integer expectedArrayElement = 1;

	  if(actualArrayElement.compareTo(expectedArrayElement)!= 0) {
   	    failFmt("removeLast:\n"+
               "ExpectedArrayElement: "+expectedArrayElement +"\n"+
               "ActualArrayElement: "+actualArrayElement+"\n"+"");
    }
  }

  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_removeLast2(){
  // Check : removeLast for [2];
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(2));
  Comparable actualValue = n.removeLast();
  Integer expectedValue = 2;
  int actualArraySize = n.getArraySize();
  int expectedArraySize = 0;
  if(actualValue.compareTo(expectedValue)!= 0) {
       failFmt("removeLast:\n"+
               "ExpectValue: "+expectedValue +"\n"+
               "ActualValue: "+actualValue+"\n"+"");
    }
  if(actualArraySize != expectedArraySize) {
       failFmt("removeLast:\n"+
               "ExpectedArraySize: "+expectedArraySize +"\n"+
               "ActualArrayValue: "+actualArraySize+"\n"+"");
    }

  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_removeLast3(){
  // Check removeLast: removeLast for []; capacity of array > size of array
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  boolean thrown = false;
  try {Comparable actual = n.removeLast();}
  catch (IndexOutOfBoundsException e) {thrown = true;}
  if(!thrown) {
       failFmt("removeLast:\n"+
               "Expect: "+"IndexOutOfBoundsException" +"\n"+
               "Actual: "+" IndexOutOfBoundsException not thrown"+"\n"+"");
    }
  }

// test ArrayNode.remove(int idx)

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_remove_idx1(){
  // Check : remove at position 1 for [1,2];
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(2));
  Comparable actualValue = n.remove(1); // position 1
  Integer expectedValue = 2;
  int actualArraySize = n.getArraySize();
  int expectedArraySize = 1;

  if(actualValue.compareTo(expectedValue)!= 0) {
       failFmt("remove(idx):\n"+
               "ExpectValue: "+expectedValue +"\n"+
               "ActualValue: "+actualValue+"\n"+"");
    }
  if(actualArraySize != expectedArraySize) {
       failFmt("remove(idx):\n"+
               "ExpectedArraySize: "+expectedArraySize +"\n"+
               "ActualArrayValue: "+actualArraySize+"\n"+"");
    }
  if (actualArraySize > 0) {
	  Comparable actualArrayElement = n.getFirst();
	  Integer expectedArrayElement = 1;
	  if(actualArrayElement.compareTo(expectedArrayElement)!= 0) {
       failFmt("remove(idx):\n"+
               "ExpectedArrayElement: "+expectedArrayElement +"\n"+
               "ActualArrayElement: "+actualArrayElement+"\n"+"");
		}
  }

  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_remove_idx2(){
  // Check : remove at position 0 for [2];
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(2));
  Comparable actualValue = n.remove(0); // position 0
  Integer expectedValue = 2;
  int actualArraySize = n.getArraySize();
  int expectedArraySize = 0;
  if(actualValue.compareTo(expectedValue)!= 0) {
       failFmt("remove(idx):\n"+
               "ExpectValue: "+expectedValue +"\n"+
               "ActualValue: "+actualValue+"\n"+"");
    }
  if(actualArraySize != expectedArraySize) {
       failFmt("remove(idx):\n"+
               "ExpectedArraySize: "+expectedArraySize +"\n"+
               "ActualArrayValue: "+actualArraySize+"\n"+"");
    }

  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_remove_idx3(){
  // Check remove at position 1 for [2]; index out of bounds
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(2));
  boolean thrown = false;
  try {Comparable actual = n.remove(1);}
  catch (IndexOutOfBoundsException e) {thrown = true;}
  if(!thrown) {
       failFmt("remove(idx):\n"+
               "Expect: "+"IndexOutOfBoundsException" +"\n"+
               "Actual: "+" IndexOutOfBoundsException not thrown"+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_remove_idx4(){
  // Check remove at position -1 for [2]; index out of bounds
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(1));
  boolean thrown = false;
  try {Comparable actual = n.remove(-1);}
  catch (IndexOutOfBoundsException e) {thrown = true;}
  if(!thrown) {
       failFmt("remove(idx):\n"+
               "Expect: "+"IndexOutOfBoundsException" +"\n"+
               "Actual: "+" IndexOutOfBoundsException not thrown"+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_remove_idx5(){
  // Check : remove at position 1 [1,2,3];
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,4);
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(2));
  n.insertSorted(new Integer(3));
  Comparable actualValue = n.remove(1); // position 1
  Integer expectedValue = 2;
  int actualArraySize = n.getArraySize();
  int expectedArraySize = 2;

  if(actualValue.compareTo(expectedValue)!= 0) {
       failFmt("remove(idx):\n"+
               "ExpectValue: "+expectedValue +"\n"+
               "ActualValue: "+actualValue+"\n"+"");
    }
  if(actualArraySize != expectedArraySize) {
       failFmt("remove(idx):\n"+
               "ExpectedArraySize: "+expectedArraySize +"\n"+
               "ActualArrayValue: "+actualArraySize+"\n"+"");
    }
  if (actualArraySize == 2) {
	  Comparable actualArrayElement1= n.getFirst();
	  Integer expectedArrayElement1 = 1;
	  if(actualArrayElement1.compareTo(expectedArrayElement1)!= 0) {
       failFmt("remove(idx):\n"+
               "ExpectedArrayElement1: "+expectedArrayElement1 +"\n"+
               "ActualArrayElement1: "+actualArrayElement1+"\n"+"");
	  }
	  Comparable actualArrayElement3 = n.getLast();
	  Integer expectedArrayElement3 = 3;
	  if(actualArrayElement3.compareTo(expectedArrayElement3)!= 0) {
       failFmt("remove(idx):\n"+
               "ExpectedArrayElement3: "+expectedArrayElement3 +"\n"+
               "ActualArrayElement3: "+actualArrayElement3+"\n"+"");
		}
  }

  }

// test ArrayNode.remove(U x)

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_remove_Ux1(){
  // Check : remove(U x): remove the 2 in [1,2];
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(2));
  Comparable actualValue = n.remove(new Integer(2));
  Integer expectedValue = 2;
  int actualArraySize = n.getArraySize();
  int expectedArraySize = 1;

  if(actualValue.compareTo(expectedValue)!= 0) {
       failFmt("remove(U x):\n"+
               "ExpectValue: "+expectedValue +"\n"+
               "ActualValue: "+actualValue+"\n"+"");
    }
  if(actualArraySize != expectedArraySize) {
       failFmt("remove(U x):\n"+
               "ExpectedArraySize: "+expectedArraySize +"\n"+
               "ActualArrayValue: "+actualArraySize+"\n"+"");
    }
  if (actualArraySize > 0) {
	  Comparable actualArrayElement = n.getFirst();
	  Integer expectedArrayElement = 1;
	  if(actualArrayElement.compareTo(expectedArrayElement)!= 0) {
       failFmt("remove(U x):\n"+
               "ExpectedArrayElement: "+expectedArrayElement +"\n"+
               "ActualArrayElement: "+actualArrayElement+"\n"+"");
		}
  }

  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_remove_Ux2(){
  // Check : remove(U x): remove the 2 in [2];
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(2));
  Comparable actualValue = n.remove(new Integer(2));
  Integer expectedValue = 2;
  int actualArraySize = n.getArraySize();
  int expectedArraySize = 0;
  if(actualValue.compareTo(expectedValue)!= 0) {
       failFmt("remove(U):\n"+
               "ExpectValue: "+expectedValue +"\n"+
               "ActualValue: "+actualValue+"\n"+"");
    }
  if(actualArraySize != expectedArraySize) {
       failFmt("remove(U):\n"+
               "ExpectedArraySize: "+expectedArraySize +"\n"+
               "ActualArrayValue: "+actualArraySize+"\n"+"");
    }

  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_remove_Ux3(){
  // Check : remove(U x): remove the 3 in [1,2]; return null since no 3
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(2));
  Comparable actual = n.remove(new Integer(3));
  if(actual != null) {
       failFmt("remove(U):\n"+
               "Expect: "+"null" +"\n"+
               "Actual: "+actual+"\n"+"");
    } 

  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_remove_Ux4(){
  // Check : remove(U x): remove the 2 in [1,2,3]
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,4);
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(2));
  n.insertSorted(new Integer(3));
  Comparable actualValue = n.remove(new Integer(2)); // position 1
  Integer expectedValue = 2;
  int actualArraySize = n.getArraySize();
  int expectedArraySize = 2;

  if(actualValue.compareTo(expectedValue)!= 0) {
       failFmt("remove(U):\n"+
               "ExpectValue: "+expectedValue +"\n"+
               "ActualValue: "+actualValue+"\n"+"");
    }
  if(actualArraySize != expectedArraySize) {
       failFmt("remove(U):\n"+
               "ExpectedArraySize: "+expectedArraySize +"\n"+
               "ActualArrayValue: "+actualArraySize+"\n"+"");
    }
  if (actualArraySize == 2) {
	  Comparable actualArrayElement1= n.getFirst();
	  Integer expectedArrayElement1 = 1;
	  if(actualArrayElement1.compareTo(expectedArrayElement1)!= 0) {
       failFmt("remove(U):\n"+
               "ExpectedArrayElement1: "+expectedArrayElement1 +"\n"+
               "ActualArrayElement1: "+actualArrayElement1+"\n"+"");
	  }
	  Comparable actualArrayElement3 = n.getLast();
	  Integer expectedArrayElement3 = 3;
	  if(actualArrayElement3.compareTo(expectedArrayElement3)!= 0) {
       failFmt("remove(U):\n"+
               "ExpectedArrayElement3: "+expectedArrayElement3 +"\n"+
               "ActualArrayElement3: "+actualArrayElement3+"\n"+"");
		}
  }

  }

// test insertSorted(null)

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_remove_null1(){
  // Check remove(x) where x is null throws exception
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  boolean thrown = false;
  try {Comparable actual = n.remove(null);}
  catch (IllegalArgumentException  e) {thrown = true;}
  if(!thrown) {
       failFmt("remove(null):\n"+
               "Expect: "+"IllegalArgumentException" +"\n"+
               "Actual: "+"IllegalArgumentException not thrown"+"\n"+"");
    }
  }

// test remove(null)

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_insertSorted_null1(){
  // Check insertSorted(x) where x is null throws exception
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,2);
  boolean thrown = false;
  try {n.insertSorted(null);}
  catch (IllegalArgumentException  e) {thrown = true;}
  if(!thrown) {
       failFmt("insertSorted(null):\n"+
               "Expect: "+"IllegalArgumentException" +"\n"+
               "Actual: "+"IllegalArgumentException not thrown"+"\n"+"");
    }
  }

// test ArrayNode.toString()

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_toString1(){
  // Check : toString for [1,2,3]
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,4);
  n.insertSorted(new Integer(1));
  n.insertSorted(new Integer(2));
  n.insertSorted(new Integer(3));
  // Consider "1, 2, 3" and "1,2,3" as passing
  String actualValue = n.toString().replaceAll("\\s+",""); // removes all whitespaces and non visible characters
  String expectedValue = "1,2,3"; // 

  if(actualValue.compareTo(expectedValue)!= 0) {
       failFmt("ArrayNode toString:\n"+
               "ExpectValue: "+expectedValue +"\n"+
               "ActualValue: "+actualValue+"\n"+"");
  }
  }

// test ArrayNode convenience constructor

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_convenience_constructor1(){
  // Check : convenience constructor capacity 16
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null);
  Object[] array = n.getArray();
  int actualDefaultCapacity = array.length;
  int expectedDefaultCapacity = 16;

  if(actualDefaultCapacity != expectedDefaultCapacity) {
       failFmt("ArrayNode_convenience_constructor:\n"+
               "expectedDefaultCapacity: "+expectedDefaultCapacity +"\n"+
               "actualDefaultCapacity: "+actualDefaultCapacity+"\n"+"");
  }
  }

// test ArrayNode workhorse constructor

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ArrayNode_constructor1(){
  // Check : constructor capacity 8
  ChainedArrays.ArrayNode n = new ChainedArrays.ArrayNode(null,null,8);
  Object[] array = n.getArray();
  int actualCapacity = array.length;
  int expectedCapacity = 8;

  if(actualCapacity != expectedCapacity) {
       failFmt("ArrayNode constructor:\n"+
               "expectedCapacity: "+expectedCapacity +"\n"+
               "actualCapacity: "+actualCapacity+"\n"+"");
  }
  }


// test ChainedArrays.getNode

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_getNode1() {
  // test getNode()
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);  //=> [1,2] --> [3,4] --> [5,6]

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("getNode:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);

   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 2;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("getNode:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }

   Comparable actualFirstValue1 = current.getFirst();
   Integer expectedFirstValue1 = 1;
   if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
       failFmt("getNode:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
   }

   Comparable actualLastValue1 = current.getLast();
   Integer expectedLastValue1 = 2;
   if (actualLastValue1.compareTo(expectedLastValue1)!=0) {
       failFmt("getNode:\n"+
               "expectedLastValue1: " + expectedLastValue1 +"\n"+
               "actualLastValue1: " + actualLastValue1 + "");
   }

   ChainedArrays.ArrayNode node1 = C.getNode(1);

   int actualArraySize2 = node1.getArraySize();
   int expectedArraySize2 = 2;

   if(actualArraySize2 != expectedArraySize2) {
       failFmt("getNode:\n"+
               "expectedArraySize2: "+expectedArraySize2 +"\n"+
               "actualArraySize2: "+actualArraySize2+"\n"+"");
   }

   Comparable actualFirstValue2 = node1.getFirst();
   Integer expectedFirstValue2 = 3;
   if (actualFirstValue2.compareTo(expectedFirstValue2)!=0) {
       failFmt("getNode:\n"+
               "expectedFirstValue2: " + expectedFirstValue2 +"\n"+
               "actualFirstValue2: " + actualFirstValue2 + "");
   }

   Comparable actualLastValue2 = node1.getLast();
   Integer expectedLastValue2 = 2;
   if (actualLastValue1.compareTo(expectedLastValue2)!=0) {
       failFmt("getNode:\n"+
               "expectedLastValue2: " + expectedLastValue2 +"\n"+
               "actualLastValue2: " + actualLastValue2 + "");
   }

   ChainedArrays.ArrayNode node2 = C.getNode(2);

   int actualArraySize3 = node2.getArraySize();
   int expectedArraySize3 = 2;

   if(actualArraySize3 != expectedArraySize3) {
       failFmt("getNode:\n"+
               "expectedArraySize3: "+expectedArraySize3 +"\n"+
               "actualArraySize3: "+actualArraySize3+"\n"+"");
   }

   Comparable actualFirstValue3 = node2.getFirst();
   Integer expectedFirstValue3 = 5;
   if (actualFirstValue3.compareTo(expectedFirstValue3)!=0) {
       failFmt("getNode:\n"+
               "expectedFirstValue3: " + expectedFirstValue3 +"\n"+
               "actualFirstValue3: " + actualFirstValue3 + "");
   }

   Comparable actualLastValue3 = node2.getLast();
   Integer expectedLastValue3 = 6;
   if (actualLastValue3.compareTo(expectedLastValue3)!=0) {
       failFmt("getNode:\n"+
               "expectedLastValue3: " + expectedLastValue3 +"\n"+
               "actualLastValue3: " + actualLastValue3 + "");
   }
   }

// test ChainedArrays.getNode( int idx, int lower, int upper )

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_getNodeLowerUpper1() {
  // test getNode(idx,lower,upper) in range
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);  //=> [1,2] --> [3,4] --> [5,6]

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays getNodeLowerUpper:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(0,0,C.nodeCount()-1);

   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 2;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("ChainedArrays getNodeLowerUpper:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }

   Comparable actualFirstValue1 = current.getFirst();
   Integer expectedFirstValue1 = 1;
   if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
       failFmt("ChainedArrays getNodeLowerUpper:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
   }

   Comparable actualLastValue1 = current.getLast();
   Integer expectedLastValue1 = 2;
   if (actualLastValue1.compareTo(expectedLastValue1)!=0) {
       failFmt("ChainedArrays getNodeLowerUpper:\n"+
               "expectedLastValue1: " + expectedLastValue1 +"\n"+
               "actualLastValue1: " + actualLastValue1 + "");
   }

   ChainedArrays.ArrayNode node1 = C.getNode(1);

   int actualArraySize2 = node1.getArraySize();
   int expectedArraySize2 = 2;

   if(actualArraySize2 != expectedArraySize2) {
       failFmt("ChainedArrays getNodeLowerUpper:\n"+
               "expectedArraySize2: "+expectedArraySize2 +"\n"+
               "actualArraySize2: "+actualArraySize2+"\n"+"");
   }

   Comparable actualFirstValue2 = node1.getFirst();
   Integer expectedFirstValue2 = 3;
   if (actualFirstValue2.compareTo(expectedFirstValue2)!=0) {
       failFmt("ChainedArrays getNodeLowerUpper:\n"+
               "expectedFirstValue2: " + expectedFirstValue2 +"\n"+
               "actualFirstValue2: " + actualFirstValue2 + "");
   }

   Comparable actualLastValue2 = node1.getLast();
   Integer expectedLastValue2 = 2;
   if (actualLastValue1.compareTo(expectedLastValue2)!=0) {
       failFmt("ChainedArrays getNodeLowerUpper:\n"+
               "expectedLastValue2: " + expectedLastValue2 +"\n"+
               "actualLastValue2: " + actualLastValue2 + "");
   }

   ChainedArrays.ArrayNode node2 = C.getNode(2);

   int actualArraySize3 = node2.getArraySize();
   int expectedArraySize3 = 2;

   if(actualArraySize3 != expectedArraySize3) {
       failFmt("ChainedArrays getNodeLowerUpper:\n"+
               "expectedArraySize3: "+expectedArraySize3 +"\n"+
               "actualArraySize3: "+actualArraySize3+"\n"+"");
   }

   Comparable actualFirstValue3 = node2.getFirst();
   Integer expectedFirstValue3 = 5;
   if (actualFirstValue3.compareTo(expectedFirstValue3)!=0) {
       failFmt("ChainedArrays getNodeLowerUpper:\n"+
               "expectedFirstValue3: " + expectedFirstValue3 +"\n"+
               "actualFirstValue3: " + actualFirstValue3 + "");
   }

   Comparable actualLastValue3 = node2.getLast();
   Integer expectedLastValue3 = 6;
   if (actualLastValue3.compareTo(expectedLastValue3)!=0) {
       failFmt("ChainedArrays getNodeLowerUpper:\n"+
               "expectedLastValue3: " + expectedLastValue3 +"\n"+
               "actualLastValue3: " + actualLastValue3 + "");
   }
   }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_getNodeLowerUpper2() {
  // test getNode(idx, lower,upper) out of range
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);  //=> [1,2] --> [3,4] --> [5,6]

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays getNodeLowerUpper:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
	boolean thrown = false;
   // -1 is out of range
	try {ChainedArrays.ArrayNode current = C.getNode(-1,0,C.nodeCount()-1);}
	catch (IndexOutOfBoundsException e) {thrown=true;}
   if(!thrown) {
       failFmt("ChainedArrays getNodeLowerUpper:\n"+
               "Expect: "+"NoSuchElementException" +"\n"+
               "Actual: "+"NoSuchElementException not thrown"+"\n"+"");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_getNodeLowerUpper3() {
  // test getNode(idx, lower,upper) out of range
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);  //=> [1,2] --> [3,4] --> [5,6]

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays getNodeLowerUpper:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
	boolean thrown = false;
   // nodeCount() is out of range
	try {ChainedArrays.ArrayNode current = C.getNode(0,C.nodeCount(),C.nodeCount()-1);}
	catch (IndexOutOfBoundsException e) {thrown=true;}
   if(!thrown) {
       failFmt("ChainedArrays getNodeLowerUpper:\n"+
               "Expect: "+"NoSuchElementException" +"\n"+
               "Actual: "+"NoSuchElementException not thrown"+"\n"+"");
   }
   }


// test ChainedArrays.add (More tests later ... )

/*
If A is empty, then the first data Node is created and linked into 
the list and current is the first data node.

>***************        ***************
* beginMarker *   -->   *  endMarker  *
***************   <--   *************** 


***************        ***************         ***************
* beginMarker *   -->  *             *    -->  *  endMarker  *
***************   <--  ***************    >--  *************** 
                           current
*/

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_add1(){
  // test adding to empty ChainedArrays
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   int actualNumberNodes = C.nodeCount();
   int expectedActualNodes = 1;
   ChainedArrays.ArrayNode n = C.getNode(0);
   if (n == null) {
       failFmt("add:\n"+
               "Expect: "+"non-null first data node" +"\n"+
               "Actual: "+"null first data node"+"");
   }
  int actualArraySize = n.getArraySize();
  int expectedArraySize = 1;

  if(actualArraySize != expectedArraySize) {
       failFmt("add:\n"+
               "ExpectedArraySize: "+expectedArraySize +"\n"+
               "ActualArrayValue: "+actualArraySize+"\n"+"");
  }

  if (actualArraySize == 1) {
	  Comparable actualArrayElement = n.getFirst();
	  Integer expectedArrayElement = 2;
	  if(actualArrayElement.compareTo(expectedArrayElement)!= 0) {
       failFmt("add:\n"+
               "ExpectedArrayElement: "+expectedArrayElement +"\n"+
               "ActualArrayElement: "+actualArrayElement+"\n"+"");
	  }
  }
  }


// test ChainedArrays.insertSortedWithPossibleSplit

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_insertSortedWithPossibleSplit1() {
   // test ChainedArrays_insertSortedWithPossibleSplit1 insert 2 into [1 ] w/ capacity 2
   // There is a single data node with [1 ]
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   // C is empty
   C.add(1);
   ChainedArrays.ArrayNode n = C.getNode(0);
   C.insertWithPossibleSplit(n,new Integer(2));
   Object[] actual1 = n.getArray();
   Object[] expect1 = {1,2};
    if(!Arrays.deepEquals(actual1,expect1)){
       failFmt("insertSortedWithPossibleSplit:\n"+
               "Expect1: "+printArray(expect1) +"\n"+
               "Actual1: "+printArray(actual1)+"\n"+"");
    }
   int actualNodeCount = C.nodeCount();
   int expectedNodeCount = 1;
   if(actualNodeCount != expectedNodeCount) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "expectedNodeCount: "+expectedNodeCount +"\n"+
               "actualNodeCount: "+actualNodeCount+"\n"+"");
  }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_insertSortedWithPossibleSplit2() {
   // test ChainedArrays_insertSortedWithPossibleSplit1 insert 2 into [1] w/ capacity 1
   // There is a single data node with [1]. Special case: capacity 1 node
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(1);
   C.add(1);
   int actualNodeCount1 = C.nodeCount();
   int expectedNodeCount1 = 1;
   if(actualNodeCount1 != expectedNodeCount1) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "expectedNodeCount1: "+expectedNodeCount1 +"\n"+
               "actualNodeCount1: "+actualNodeCount1+"\n"+"");
  }
   ChainedArrays.ArrayNode current = C.getNode(0);
   C.insertWithPossibleSplit(current,new Integer(2));
   Object[] actual2 = current.getArray();
   Object[] expect2 = {1};
    if(!Arrays.deepEquals(actual2,expect2)){
       failFmt("insertSortedWithPossibleSplit:\n"+
               "Expect2: "+printArray(expect2) +"\n"+
               "Actual2: "+printArray(actual2)+"\n"+"");
    }
   int actualNodeCount2 = C.nodeCount();
   int expectedNodeCount2 = 2;
   if(actualNodeCount2 != expectedNodeCount2) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "expectedNodeCount2: "+expectedNodeCount2 +"\n"+
               "actualNodeCount2: "+actualNodeCount2+"\n"+"");
   }
   ChainedArrays.ArrayNode next = C.getNode(1);
   Object[] actual3 = next.getArray();
   Object[] expect3 = {2};
    if(!Arrays.deepEquals(actual3,expect3)){
       failFmt("insertSortedWithPossibleSplit:\n"+
               "Expect3: "+printArray(expect3) +"\n"+
               "Actual3: "+printArray(actual3)+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_insertSortedWithPossibleSplit3() {
   // test ChainedArrays_insertSortedWithPossibleSplit1 insert 1 into [2] w/ capacity 1
   // There is a single data node with [2]. Special case: capacity 1 node
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(1);
   C.add(2);
   int actualNodeCount1 = C.nodeCount();
   int expectedNodeCount1 = 1;
   if(actualNodeCount1 != expectedNodeCount1) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "expectedNodeCount1: "+expectedNodeCount1 +"\n"+
               "actualNodeCount1: "+actualNodeCount1+"\n"+"");
  }
   ChainedArrays.ArrayNode current = C.getNode(0);
   C.insertWithPossibleSplit(current,new Integer(1));
   Object[] actual2 = current.getArray();
   Object[] expect2 = {1};
    if(!Arrays.deepEquals(actual2,expect2)){
       failFmt("insertSortedWithPossibleSplit:\n"+
               "Expect2: "+printArray(expect2) +"\n"+
               "Actual2: "+printArray(actual2)+"\n"+"");
    }
   int actualNodeCount2 = C.nodeCount();
   int expectedNodeCount2 = 2;
   if(actualNodeCount2 != expectedNodeCount2) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "expectedNodeCount2: "+expectedNodeCount2 +"\n"+
               "actualNodeCount2: "+actualNodeCount2+"\n"+"");
   }
   ChainedArrays.ArrayNode next = C.getNode(1);
   Object[] actual3 = next.getArray();
   Object[] expect3 = {2};
    if(!Arrays.deepEquals(actual3,expect3)){
       failFmt("insertSortedWithPossibleSplit:\n"+
               "Expect3: "+printArray(expect3) +"\n"+
               "Actual3: "+printArray(actual3)+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_insertSortedWithPossibleSplit4() {
   // test ChainedArrays_insertSortedWithPossibleSplit1 insert 1 into [2,3] w/ capacity 2
   // There is a single data node with [2,3]. 
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   int actualNodeCount1 = C.nodeCount();
   int expectedNodeCount1 = 1;
   if(actualNodeCount1 != expectedNodeCount1) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "expectedNodeCount1: "+expectedNodeCount1 +"\n"+
               "actualNodeCount1: "+actualNodeCount1+"\n"+"");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);
   C.insertWithPossibleSplit(current,new Integer(1));
   int actualNodeCount2 = C.nodeCount();
   int expectedNodeCount2 = 2;
   if(actualNodeCount2 != expectedNodeCount2) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "expectedNodeCount2: "+expectedNodeCount2 +"\n"+
               "actualNodeCount2: "+actualNodeCount2+"\n"+"");
   }
   current = C.getNode(0);
   Object[] actual2 = current.getArray();
   Object[] expect2 = {1,2};
    if(!Arrays.deepEquals(actual2,expect2)){
       failFmt("insertSortedWithPossibleSplit:\n"+
               "Expect2: "+printArray(expect2) +"\n"+
               "Actual2: "+printArray(actual2)+"\n"+"");
    }
   ChainedArrays.ArrayNode next = C.getNode(1);
   Object[] actual3 = next.getArray();
   Object[] expect3 = {3,null};
    if(!Arrays.deepEquals(actual3,expect3)){
       failFmt("insertSortedWithPossibleSplit:\n"+
               "Expect3: "+printArray(expect3) +"\n"+
               "Actual3: "+printArray(actual3)+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_insertSortedWithPossibleSplit5() {
   // test ChainedArrays_insertSortedWithPossibleSplit1 insert 3 into [1,2] w/ capacity 2
   // There is a single data node with [2,3]. 
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(1);
   C.add(2);
   int actualNodeCount1 = C.nodeCount();
   int expectedNodeCount1 = 1;
   if(actualNodeCount1 != expectedNodeCount1) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "expectedNodeCount1: "+expectedNodeCount1 +"\n"+
               "actualNodeCount1: "+actualNodeCount1+"\n"+"");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);
   C.insertWithPossibleSplit(current,new Integer(3));
   int actualNodeCount2 = C.nodeCount();
   int expectedNodeCount2 = 2;
   if(actualNodeCount2 != expectedNodeCount2) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "expectedNodeCount2: "+expectedNodeCount2 +"\n"+
               "actualNodeCount2: "+actualNodeCount2+"\n"+"");
   }
   current = C.getNode(0);
   int actualArraySize = current.getArraySize();
   int expectedArraySize = 1;

   if(actualArraySize != expectedArraySize) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "ExpectedArraySize: "+expectedArraySize +"\n"+
               "ActualArrayValue: "+actualArraySize+"\n"+"");
   }
   if (actualArraySize == 1) {
	  Comparable actualArrayElement = current.getFirst();
	  Integer expectedArrayElement = 1;
	  if(actualArrayElement.compareTo(expectedArrayElement)!= 0) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "ExpectedArrayElement: "+expectedArrayElement +"\n"+
               "ActualArrayElement: "+actualArrayElement+"\n"+"");
	  }
   }
   ChainedArrays.ArrayNode next = C.getNode(1);
   Object[] actual3 = next.getArray();
   Object[] expect3 = {2,3};
    if(!Arrays.deepEquals(actual3,expect3)){
       failFmt("insertSortedWithPossibleSplit:\n"+
               "Expect3: "+printArray(expect3) +"\n"+
               "Actual3: "+printArray(actual3)+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_insertSortedWithPossibleSplit6() {
   // test ChainedArrays_insertSortedWithPossibleSplit1 insert 4 into [1,2,3] w/ capacity 3
   // There is a single data node with [2,3]. 
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(3);
   C.add(1);
   C.add(2);
   C.add(3);
   int actualNodeCount1 = C.nodeCount();
   int expectedNodeCount1 = 1;
   if(actualNodeCount1 != expectedNodeCount1) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "expectedNodeCount1: "+expectedNodeCount1 +"\n"+
               "actualNodeCount1: "+actualNodeCount1+"\n"+"");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);
   C.insertWithPossibleSplit(current,new Integer(4));
   int actualNodeCount2 = C.nodeCount();
   int expectedNodeCount2 = 2;
   if(actualNodeCount2 != expectedNodeCount2) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "expectedNodeCount2: "+expectedNodeCount2 +"\n"+
               "actualNodeCount2: "+actualNodeCount2+"\n"+"");
   }
   current = C.getNode(0);
   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 1;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "ExpectedArraySize1: "+expectedArraySize1 +"\n"+
               "ActualArrayValue1: "+actualArraySize1+"\n"+"");
   }
   if (actualArraySize1 == 1) {
	  Comparable actualArrayElement1 = current.getFirst();
	  Integer expectedArrayElement1 = 1;
	  if(actualArrayElement1.compareTo(expectedArrayElement1)!= 0) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "ExpectedArrayElement1: "+expectedArrayElement1 +"\n"+
               "ActualArrayElement1: "+actualArrayElement1+"\n"+"");
	  }

   }
   ChainedArrays.ArrayNode next = C.getNode(1);
   int actualArraySize2 = next.getArraySize();
   int expectedArraySize2 = 3;

   if(actualArraySize2 != expectedArraySize2) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "ExpectedArraySize2: "+expectedArraySize2 +"\n"+
               "ActualArrayValue2: "+actualArraySize2+"\n"+"");
   }
   if (actualArraySize2 == 2) {
	  Comparable actualArrayElement3 = next.getFirst();
	  Integer expectedArrayElement3 = 2;
	  if(actualArrayElement3.compareTo(expectedArrayElement3)!= 0) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "ExpectedArrayElement3: "+expectedArrayElement3 +"\n"+
               "ActualArrayElement3: "+actualArrayElement3+"\n"+"");
	  }
	  Comparable actualArrayElement4 = next.get(1);
	  Integer expectedArrayElement4 = 3;
	  if(actualArrayElement4.compareTo(expectedArrayElement4)!= 0) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "ExpectedArrayElement4: "+expectedArrayElement4 +"\n"+
               "ActualArrayElement4: "+actualArrayElement4+"\n"+"");
	  }
	  Comparable actualArrayElement5 = next.getLast();
	  Integer expectedArrayElement5 = 4;
	  if(actualArrayElement5.compareTo(expectedArrayElement5)!= 0) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "ExpectedArrayElement5: "+expectedArrayElement5 +"\n"+
               "ActualArrayElement5: "+actualArrayElement5+"\n"+"");
	  }
   }

  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_insertSortedWithPossibleSplit7() {
   // test ChainedArrays_insertSortedWithPossibleSplit1 insert 2 into [1] w/ capacity 1
   // There is a single data node with [1]. Special case: capacity 1 node

   ChainedArrays<Integer> C = new ChainedArrays<Integer>(1);
   C.add(1);
   int actualNodeCount1 = C.nodeCount();
   int expectedNodeCount1 = 1;
   if(actualNodeCount1 != expectedNodeCount1) {
       failFmt("insertSortedWithPossibleSplit:\n"+
               "expectedNodeCount1: "+expectedNodeCount1 +"\n"+
               "actualNodeCount1: "+actualNodeCount1+"\n"+"");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);
   ChainedArrays.ArrayNode end = new ChainedArrays.ArrayNode(current,current.next,1);
  	end.insertSorted(new Integer(3));
	current.next.prev = end;
	current.next = end;

   C.insertWithPossibleSplit(current,new Integer(2));

   Object[] actual2 = current.getArray();
   Object[] expect2 = {1};
    if(!Arrays.deepEquals(actual2,expect2)){
       failFmt("insertSortedWithPossibleSplit:\n"+
               "Expect2: "+printArray(expect2) +"\n"+
               "Actual2: "+printArray(actual2)+"\n"+"");
    }

   ChainedArrays.ArrayNode next = current.next;
   Object[] actual3 = next.getArray();
   Object[] expect3 = {2};
    if(!Arrays.deepEquals(actual3,expect3)){
       failFmt("insertSortedWithPossibleSplit:\n"+
               "Expect3: "+printArray(expect3) +"\n"+
               "Actual3: "+printArray(actual3)+"\n"+"");
    }

   end = next.next;
   Object[] actual4 = end.getArray();
   Object[] expect4 = {3};
    if(!Arrays.deepEquals(actual4,expect4)){
       failFmt("insertSortedWithPossibleSplit:\n"+
               "Expect4: "+printArray(expect4) +"\n"+
               "Actual4: "+printArray(actual4)+"\n"+"");
    }
  }

// 

// test ChainedArrays.add

/*
If A has one data node N, which is node beginMarker.next and node endMarker.prev, 
then current is node N.
***************        ***************       ***************
* beginMarker *   -->  *             *  -->  *  endMarker  *
***************   <--  ***************  <--  ***************
                           current
*/

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_add2(){
  // test adding to empty ChainedArrays
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(4);
   C.add(1); // create first data node and insert 1
   C.add(2); // insert 2, 3, and 4 into first data node
   C.add(3);
   C.add(4);
   int actualNumberNodes = C.nodeCount();
   int expectedActualNodes = 1;
   ChainedArrays.ArrayNode current = C.getNode(0);
   if (current == null) {
       failFmt("add:\n"+
               "Expect: "+"non-null first data node" +"\n"+
               "Actual: "+"null first data node"+"");
   }
  int actualArraySize = current.getArraySize();
  int expectedArraySize = 4;

  if(actualArraySize != expectedArraySize) {
       failFmt("add:\n"+
               "ExpectedArraySize: "+expectedArraySize +"\n"+
               "ActualArrayValue: "+actualArraySize+"\n"+"");
  }

  if (actualArraySize == 1) {
	  Comparable actualArrayElement = current.getFirst();
	  Integer expectedArrayElement = 2;
	  if(actualArrayElement.compareTo(expectedArrayElement)!= 0) {
       failFmt("add:\n"+
               "ExpectedArrayElement: "+expectedArrayElement +"\n"+
               "ActualArrayElement: "+actualArrayElement+"\n"+"");
	  }
   }
   Object[] actual = current.getArray();
   Object[] expect = {1,2,3,4};
    if(!Arrays.deepEquals(actual,expect)){
       failFmt("add:\n"+
               "Expect: "+printArray(expect) +"\n"+
               "Actual: "+printArray(actual)+"\n"+"");
    }
  }

/*
If A has more than one data node, but the inserted data value is less than the minimum value in the first 
data node (i.e., beginMarker.next) then current is the first data node.
insert: 1

***************        ************       *********       ***************
* beginMarker *   -->  *  2   3   *  -->  *  5       -->  *  endMarker  *
***************   <--  ************  <--  *********  <--  ***************
                           current
*/

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_add3(){
  // test adding to empty ChainedArrays
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2); // add 2 to first node
   C.add(5); // add 5 to first node
   C.add(3); // split first node into [2, ] -> [5, ] and add 3: [2,3] -> [5, ]
   // more than one data node 
   C.add(1); // 1 < 2  ==> [1,2] -> [3, ] -> [5, ]

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("add:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);

   Comparable actualFirstValue1 = current.getFirst();
   Integer expectedFirstValue1 = 1;
   if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
       failFmt("add:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
   }

   Comparable actualLastValue = current.getLast();
   Integer expectedLastValue = 2;
   if (actualLastValue.compareTo(expectedLastValue) != 0) {
       failFmt("add:\n"+
               "expectedLastValue: " + expectedLastValue +"\n"+
               "actualLastValue: " + actualLastValue + "");
   }

   ChainedArrays.ArrayNode node2 = C.getNode(1);

   Comparable actualFirstValue2 = node2.getFirst();
   Integer expectedFirstValue2 = 3;
   if (actualFirstValue2.compareTo(expectedFirstValue2) != 0) {
       failFmt("add:\n"+
               "expectedFirstValue2: " + expectedFirstValue2 +"\n"+
               "actualFirstValue2: " + actualFirstValue2 + "");
   }
  
   int actualArraySize1 = node2.getArraySize();
   int expectedArraySize1 = 1;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("add:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }

   ChainedArrays.ArrayNode node3 = C.getNode(2);

   Comparable actualFirstValue3 = node3.getFirst();
   Integer expectedFirstValue3 = 5;
   if (actualFirstValue3.compareTo(expectedFirstValue3)!=0) {
       failFmt("add:\n"+
               "expectedFirstValue3: " + expectedFirstValue3 +"\n"+
               "actualFirstValue3: " + actualFirstValue3 + "");
   }
  
   int actualArraySize2 = node3.getArraySize();
   int expectedArraySize2 = 1;

   if(actualArraySize2 != expectedArraySize2) {
       failFmt("add:\n"+
               "expectedArraySize2: "+expectedArraySize2 +"\n"+
               "actualArraySize2: "+actualArraySize2+"\n"+"");
   }
  }

/*
If there are two data nodes N1 and N2 in A such that: N1.next == N2, and the inserted data value is greater 
than the maximum value in Node N1 and less than the minimum value in node N2, then current is the 
node with the smallest number of data elements. If N1 and N2 have the same number of elements, 
then current is N2.
insert: 4

***************        ************       *********       ***************
* beginMarker *   -->  *  2   3   *  -->  *  5       -->  *  endMarker  *
***************   <--  ************  <--  *********  <--  ***************
                           current
*/

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_add4(){
  // test adding to empty ChainedArrays
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2); // add 2 to first node
   C.add(5); // add 5 to first node
   C.add(3); // split first node into [2, ] -> [5, ] and add 3: [2,3] -> [5, ]
   // more than one data node 
   C.add(4); // 4 > 3 && 4 < 5 and the node with 5 is smaller ==> [2,3] -> [4,5]
;
   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 2;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("add:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);

   Comparable actualFirstValue1 = current.getFirst();
   Integer expectedFirstValue1 = 2;
   if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
       failFmt("add:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
   }

   Comparable actualLastValue1 = current.getLast();
   Integer expectedLastValue1 = 3;
   if (actualLastValue1.compareTo(expectedLastValue1) != 0) {
       failFmt("add:\n"+
               "expectedLastValue1: " + expectedLastValue1 +"\n"+
               "actualLastValue1: " + actualLastValue1 + "");
   }

   ChainedArrays.ArrayNode node2 = C.getNode(1);

   Comparable actualFirstValue2 = node2.getFirst();
   Integer expectedFirstValue2 = 4;
   if (actualFirstValue2.compareTo(expectedFirstValue2) != 0) {
       failFmt("add:\n"+
               "expectedFirstValue2: " + expectedFirstValue2 +"\n"+
               "actualFirstValue2: " + actualFirstValue2 + "");
   }
  
   int actualArraySize1 = node2.getArraySize();
   int expectedArraySize1 = 2;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("add:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }

   Comparable actualLastValue2 = node2.getLast();
   Integer expectedLastValue2 = 5;
   if (actualLastValue2.compareTo(expectedLastValue2) != 0) {
       failFmt("add:\n"+
               "expectedLastValue2: " + expectedLastValue2 +"\n"+
               "actualLastValue2: " + actualLastValue2 + "");
   }
  }


/*
If A has more than one data node, and the inserted data value is greater than the maximum value in the last
data node L of A, then current is node L.

insert: 6

***************        ************       *********       ***************
* beginMarker *   -->  *  2   3   *  -->  *  5       -->  *  endMarker  *
***************   <--  ************  <--  *********  <--  ***************
                           current
*/

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_add5(){
  // test adding to empty ChainedArrays
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2); // add 2 to first node
   C.add(5); // add 5 to first node
   C.add(3); // split first node into [2, ] -> [5, ] and add 3: [2,3] -> [5, ]
   // 6 > 5 and there is space in the last node
   C.add(6); //  [2,3] -> [5,6]

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 2;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("add:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);

   Comparable actualFirstValue1 = current.getFirst();
   Integer expectedFirstValue1 = 2;
   if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
       failFmt("add:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
   }

   Comparable actualLastValue1 = current.getLast();
   Integer expectedLastValue1 = 3;
   if (actualLastValue1.compareTo(expectedLastValue1) != 0) {
       failFmt("add:\n"+
               "expectedLastValue1: " + expectedLastValue1 +"\n"+
               "actualLastValue1: " + actualLastValue1 + "");
   }

   ChainedArrays.ArrayNode node2 = C.getNode(1);

   Comparable actualFirstValue2 = node2.getFirst();
   Integer expectedFirstValue2 = 5;
   if (actualFirstValue2.compareTo(expectedFirstValue2) != 0) {
       failFmt("add:\n"+
               "expectedFirstValue2: " + expectedFirstValue2 +"\n"+
               "actualFirstValue2: " + actualFirstValue2 + "");
   }
  
   int actualArraySize1 = node2.getArraySize();
   int expectedArraySize1 = 2;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("add:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }

   Comparable actualLastValue2 = node2.getLast();
   Integer expectedLastValue2 = 6;
   if (actualLastValue2.compareTo(expectedLastValue2) != 0) {
       failFmt("add:\n"+
               "expectedLastValue2: " + expectedLastValue2 +"\n"+
               "actualLastValue2: " + actualLastValue2 + "");
   }
  }

/*
If A has more than one data node, and the inserted data value is greater than the maximum value in the last
data node L of A, then current is node L.

insert: 7

***************        ************       *********       ***************
* beginMarker *   -->  *  2   3   *  -->  *  5   6    -->  *  endMarker  *
***************   <--  ************  <--  *********   <--  ***************
                           current
*/

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_add6(){
  // test adding to empty ChainedArrays
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2); // add 2 to first node
   C.add(5); // add 5 to first node
   C.add(3); // split first node into [2, ] -> [5, ] and add 3: [2,3] -> [5, ]
   C.add(6); // [2,3] -> [5,6]
   // 7 > 6
   C.add(7); // [2,3] -> [5, ] -> [6,7]

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("add:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);

   Comparable actualFirstValue1 = current.getFirst();
   Integer expectedFirstValue1 = 2;
   if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
       failFmt("add:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
   }

   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 2;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("add:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }

   Comparable actualLastValue1 = current.getLast();
   Integer expectedLastValue1 = 3;
   if (actualLastValue1.compareTo(expectedLastValue1) != 0) {
       failFmt("add:\n"+
               "expectedLastValue1: " + expectedLastValue1 +"\n"+
               "actualLastValue1: " + actualLastValue1 + "");
   }

   ChainedArrays.ArrayNode node2 = C.getNode(1);

   Comparable actualFirstValue2 = node2.getFirst();
   Integer expectedFirstValue2 = 5;
   if (actualFirstValue2.compareTo(expectedFirstValue2) != 0) {
       failFmt("add:\n"+
               "expectedFirstValue2: " + expectedFirstValue2 +"\n"+
               "actualFirstValue2: " + actualFirstValue2 + "");
   }
  
   int actualArraySize2 = node2.getArraySize();
   int expectedArraySize2 = 1;

   if(actualArraySize2 != expectedArraySize2) {
       failFmt("add:\n"+
               "expectedArraySize2: "+expectedArraySize2 +"\n"+
               "actualArraySize2: "+actualArraySize2+"\n"+"");
   }

   ChainedArrays.ArrayNode node3 = C.getNode(2);

   Comparable actualFirstValue3 = node3.getFirst();
   Integer expectedFirstValue3 = 6;
   if (actualFirstValue3.compareTo(expectedFirstValue3) != 0) {
       failFmt("add:\n"+
               "expectedFirstValue3: " + expectedFirstValue3 +"\n"+
               "actualFirstValue3: " + actualFirstValue3 + "");
   }

   int actualArraySize3 = node3.getArraySize();
   int expectedArraySize3 = 2;

   if(actualArraySize3 != expectedArraySize3) {
       failFmt("add:\n"+
               "expectedArraySize3: "+expectedArraySize3 +"\n"+
               "actualArraySize3: "+actualArraySize3+"\n"+"");
   }

   Comparable actualLastValue2 = node3.getLast();
   Integer expectedLastValue2 = 7;
   if (actualLastValue2.compareTo(expectedLastValue2) != 0) {
       failFmt("add:\n"+
               "expectedLastValue2: " + expectedLastValue2 +"\n"+
               "actualLastValue2: " + actualLastValue2 + "");
   }

  }


/*
If there are two data nodes N1 and N2 in A such that: N1.next == N2, and the inserted data value is greater 
than the maximum value in Node N1 and less than the minimum value in node N2, then current is the 
node with the smallest number of data elements. If N1 and N2 have the same number of elements, 
then current is N2.


insert: 4

***************        ************       *********       ***************
* beginMarker *   -->  *  2   3   *  -->  *  5  6    -->  *  endMarker  *
***************   <--  ************  <--  *********  <--  ***************
                           current

*/

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_add7(){
  // test adding to empty ChainedArrays
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2); // add 2 to first node
   C.add(5); // add 5 to first node
   C.add(3); // split first node into [2, ] -> [5, ] and add 3: [2,3] -> [5, ]
   C.add(6); // [2,3] -> [5,6]
   // 4 < 5 and 4 > 3 and nodes have equal size
   C.add(4); // [2,3] -> [4,5] -> [6,]


   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("add:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);

   Comparable actualFirstValue1 = current.getFirst();
   Integer expectedFirstValue1 = 2;
   if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
       failFmt("add:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
   }

   Comparable actualLastValue1 = current.getLast();
   Integer expectedLastValue1 = 3;
   if (actualLastValue1.compareTo(expectedLastValue1) != 0) {
       failFmt("add:\n"+
               "expectedLastValue1: " + expectedLastValue1 +"\n"+
               "actualLastValue1: " + actualLastValue1 + "");
   }

   ChainedArrays.ArrayNode node2 = C.getNode(1);

   Comparable actualFirstValue2 = node2.getFirst();
   Integer expectedFirstValue2 = 4;
   if (actualFirstValue2.compareTo(expectedFirstValue2) != 0) {
       failFmt("add:\n"+
               "expectedFirstValue2: " + expectedFirstValue2 +"\n"+
               "actualFirstValue2: " + actualFirstValue2 + "");
   }
  
   int actualArraySize1 = node2.getArraySize();
   int expectedArraySize1 = 2;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("add:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }

   Comparable actualLastValue2 = node2.getLast();
   Integer expectedLastValue2 = 5;
   if (actualLastValue2.compareTo(expectedLastValue2) != 0) {
       failFmt("add:\n"+
               "expectedLastValue2: " + expectedLastValue2 +"\n"+
               "actualLastValue2: " + actualLastValue2 + "");
   }

   ChainedArrays.ArrayNode node3 = C.getNode(2);

   Comparable actualFirstValue3 = node3.getFirst();
   Integer expectedFirstValue3 = 6;
   if (actualFirstValue3.compareTo(expectedFirstValue3) != 0) {
       failFmt("add:\n"+
               "expectedFirstValue3: " + expectedFirstValue2 +"\n"+
               "actualFirstValue3: " + actualFirstValue3 + "");
   }
  
   int actualArraySize2 = node3.getArraySize();
   int expectedArraySize2 = 1;

   if(actualArraySize2 != expectedArraySize2) {
       failFmt("add:\n"+
               "expectedArraySize2: "+expectedArraySize2 +"\n"+
               "actualArraySize2: "+actualArraySize2+"\n"+"");
   }
  }

/*
If A has more than one data node, and for some data node N the inserted data value is greater than or 
equal to the minimum data value in node N and less than or equal to the maximum data value in node N,
then current is node N.

insert: 4

***************        ************       *********       ***************
* beginMarker *   -->  *  2   3   *  -->  *  5  6    -->  *  endMarker  *
***************   <--  ************  <--  *********  <--  ***************
                           current

*/


  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_add8(){
  // test adding to empty ChainedArrays
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(3);
   C.add(2); // add 2 to first node
   C.add(3); // add 3 to first node
   C.add(5); // add 5 to the first node
   C.add(1); //split first node into [2, ] -> [3,5] and add 1: [1,2] -> [3,5]
   // 4 < 5 and 4 > 3
   C.add(4); // [1,2] -> [3,4,5] 


   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 2;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("add:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);

   Comparable actualFirstValue1 = current.getFirst();
   Integer expectedFirstValue1 = 1;
   if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
       failFmt("add:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
   }

   Comparable actualLastValue1 = current.getLast();
   Integer expectedLastValue1 = 2;
   if (actualLastValue1.compareTo(expectedLastValue1) != 0) {
       failFmt("add:\n"+
               "expectedLastValue1: " + expectedLastValue1 +"\n"+
               "actualLastValue1: " + actualLastValue1 + "");
   }

   ChainedArrays.ArrayNode node2 = C.getNode(1);

   Comparable actualFirstValue2 = node2.getFirst();
   Integer expectedFirstValue2 = 3;
   if (actualFirstValue2.compareTo(expectedFirstValue2) != 0) {
       failFmt("add:\n"+
               "expectedFirstValue2: " + expectedFirstValue2 +"\n"+
               "actualFirstValue2: " + actualFirstValue2 + "");
   }
  
   int actualArraySize1 = node2.getArraySize();
   int expectedArraySize1 = 3;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("add:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }

   Comparable actualLastValue2 = node2.getLast();
   Integer expectedLastValue2 = 5;
   if (actualLastValue2.compareTo(expectedLastValue2) != 0) {
       failFmt("add:\n"+
               "expectedLastValue2: " + expectedLastValue2 +"\n"+
               "actualLastValue2: " + actualLastValue2 + "");
   }

   Comparable actualMiddleValue1 = node2.get(1);
   Integer expectedMiddleValue1 = 4;
   if (actualMiddleValue1.compareTo(expectedMiddleValue1) != 0) {
       failFmt("add:\n"+
               "expectedMiddleValue1: " + expectedMiddleValue1 +"\n"+
               "actualMiddleValue1: " + actualMiddleValue1 + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_add9(){
  // test adding with nodes that have an array capacity of 1
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(1);
   C.add(3);
   C.add(5);
   C.add(1); 
   C.add(6);
   C.add(4); // 1 -> 3 -> 4 -> 5 -> 6


   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 5;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("add:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);

   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 1;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("add:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }

   Comparable actualFirstValue1 = current.getFirst();
   Integer expectedFirstValue1 = 1;
   if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
       failFmt("add:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
   }


   ChainedArrays.ArrayNode node1 = C.getNode(1);

   int actualArraySize2 = node1.getArraySize();
   int expectedArraySize2 = 1;

   if(actualArraySize2 != expectedArraySize2) {
       failFmt("add:\n"+
               "expectedArraySize2: "+expectedArraySize2 +"\n"+
               "actualArraySize2: "+actualArraySize2+"\n"+"");
   }

   Comparable actualFirstValue2 = node1.getFirst();
   Integer expectedFirstValue2 = 3;
   if (actualFirstValue2.compareTo(expectedFirstValue2)!=0) {
       failFmt("add:\n"+
               "expectedFirstValue2: " + expectedFirstValue2 +"\n"+
               "actualFirstValue2: " + actualFirstValue2 + "");
   }

   ChainedArrays.ArrayNode node2 = C.getNode(2);

   int actualArraySize3 = node2.getArraySize();
   int expectedArraySize3 = 1;

   if(actualArraySize3 != expectedArraySize3) {
       failFmt("add:\n"+
               "expectedArraySize3: "+expectedArraySize3 +"\n"+
               "actualArraySize3: "+actualArraySize3+"\n"+"");
   }

   Comparable actualFirstValue3 = node2.getFirst();
   Integer expectedFirstValue3 = 4;
   if (actualFirstValue3.compareTo(expectedFirstValue3)!=0) {
       failFmt("add:\n"+
               "expectedFirstValue3: " + expectedFirstValue3 +"\n"+
               "actualFirstValue3: " + actualFirstValue3 + "");
   }

   ChainedArrays.ArrayNode node3 = C.getNode(3);

   int actualArraySize4 = node3.getArraySize();
   int expectedArraySize4 = 1;

   if(actualArraySize4 != expectedArraySize4) {
       failFmt("add:\n"+
               "expectedArraySize4: "+expectedArraySize4 +"\n"+
               "actualArraySize4: "+actualArraySize4+"\n"+"");
   }

   Comparable actualFirstValue4 = node3.getFirst();
   Integer expectedFirstValue4 = 5;
   if (actualFirstValue4.compareTo(expectedFirstValue4)!=0) {
       failFmt("add:\n"+
               "expectedFirstValue4: " + expectedFirstValue4 +"\n"+
               "actualFirstValue4: " + actualFirstValue4 + "");
   }

   ChainedArrays.ArrayNode node4 = C.getNode(4);

   int actualArraySize5 = node4.getArraySize();
   int expectedArraySize5 = 1;

   if(actualArraySize5 != expectedArraySize5) {
       failFmt("add:\n"+
               "expectedArraySize5: "+expectedArraySize5 +"\n"+
               "actualArraySize5: "+actualArraySize5+"\n"+"");
   }

   Comparable actualFirstValue5 = node4.getFirst();
   Integer expectedFirstValue5 = 6;
   if (actualFirstValue5.compareTo(expectedFirstValue5)!=0) {
       failFmt("add:\n"+
               "expectedFirstValue5: " + expectedFirstValue5 +"\n"+
               "actualFirstValue5: " + actualFirstValue5 + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_add10(){
  // test adding to empty ChainedArrays
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(1); // add 1 to first node
   C.add(4); // add 4 to first node
   C.add(2); // add 2 to  first node ==> [1,2] -> [4, ]
   C.add(2); // add 2 to  second node ==> [1,2]->[4, ] ==> [1, ]->[2, ]->4 ==> [1, ]->[2,2]->[4, ]
   /* In general, (current.getArraySize()+1)/2 elements are moved 
   from the current node to the new node. This means current.getArraySize()/2 
   elements remain in the current node. If the inserted data is less than the 
   minimum value in the new node, then data is inserted into the current node; 
   otherwise, data is inserted into the new node. In this test, data 2 is greater 
   than or equal to the minimum value 2 in the new node so 2 is inserted into the 
   new node. */

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("add:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);

   Comparable actualFirstValue1 = current.getFirst();
   Integer expectedFirstValue1 = 1;
   if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
       failFmt("add:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
   }

   ChainedArrays.ArrayNode node1 = C.getNode(1);

   Comparable actualFirstValue2 = node1.getFirst();
   Integer expectedFirstValue2 = 2;
   if (actualFirstValue2.compareTo(expectedFirstValue2) != 0) {
       failFmt("add:\n"+
               "expectedFirstValue2: " + expectedFirstValue2 +"\n"+
               "actualFirstValue2: " + actualFirstValue2 + "");
   }

   Comparable actualLastValue1 = node1.getLast();
   Integer expectedLastValue1 = 2;
   if (actualLastValue1.compareTo(expectedLastValue1) != 0) {
       failFmt("add:\n"+
               "expectedLastValue1: " + expectedLastValue1 +"\n"+
               "actualLastValue1: " + actualLastValue1 + "");
   }

   ChainedArrays.ArrayNode node2 = C.getNode(2);

   Comparable actualFirstValue3 = node2.getFirst();
   Integer expectedFirstValue3 = 4;
   if (actualFirstValue3.compareTo(expectedFirstValue3) != 0) {
       failFmt("add:\n"+
               "expectedFirstValue3: " + expectedFirstValue3 +"\n"+
               "actualFirstValue3: " + actualFirstValue3 + "");
   }
  }

// test ChainedArrays.contains

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_contains1(){
  // test contains - true for first data node
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);   //=> [1,2] --> [3,4] --> [5,6]

   boolean actualContains = C.contains(2);
	boolean expectedContains = true;

   if (actualContains != expectedContains) {
       failFmt("contains:\n"+
               "expectedContains: " + expectedContains +"\n"+
               "actualContains: " + actualContains + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_contains2(){
  // test contains - true for middle data node
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);   //=> [1,2] --> [3,4] --> [5,6]

   boolean actualContains = C.contains(3);
	boolean expectedContains = true;

   if (actualContains != expectedContains) {
       failFmt("contains:\n"+
               "expectedContains: " + expectedContains +"\n"+
               "actualContains: " + actualContains + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_contains3(){
  // test contains - true for last data node
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);   //=> [1,2] --> [3,4] --> [5,6]

   boolean actualContains = C.contains(6);
	boolean expectedContains = true;

   if (actualContains != expectedContains) {
       failFmt("contains:\n"+
               "expectedContains: " + expectedContains +"\n"+
               "actualContains: " + actualContains + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_contains4(){
  // test contains - false
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);   //=> [1,2] --> [3,4] --> [5,6]

   boolean actualContains = C.contains(7);
	boolean expectedContains = false;

   if (actualContains != expectedContains) {
       failFmt("contains:\n"+
               "expectedContains: " + expectedContains +"\n"+
               "actualContains: " + actualContains + "");
   }
  }

// tests for ChainedArrays.getMatch

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_getMatch1(){
  // test getMatch - match in first data node
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);   //=> [1,2] --> [3,4] --> [5,6]

   Comparable actualMatch = C.getMatch(2);
	Integer expectedMatch = 2;

   if (actualMatch.compareTo(expectedMatch) != 0) {
       failFmt("getMatch:\n"+
               "expectedMatch: " + expectedMatch +"\n"+
               "actualMatch: " + actualMatch + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_getMatch2(){
  // test getMatch - match in middle data node
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);  // => [1,2] --> [3,4] --> [5,6]

   Comparable actualMatch = C.getMatch(3);
	Integer expectedMatch = 3;

   if (actualMatch.compareTo(expectedMatch) != 0) {
       failFmt("getMatch:\n"+
               "expectedMatch: " + expectedMatch +"\n"+
               "actualMatch: " + actualMatch + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_getMatch3(){
  // test getMatch - match in last data node
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);   //=> [1,2] --> [3,4] --> [5,6]

   Comparable actualMatch = C.getMatch(6);
	Integer expectedMatch = 6;

   if (actualMatch.compareTo(expectedMatch) != 0) {
       failFmt("getMatch:\n"+
               "expectedMatch: " + expectedMatch +"\n"+
               "actualMatch: " + actualMatch + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_getMatch4(){
  // test getMatch - no match
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);   //=> [1,2] --> [3,4] --> [5,6]

   Comparable actualMatch = C.getMatch(7);
	Integer expectedMatch = null;

   if (actualMatch != expectedMatch) {
       failFmt("getMatch:\n"+
               "expectedMatch: " + expectedMatch +"\n"+
               "actualMatch: " + actualMatch + "");
   }
  }

// test ChainedArrays.getFirst

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_getFirst1(){
  // test getFirst 
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);  //=> [1,2] --> [3,4] --> [5,6]

   Comparable actualFirst = C.getFirst();
	Integer expectedFirst = 1;

   if (actualFirst.compareTo(expectedFirst) != 0) {
       failFmt("getFirst:\n"+
               "expectedFirst: " + expectedFirst +"\n"+
               "actualFirst: " + actualFirst + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_getFirst2(){
  // test getFirst on empty 
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   boolean thrown = false;
   try {Comparable actualFirst = C.getFirst();}
	catch (NoSuchElementException e) {
		thrown = true;;
	}
   if(!thrown) {
       failFmt("getFirst:\n"+
               "Expect: "+"NoSuchElementException" +"\n"+
               "Actual: "+"NoSuchElementException not thrown"+"\n"+"");
   }
  }

// test ChainedArrays.getLast

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_getLast1(){
  // test getLast 
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);  //=> [1,2] --> [3,4] --> [5,6]

   Comparable actualLast = C.getLast();
	Integer expectedLast = 6;

   if (actualLast.compareTo(expectedLast) != 0) {
       failFmt("getLast:\n"+
               "expectedLast: " + expectedLast +"\n"+
               "actualLast: " + actualLast + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_getLast2(){
  // test getLast on empty 
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   boolean thrown = false;
   try {Comparable actualFirst = C.getLast();}
	catch (NoSuchElementException e) {
		thrown = true;;
	}
   if(!thrown) {
       failFmt("getLast:\n"+
               "Expect: "+"NoSuchElementException" +"\n"+
               "Actual: "+"NoSuchElementException not thrown"+"\n"+"");
   }
  }

// Test ChainedArays iterator

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_iterator1() {
  // test iterator
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);  //=> [1,2] --> [3,4] --> [5,6]

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays Iterator:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }

	Iterator<Integer> i = C.iterator();

   boolean actualHasNext1 = i.hasNext();
	boolean expectedHasNext1 = true;
   if (actualHasNext1 != expectedHasNext1) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext1: " + expectedHasNext1 +"\n"+
               "actualHasNext1: " + actualHasNext1 + "");
   }
   Integer actualNext1 = i.next();
	Integer expectedNext1 = 1;
   if (actualNext1 != expectedNext1) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNext1: " + expectedNext1 +"\n"+
               "actualNext1: " + actualNext1 + "");
   }
	
   boolean actualHasNext2 = i.hasNext();
	boolean expectedHasNext2 = true;
   if (actualHasNext2 != expectedHasNext2) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext2: " + expectedHasNext2 +"\n"+
               "actualHasNext2: " + actualHasNext2 + "");
   }
   Integer actualNext2 = i.next();
	Integer expectedNext2 = 2;
   if (actualNext2 != expectedNext2) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNext2: " + expectedNext2 +"\n"+
               "actualNext2: " + actualNext2 + "");
   }

   boolean actualHasNext3 = i.hasNext();
	boolean expectedHasNext3 = true;
   if (actualHasNext3 != expectedHasNext3) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext3: " + expectedHasNext3 +"\n"+
               "actualHasNext3: " + actualHasNext3 + "");
   }
   Integer actualNext3 = i.next();
	Integer expectedNext3 = 3;
   if (actualNext3 != expectedNext3) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNext3: " + expectedNext3 +"\n"+
               "actualNext3: " + actualNext3 + "");
   }

   boolean actualHasNext4 = i.hasNext();
	boolean expectedHasNext4 = true;
   if (actualHasNext4 != expectedHasNext4) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext4: " + expectedHasNext4 +"\n"+
               "actualHasNext4: " + actualHasNext4 + "");
   }
   Integer actualNext4 = i.next();
	Integer expectedNext4 = 4;
   if (actualNext4 != expectedNext4) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNext4: " + expectedNext4 +"\n"+
               "actualNext4: " + actualNext4 + "");
   }

   boolean actualHasNext5 = i.hasNext();
	boolean expectedHasNext5 = true;
   if (actualHasNext5 != expectedHasNext5) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext5: " + expectedHasNext5 +"\n"+
               "actualHasNext5: " + actualHasNext5 + "");
   }
   Integer actualNext5 = i.next();
	Integer expectedNext5 = 5;
   if (actualNext5 != expectedNext5) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNext5: " + expectedNext5 +"\n"+
               "actualNext5: " + actualNext5 + "");
   }

   boolean actualHasNext6 = i.hasNext();
	boolean expectedHasNext6 = true;
   if (actualHasNext6 != expectedHasNext6) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext6: " + expectedHasNext6 +"\n"+
               "actualHasNext6: " + actualHasNext6 + "");
   }
   Integer actualNext6 = i.next();
	Integer expectedNext6 = 6;
   if (actualNext6 != expectedNext6) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNext6: " + expectedNext6 +"\n"+
               "actualNext6: " + actualNext6 + "");
   }

   boolean actualHasNext7 = i.hasNext();
	boolean expectedHasNext7 = false;
   if (actualHasNext7 != expectedHasNext7) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext7: " + expectedHasNext7 +"\n"+
               "actualHasNext7: " + actualHasNext7 + "");
   }
   }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_iterator2() {
  // test iterator
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	//C.add(4);
   C.add(5);  //=> [1,2] --> [3, ] --> [5,6]

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }

	Iterator<Integer> i = C.iterator();
	
   boolean actualHasNext1 = i.hasNext();
	boolean expectedHasNext1 = true;
   if (actualHasNext1 != expectedHasNext1) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext1: " + expectedHasNext1 +"\n"+
               "actualHasNext1: " + actualHasNext1 + "");
   }
   Integer actualNext1 = i.next();
	Integer expectedNext1 = 1;
   if (actualNext1 != expectedNext1) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNext1: " + expectedNext1 +"\n"+
               "actualNext1: " + actualNext1 + "");
   }
	
   boolean actualHasNext2 = i.hasNext();
	boolean expectedHasNext2 = true;
   if (actualHasNext2 != expectedHasNext2) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext2: " + expectedHasNext2 +"\n"+
               "actualHasNext2: " + actualHasNext2 + "");
   }
   Integer actualNext2 = i.next();
	Integer expectedNext2 = 2;
   if (actualNext2 != expectedNext2) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNext2: " + expectedNext2 +"\n"+
               "actualNext2: " + actualNext2 + "");
   }

   boolean actualHasNext3 = i.hasNext();
	boolean expectedHasNext3 = true;
   if (actualHasNext3 != expectedHasNext3) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext3: " + expectedHasNext3 +"\n"+
               "actualHasNext3: " + actualHasNext3 + "");
   }
   Integer actualNext3 = i.next();
	Integer expectedNext3 = 3;
   if (actualNext3 != expectedNext3) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNext3: " + expectedNext3 +"\n"+
               "actualNext3: " + actualNext3 + "");
   }

   // no value 4

   boolean actualHasNext5 = i.hasNext();
	boolean expectedHasNext5 = true;
   if (actualHasNext5 != expectedHasNext5) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext5: " + expectedHasNext5 +"\n"+
               "actualHasNext5: " + actualHasNext5 + "");
   }
   Integer actualNext5 = i.next();
	Integer expectedNext5 = 5;
   if (actualNext5 != expectedNext5) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNext5: " + expectedNext5 +"\n"+
               "actualNext5: " + actualNext5 + "");
   }

   boolean actualHasNext6 = i.hasNext();
	boolean expectedHasNext6 = true;
   if (actualHasNext6 != expectedHasNext6) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext6: " + expectedHasNext6 +"\n"+
               "actualHasNext6: " + actualHasNext6 + "");
   }
   Integer actualNext6 = i.next();
	Integer expectedNext6 = 6;
   if (actualNext6 != expectedNext6) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNext6: " + expectedNext6 +"\n"+
               "actualNext6: " + actualNext6 + "");
   }

   boolean actualHasNext7 = i.hasNext();
	boolean expectedHasNext7 = false;
   if (actualHasNext7 != expectedHasNext7) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext7: " + expectedHasNext7 +"\n"+
               "actualHasNext7: " + actualHasNext7 + "");
   }
   }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_iterator3() {
  // test iterator
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(1);
   C.add(2); //=> [1,2]

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 1;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }

	Iterator<Integer> i = C.iterator();

   boolean actualHasNext1 = i.hasNext();
	boolean expectedHasNext1 = true;
   if (actualHasNext1 != expectedHasNext1) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext1: " + expectedHasNext1 +"\n"+
               "actualHasNext1: " + actualHasNext1 + "");
   }
   Integer actualNext1 = i.next();
	Integer expectedNext1 = 1;
   if (actualNext1 != expectedNext1) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNext1: " + expectedNext1 +"\n"+
               "actualNext1: " + actualNext1 + "");
   }
	
   boolean actualHasNext2 = i.hasNext();
	boolean expectedHasNext2 = true;
   if (actualHasNext2 != expectedHasNext2) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext2: " + expectedHasNext2 +"\n"+
               "actualHasNext2: " + actualHasNext2 + "");
   }
   Integer actualNext2 = i.next();
	Integer expectedNext2 = 2;
   if (actualNext2 != expectedNext2) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNext2: " + expectedNext2 +"\n"+
               "actualNext2: " + actualNext2 + "");
   }

   boolean actualHasNext3 = i.hasNext();
	boolean expectedHasNext3 = false;
   if (actualHasNext3 != expectedHasNext3) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext3: " + expectedHasNext3 +"\n"+
               "actualHasNext3: " + actualHasNext3 + "");
   }
   }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_iterator4() {
  // test iterator
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(1); //=> [1, ]

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 1;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }

	Iterator<Integer> i = C.iterator();

   boolean actualHasNext1 = i.hasNext();
	boolean expectedHasNext1 = true;
   if (actualHasNext1 != expectedHasNext1) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext1: " + expectedHasNext1 +"\n"+
               "actualHasNext1: " + actualHasNext1 + "");
   }
   Integer actualNext1 = i.next();
	Integer expectedNext1 = 1;
   if (actualNext1 != expectedNext1) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNext1: " + expectedNext1 +"\n"+
               "actualNext1: " + actualNext1 + "");
   }
	
   boolean actualHasNext2 = i.hasNext();
	boolean expectedHasNext2 = false;
   if (actualHasNext2 != expectedHasNext2) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext2: " + expectedHasNext2 +"\n"+
               "actualHasNext2: " + actualHasNext2 + "");
   }
   }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_iterator5() {
  // test getNode(idx, lower,upper) out of range
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(1);
   C.add(1);
   C.add(2); //=> [1] --> [2]

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 2;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }

	Iterator<Integer> i = C.iterator();

   boolean actualHasNext1 = i.hasNext();
	boolean expectedHasNext1 = true;
   if (actualHasNext1 != expectedHasNext1) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext1: " + expectedHasNext1 +"\n"+
               "actualHasNext1: " + actualHasNext1 + "");
   }
   Integer actualNext1 = i.next();
	Integer expectedNext1 = 1;
   if (actualNext1 != expectedNext1) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNext1: " + expectedNext1 +"\n"+
               "actualNext1: " + actualNext1 + "");
   }
	
   boolean actualHasNext2 = i.hasNext();
	boolean expectedHasNext2 = true;
   if (actualHasNext2 != expectedHasNext2) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext2: " + expectedHasNext2 +"\n"+
               "actualHasNext2: " + actualHasNext2 + "");
   }
   Integer actualNext2 = i.next();
	Integer expectedNext2 = 2;
   if (actualNext2 != expectedNext2) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedNext2: " + expectedNext2 +"\n"+
               "actualNext2: " + actualNext2 + "");
   }

   boolean actualHasNext3 = i.hasNext();
	boolean expectedHasNext3 = false;
   if (actualHasNext3 != expectedHasNext3) {
       failFmt("ChainedArrays iterator:\n"+
               "expectedHasNext3: " + expectedHasNext3 +"\n"+
               "actualHasNext3: " + actualHasNext3 + "");
   }
   }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_iterator6() {
  // test iterator
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);

	Iterator<Integer> i = C.iterator();
   boolean thrown = false;
   boolean hasN = i.hasNext();
   C.add(4);
   try {i.hasNext();}
   catch (ConcurrentModificationException e) {
      thrown = true;
   }

   boolean actualThrown = thrown;
   boolean expectedThrown = true;
   if(!thrown) {
       failFmt("ChainedArrays iterator:\n"+
               "Expect: "+"ConcurrentModificationException" +"\n"+
               "Actual: "+"ConcurrentModificationException not thrown"+"\n"+"");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_iterator7() {
  // test iterator
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);

	Iterator<Integer> i = C.iterator();
   boolean thrown = false;
   boolean hasN = i.hasNext();
   C.remove(3);
   try {i.hasNext();}
   catch (ConcurrentModificationException e) {
      thrown = true;
   }

   boolean actualThrown = thrown;
   boolean expectedThrown = true; 
   if(!thrown) {
       failFmt("ChainedArrays iterator:\n"+
               "Expect: "+"ConcurrentModificationException" +"\n"+
               "Actual: "+"ConcurrentModificationException not thrown"+"\n"+"");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_iterator8() {
  // test iterator
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);

	Iterator<Integer> i = C.iterator();
   boolean thrown = false;
   boolean hasN = i.hasNext();
   C.remove(4);
   try {i.hasNext();}
   catch (ConcurrentModificationException e) {
      thrown = true;
   }

   boolean actualThrown = thrown;
   boolean expectedThrown = false;  // remove(4) did not modify C
   if(thrown) {
       failFmt("ChainedArrays iterator:\n"+
               "Expect: "+"ConcurrentModificationException" +"\n"+
               "Actual: "+"ConcurrentModificationException not thrown"+"\n"+"");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_iterator9() {
  // test iterator
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);

	Iterator<Integer> i = C.iterator();
   boolean thrown = false;
   boolean hasN = i.hasNext();
   C.removeFirst();
   try {i.hasNext();}
   catch (ConcurrentModificationException e) {
      thrown = true;
   }

   boolean actualThrown = thrown;
   boolean expectedThrown = true;  // remove(4) did not modify C
   if(!thrown) {
       failFmt("ChainedArrays iterator:\n"+
               "Expect: "+"ConcurrentModificationException" +"\n"+
               "Actual: "+"ConcurrentModificationException not thrown"+"\n"+"");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_iterator10() {
  // test iterator
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);

	Iterator<Integer> i = C.iterator();
   boolean thrown = false;
   boolean hasN = i.hasNext();
   C.removeLast();
   try {i.hasNext();}
   catch (ConcurrentModificationException e) {
      thrown = true;
   }

   boolean actualThrown = thrown;
   boolean expectedThrown = true;  // remove(4) did not modify C
   if(!thrown) {
       failFmt("ChainedArrays iterator:\n"+
               "Expect: "+"ConcurrentModificationException" +"\n"+
               "Actual: "+"ConcurrentModificationException not thrown"+"\n"+"");
   }
  }



// test ChainedArrays.equals

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_equals1(){
  // test equals true 
   ChainedArrays<Integer> C1 = new ChainedArrays<Integer>(2);
   C1.add(2);
   C1.add(3);
   C1.add(1); 
   C1.add(6);
	C1.add(4);
   C1.add(5);  //=> [1,2] --> [3,4] --> [5,6]
   ChainedArrays<Integer> C2 = new ChainedArrays<Integer>(2);
   C2.add(2);
   C2.add(3);
   C2.add(1); 
   C2.add(6);
	C2.add(4);
   C2.add(5);  //=> [1,2] --> [3,4] --> [5,6]


   boolean actualEquals = C1.equals(C2);
	boolean expectedEquals = true;

   if (actualEquals != expectedEquals) {
       failFmt("ChainedArrays equals:\n"+
               "expectedEquals: " + expectedEquals +"\n"+
               "actualEquals: " + actualEquals + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_equals2(){
  // test equals false 
   ChainedArrays<Integer> C1 = new ChainedArrays<Integer>(2);
   C1.add(2);
   C1.add(3);
   C1.add(1); 
   C1.add(6);
	C1.add(4);
   C1.add(5);  //=> [1,2] --> [3,4] --> [5,6]
   ChainedArrays<Integer> C2 = new ChainedArrays<Integer>(2);
   C2.add(2);
   C2.add(3);
   C2.add(1); 
   C2.add(6);
	C2.add(4);
   //C2.add(5); 


   boolean actualEquals = C1.equals(C2);
	boolean expectedEquals = false;

   if (actualEquals != expectedEquals) {
       failFmt("ChainedArrays equals:\n"+
               "expectedEquals: " + expectedEquals +"\n"+
               "actualEquals: " + actualEquals + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_equals3(){
  // test equals false 
   ChainedArrays<Integer> C1 = new ChainedArrays<Integer>(2);
   C1.add(2);
   C1.add(3);
   C1.add(1); 
   C1.add(6);
	C1.add(4);
   C1.add(5);  //=> [1,2] --> [3,4] --> [5,6]
   ChainedArrays<Integer> C2 = new ChainedArrays<Integer>(2);
   C2.add(2);
   C2.add(3);
   //C2.add(1); 
   C2.add(6);
	C2.add(4);
   C2.add(5);


   boolean actualEquals = C1.equals(C2);
	boolean expectedEquals = false;

   if (actualEquals != expectedEquals) {
       failFmt("ChainedArrays equals:\n"+
               "expectedEquals: " + expectedEquals +"\n"+
               "actualEquals: " + actualEquals + "");
   }
  }

// test ChainedArrays.isEqual

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_isEqual1(){
  // test isEqual true 
   ChainedArrays<Integer> C1 = new ChainedArrays<Integer>(2);
   C1.add(2);
   C1.add(3);
   C1.add(1); 
   C1.add(6);
	C1.add(4);
   C1.add(5);  //=> [1,2] --> [3,4] --> [5,6]
   ChainedArrays<Integer> C2 = new ChainedArrays<Integer>(2);
   C2.add(2);
   C2.add(3);
   C2.add(1); 
   C2.add(6);
	C2.add(4);
   C2.add(5);  //=> [1,2] --> [3,4] --> [5,6]


   boolean actualEquals = C1.isEqual(C1,C2);
	boolean expectedEquals = true;

   if (actualEquals != expectedEquals) {
       failFmt("ChainedArrays isEqual:\n"+
               "expectedEquals: " + expectedEquals +"\n"+
               "actualEquals: " + actualEquals + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_isEqual2(){
  // test isEqual false 
   ChainedArrays<Integer> C1 = new ChainedArrays<Integer>(2);
   C1.add(2);
   C1.add(3);
   C1.add(1); 
   C1.add(6);
	C1.add(4);
   C1.add(5);  //=> [1,2] --> [3,4] --> [5,6]
   ChainedArrays<Integer> C2 = new ChainedArrays<Integer>(2);
   C2.add(2);
   C2.add(3);
   C2.add(1); 
   C2.add(6);
	C2.add(4);
   //C2.add(5); 


   boolean actualEquals = C1.isEqual(C1,C2);
	boolean expectedEquals = false;

   if (actualEquals != expectedEquals) {
       failFmt("ChainedArrays isEqual:\n"+
               "expectedEquals: " + expectedEquals +"\n"+
               "actualEquals: " + actualEquals + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_isEqual3(){
  // test isEqual false : isEqual(null,non-null)
   ChainedArrays<Integer> C1 = new ChainedArrays<Integer>(2);
   C1.add(2);
   C1.add(3);
   C1.add(1); 
   C1.add(6);
	C1.add(4);
   C1.add(5);  //=> [1,2] --> [3,4] --> [5,6]
   ChainedArrays<Integer> C2 = null;


   boolean actualEquals = C1.isEqual(C1,C2);
	boolean expectedEquals = false;

   if (actualEquals != expectedEquals) {
       failFmt("ChainedArrays isEqual:\n"+
               "expectedEquals: " + expectedEquals +"\n"+
               "actualEquals: " + actualEquals + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_isEqual4(){
  // test isEqual false : isEqual(null,non-null)
   ChainedArrays<Integer> C1 = new ChainedArrays<Integer>(2);
   C1.add(2);
   C1.add(3);
   C1.add(1); 
   C1.add(6);
	C1.add(4);
   C1.add(5);  //=> [1,2] --> [3,4] --> [5,6]
   ChainedArrays<Integer> C2 = null;

   boolean actualEquals = C1.isEqual(C2,C1);
	boolean expectedEquals = false;

   if (actualEquals != expectedEquals) {
       failFmt("ChainedArrays isEqual:\n"+
               "expectedEquals: " + expectedEquals +"\n"+
               "actualEquals: " + actualEquals + "");
   }
  }




// test ChainedArrays.addAll

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_addAll1(){
  // test addAll: add from ArrayList
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(4);
   ArrayList<Integer> L = new ArrayList<Integer>(4);
   L.add(4);
   L.add(3);
   L.add(2);
   L.add(1);
	C.addAll(L);

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 1;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays addAll:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);

   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 4;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("ChainedArrays addAll:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }
	
   Object[] actual = current.getArray();
   Object[] expect = {1,2,3,4};
    if(!Arrays.deepEquals(actual,expect)){
       failFmt("ChainedArrays addAll:\n"+
               "Expect: "+printArray(expect) +"\n"+
               "Actual: "+printArray(actual)+"\n"+"");
    }
  }

//ChainedArrays.removeFirst

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_removeFirst1(){
  // test removeFirst - no compress 
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);  //=> [1,2] --> [3,4] --> [5,6]

   Comparable actualFirst = C.removeFirst();
	Integer expectedFirst = 1;

   if (actualFirst.compareTo(expectedFirst) != 0) {
       failFmt("ChainedArrays removeFirst:\n"+
               "expectedFirst: " + expectedFirst +"\n"+
               "actualFirst: " + actualFirst + "");
   }

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays removeFirst:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);

   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 1;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("ChainedArrays removeFirst:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }
	
   Comparable actualFirst2 = current.getFirst();
   Integer expectedFirst2 = 2;
   if (actualFirst2.compareTo(expectedFirst2) != 0) {
       failFmt("ChainedArrays removeFirst:\n"+
               "expectedFirst2: " + expectedFirst2 +"\n"+
               "actualFirst2: " + actualFirst2 + "");
   }
  }


  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_removeFirst2(){
  // test getFirst on empty 
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   boolean thrown = false;
   try {Comparable actualFirst = C.removeFirst();}
	catch (NoSuchElementException e) {
		thrown = true;;
	}
   if(!thrown) {
       failFmt("ChainedArrays removeFirst:\n"+
               "Expect: "+"NoSuchElementException" +"\n"+
               "Actual: "+"NoSuchElementException not thrown"+"\n"+"");
   }
  }

//ChainedArrays.removeLast

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_removeLast1(){
  // test removeFirst - no compress 
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);  //=> [1,2] --> [3,4] --> [5,6]

   Comparable actualLast = C.removeLast();
	Integer expectedLast = 6;

   if (actualLast.compareTo(expectedLast) != 0) {
       failFmt("ChainedArrays removeLast:\n"+
               "expectedLast: " + expectedLast +"\n"+
               "actualLast: " + actualLast + "");
   }

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays removeLast:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(2);

   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 1;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("ChainedArrays removeLast:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }
	
   Comparable actualLast2 = current.getFirst();
   Integer expectedLast2 = 5;
   if (actualLast2.compareTo(expectedLast2) != 0) {
       failFmt("ChainedArrays removeLast:\n"+
               "expectedLast2: " + expectedLast2 +"\n"+
               "actualLast2: " + actualLast2 + "");
   }
  }


  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_removeLast2(){
  // test getFirst on empty 
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   boolean thrown = false;
   try {Comparable actualFirst = C.removeLast();}
	catch (NoSuchElementException e) {
		thrown = true;;
	}
   if(!thrown) {
       failFmt("ChainedArrays removeLast:\n"+
               "Expect: "+"NoSuchElementException" +"\n"+
               "Actual: "+"NoSuchElementException not thrown"+"\n"+"");
   }
  }

// test ChainedArrays.remove

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_remove1(){
  // test remove - no compress 
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);  //=> [1,2] --> [3,4] --> [5,6]

   Comparable actualLast = C.remove(5);
	Integer expectedLast = 5;

   if (actualLast.compareTo(expectedLast) != 0) {
       failFmt("ChainedArrays remove:\n"+
               "expectedLast: " + expectedLast +"\n"+
               "actualLast: " + actualLast + "");
   }

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays remove:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(2);

   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 1;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("ChainedArrays remove:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }
	
   Comparable actualLast2 = current.getFirst();
   Integer expectedLast2 = 6;
   if (actualLast2.compareTo(expectedLast2) != 0) {
       failFmt("ChainedArrays remove:\n"+
               "expectedLast2: " + expectedLast2 +"\n"+
             "actualLast2: " + actualLast2 + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_remove2(){
  // test remove - no compress 
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);  //=> [1,2] --> [3,4] --> [5,6]

   Comparable actualLast = C.remove(4);
	Integer expectedLast = 4;

   if (actualLast.compareTo(expectedLast) != 0) {
       failFmt("ChainedArrays remove:\n"+
               "expectedLast: " + expectedLast +"\n"+
               "actualLast: " + actualLast + "");
   }

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays remove:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(1);

   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 1;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("ChainedArrays remove:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }
	
   Comparable actualLast2 = current.getFirst();
   Integer expectedLast2 = 3;
   if (actualLast2.compareTo(expectedLast2) != 0) {
       failFmt("ChainedArrays remove:\n"+
               "expectedLast2: " + expectedLast2 +"\n"+
               "actualLast2: " + actualLast2 + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_remove3(){
  // test remove - no compress 
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);  //=> [1,2] --> [3,4] --> [5,6]

   Comparable actualLast = C.remove(2);
	Integer expectedLast = 2;

   if (actualLast.compareTo(expectedLast) != 0) {
       failFmt("ChainedArrays remove:\n"+
               "expectedLast: " + expectedLast +"\n"+
               "actualLast: " + actualLast + "");
   }

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays remove:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);

   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 1;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("ChainedArrays remove:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }
	
   Comparable actualLast2 = current.getFirst();
   Integer expectedLast2 = 1;
   if (actualLast2.compareTo(expectedLast2) != 0) {
       failFmt("ChainedArrays remove:\n"+
               "expectedLast2: " + expectedLast2 +"\n"+
               "actualLast2: " + actualLast2 + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_remove4(){
  // test remove - not found so return null
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(3);
   C.add(5);
   C.add(1); 
   C.add(9);
	C.add(7);
   C.add(8);  //=> [1,3] --> [5,7] --> [8,9]

   Comparable actualLast = C.remove(6);
	Integer expectedLast = null;

   if (actualLast != expectedLast) {
       failFmt("ChainedArrays remove:\n"+
               "expectedLast: " + expectedLast +"\n"+
               "actualLast: " + actualLast + "");
   }

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays emove:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(1);

   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 2;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("ChainedArrays remove:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_remove5(){
  // test remove - not found so return null
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(3);
   C.add(5);
   C.add(1); 
   C.add(9);
	C.add(7);
   C.add(8);  //=> [1,3] --> [5,7] --> [8,9]


   Comparable actualLast = C.remove(10);
	Integer expectedLast = null;

   if (actualLast != expectedLast) {
       failFmt("ChainedArrays remove:\n"+
               "expectedLast: " + expectedLast +"\n"+
               "actualLast: " + actualLast + "");
   }

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays remove:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(1);

   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 2;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("ChainedArrays remove:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_remove6(){
  // test remove -  node becomes empty so remove node
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(3);
   C.add(5);
   C.add(1); 
   C.add(9);
	C.add(7);
   C.add(8);  //=> [1,3] --> [5,7] --> [8,9]

   Comparable actualLast = C.remove(1);
   actualLast = C.remove(3);

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 2;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays remove:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);

   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 2;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("ChainedArrays remove:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }

   Object[] actual1 = current.getArray();
   Object[] expect1 = {5,7};
    if(!Arrays.deepEquals(actual1,expect1)){
       failFmt("ChainedArrays remove:\n"+
               "Expect1: "+printArray(expect1) +"\n"+
               "Actual1: "+printArray(actual1)+"\n"+"");
    }

   current = C.getNode(1);

   int actualArraySize2 = current.getArraySize();
   int expectedArraySize2 = 2;

   if(actualArraySize2 != expectedArraySize2) {
       failFmt("ChainedArrays remove:\n"+
               "expectedArraySize2: "+expectedArraySize2 +"\n"+
               "actualArraySize2: "+actualArraySize2+"\n"+"");
   }

   Object[] actual2 = current.getArray();
   Object[] expect2 = {8,9};
    if(!Arrays.deepEquals(actual2,expect2)){
       failFmt("ChainedArrays remove:\n"+
               "Expect2: "+printArray(expect2) +"\n"+
               "Actual2: "+printArray(actual2)+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_remove7(){
  // test remove -  node becomes empty so remove node
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(3);
   C.add(5);
   C.add(1); 
   C.add(9);
	C.add(7);
   C.add(8);  //=> [1,3] --> [5,7] --> [8,9]

   Comparable actualLast = C.remove(5);
   actualLast = C.remove(7);

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 2;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays remove:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);

   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 2;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("ChainedArrays remove:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }

   Object[] actual1 = current.getArray();
   Object[] expect1 = {1,3};
    if(!Arrays.deepEquals(actual1,expect1)){
       failFmt("ChainedArrays remove:\n"+
               "Expect1: "+printArray(expect1) +"\n"+
               "Actual1: "+printArray(actual1)+"\n"+"");
    }

   current = C.getNode(1);

   int actualArraySize2 = current.getArraySize();
   int expectedArraySize2 = 2;

   if(actualArraySize2 != expectedArraySize2) {
       failFmt("ChainedArrays remove:\n"+
               "expectedArraySize2: "+expectedArraySize2 +"\n"+
               "actualArraySize2: "+actualArraySize2+"\n"+"");
   }

   Object[] actual2 = current.getArray();
   Object[] expect2 = {8,9};
    if(!Arrays.deepEquals(actual2,expect2)){
       failFmt("ChainedArrays remove:\n"+
               "Expect2: "+printArray(expect2) +"\n"+
               "Actual2: "+printArray(actual2)+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_remove8(){
  // test remove -  node becomes empty so remove node
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(3);
   C.add(5);
   C.add(1); 
   C.add(9);
	C.add(7);
   C.add(8);  //=> [1,3] --> [5,7] --> [8,9]

   Comparable actualLast = C.remove(8);
   actualLast = C.remove(9);

   int actualNumberNodes = C.nodeCount();
   int expectedNumberNodes = 2;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays remove:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
   ChainedArrays.ArrayNode current = C.getNode(0);

   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 2;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("ChainedArrays remove:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }

   Object[] actual1 = current.getArray();
   Object[] expect1 = {1,3};
    if(!Arrays.deepEquals(actual1,expect1)){
       failFmt("ChainedArrays remove:\n"+
               "Expect1: "+printArray(expect1) +"\n"+
               "Actual1: "+printArray(actual1)+"\n"+"");
    }

   current = C.getNode(1);

   int actualArraySize2 = current.getArraySize();
   int expectedArraySize2 = 2;

   if(actualArraySize2 != expectedArraySize2) {
       failFmt("ChainedArrays remove:\n"+
               "expectedArraySize2: "+expectedArraySize2 +"\n"+
               "actualArraySize2: "+actualArraySize2+"\n"+"");
   }

   Object[] actual2 = current.getArray();
   Object[] expect2 = {5,7};
    if(!Arrays.deepEquals(actual2,expect2)){
       failFmt("ChainedArrays remove:\n"+
               "Expect2: "+printArray(expect2) +"\n"+
               "Actual2: "+printArray(actual2)+"\n"+"");
    }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_remove9(){
  // test remove - no compress 
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);  //=> [1,2] --> [3,4] --> [5,6]

   Comparable actualLast = C.remove(2);
   actualLast = C.remove(4);
   actualLast = C.remove(5);

   int actualNumberNodes = C.nodeCount(); //no compression
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays remove:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_remove10(){
  // test remove - no compress 
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(2);
   C.add(3);
   C.add(1); 
   C.add(6);
	C.add(4);
   C.add(5);  //=> [1,2] --> [3,4] --> [5,6]

   Comparable actualLast = C.remove(2);
   actualLast = C.remove(4);
   actualLast = C.remove(5);
   actualLast = C.remove(6); // node [5,6] is removed so no compression is needed

   int actualNumberNodes = C.nodeCount(); //no compression
   int expectedNumberNodes = 2;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("ChainedArrays remove:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }

   ChainedArrays.ArrayNode current = C.getNode(0);

   int actualArraySize1 = current.getArraySize();
   int expectedArraySize1 = 1;

   if(actualArraySize1 != expectedArraySize1) {
       failFmt("ChainedArrays remove:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
   }

   Comparable actualLast2 = current.getLast();
   Integer expectedLast2 = 1;
   if (actualLast2.compareTo(expectedLast2) != 0) {
       failFmt("ChainedArrays remove:\n"+
               "expectedLast2: " + expectedLast2 +"\n"+
               "actualLast2: " + actualLast2 + "");
   }

   current = C.getNode(1);

   int actualArraySize2 = current.getArraySize();
   int expectedArraySize2 = 1;

   if(actualArraySize2 != expectedArraySize2) {
       failFmt("ChainedArrays remove:\n"+
               "expectedArraySize2: "+expectedArraySize2 +"\n"+
               "actualArraySize2: "+actualArraySize2+"\n"+"");
   }

   Comparable actualLast3 = current.getLast();
   Integer expectedLast3 = 3;
   if (actualLast3.compareTo(expectedLast3) != 0) {
       failFmt("ChainedArrays remove:\n"+
               "expectedLast3: " + expectedLast3 +"\n"+
               "actualLast3: " + actualLast3 + "");
   }
  }


// test ChainedArrays.toString

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_toString1() {
  // test getNode(idx, lower,upper) out of range
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(3);
   C.add(1);
   C.add(4);
   C.add(6); 
   C.add(7);
	C.add(5);
   C.add(8);  //=> | 1 | --> | 4, 5 | --> | 6, 7, 8|

   // ignore differences in white space, e.g., |1,2| equals | 1, 2 |
   String actualString = C.toString().replaceAll("\\s+",""); // removes all whitespaces and non visible characters
   String expectedString = "|1|4,5|6,7,8|";
   if (!actualString.equals(expectedString)) {
       failFmt("ChainedArrays toString:\n"+
               "expectedString: " + expectedString +"\n"+
               "actualString: " + actualString + "");
   }
   }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_toString2() {
  // test getNode(idx, lower,upper) out of range
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(3);
   C.add(1); //=> | 1 | 

   // ignore differences in white space, e.g., |1,2| equals | 1, 2 |
   String actualString = C.toString().replaceAll("\\s+",""); // removes all whitespaces and non visible characters
   String expectedString = "|1|";
   if (!actualString.equals(expectedString)) {
       failFmt("ChainedArrays toString:\n"+
               "expectedString: " + expectedString +"\n"+
               "actualString: " + actualString + "");
   }
   }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_toString3() {
  // test getNode(idx, lower,upper) out of range
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(2);
   C.add(1); 
   C.add(3);
   C.add(4); 
	C.add(2); 
   C.remove(4);
   //=> | 1, 2 | --> | 3 |

   // ignore differences in white space, e.g., |1,2| equals | 1, 2 |
   String actualString = C.toString().replaceAll("\\s+",""); // removes all whitespaces and non visible characters
   String expectedString = "|1,2|3|";
   if (!actualString.equals(expectedString)) {
       failFmt("ChainedArrays toString:\n"+
               "expectedString: " + expectedString +"\n"+
               "actualString: " + actualString + "");
   }
   }

// test ChainedArrays.remove with compression


  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_removeWithCompression1() {
  // test getNode(idx, lower,upper) out of range
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(3);
   C.add(1); 
   C.add(4); 
   C.add(7); 
   C.add(8);
   C.add(2);
   C.add(3);   
   C.add(5);
   C.add(6);
   C.add(9); //=> | 1, 2, 3 | --> | 4, 5, 6 | -> | 7, 8, 9 |

   C.remove(6);
   C.remove(3);
   C.remove(5);
   C.remove(2); //=> | 1, ,  | --> | 4, ,  | -> | 7, 8, 9 |

   int actualNumberNodes = C.nodeCount(); //no compression
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("remove with compression:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }

   C.remove(7); //=> | 1, ,  | --> | 4, ,  | -> | 8, 9,  |
   // 4 elements stored in space for 9 ==> compress

   int actualNumberNodes2 = C.nodeCount();
   int expectedNumberNodes2 = 2;
   if (actualNumberNodes2 != expectedNumberNodes2) {
       failFmt("remove with compression:\n"+
               "expectedNumberNodes2: " + expectedNumberNodes2 +"\n"+
               "actualNumberNodes2: " + actualNumberNodes2 + "");
   }

   // ignore differences in white space, e.g., |1,4| equals | 1, 4 |
   String actualString = C.toString().replaceAll("\\s+",""); // removes all whitespaces and non visible characters
   String expectedString = "|1,4,8|9|";
   if (!actualString.equals(expectedString)) {
       failFmt("remove with compression:\n"+
               "expectedString: " + expectedString +"\n"+
               "actualString: " + actualString + "");
   }
   }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_removeWithCompression2() {
  // test getNode(idx, lower,upper) out of range
   ChainedArrays<Integer> C = new ChainedArrays<Integer>(3);
   C.add(1); 
   C.add(4); 
   C.add(7); 
   C.add(8);
   C.add(2);
   C.add(3);   
   C.add(5);
   C.add(6);
   C.add(9); //=> | 1, 2, 3 | --> | 4, 5, 6 | -> | 7, 8, 9 |

   C.remove(9);
   C.remove(6);
   C.remove(3);  //=> | 1, 2,  | --> | 4, 5,  | -> | 7, 8,  |
   C.remove(5);  //=> | 1, 2,  | --> | 4,  ,  | -> | 7, 8,  |

   int actualNumberNodes = C.nodeCount(); //no compression
   int expectedNumberNodes = 3;
   if (actualNumberNodes != expectedNumberNodes) {
       failFmt("remove with compression:\n"+
               "expectedNumberNodes: " + expectedNumberNodes +"\n"+
               "actualNumberNodes: " + actualNumberNodes + "");
   }

   C.remove(2);     C.remove(2);  //=> | 1,  ,  | --> | 4,  ,  | -> | 7, 8,  |
   // 4 elements stored in space for 3*3 ==> compress

   int actualNumberNodes2 = C.nodeCount(); //no compression
   int expectedNumberNodes2 = 2;
   if (actualNumberNodes2 != expectedNumberNodes2) {
       failFmt("remove with compression:\n"+
               "expectedNumberNodes2: " + expectedNumberNodes2 +"\n"+
               "actualNumberNodes2: " + actualNumberNodes2 + "");
   }

   // ignore differences in white space, e.g., |1,4| equals | 1, 4 |
   String actualString = C.toString().replaceAll("\\s+",""); // removes all whitespaces and non visible characters
   String expectedString = "|1,4,7|8|";
   if (!actualString.equals(expectedString)) {
       failFmt("remove with compression:\n"+
               "expectedString: " + expectedString +"\n"+
               "actualString: " + actualString + "");
   }
   }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_convenience_constructor1() {
  // test getNode(idx, lower,upper) out of range
  ChainedArrays<Integer> C = new ChainedArrays<Integer>();
  C.add(1); 
  ChainedArrays.ArrayNode n = C.getNode(0);
  Object[] array = n.getArray();
  int actualDefaultCapacity = array.length;
  int expectedDefaultCapacity = 16;

  if(actualDefaultCapacity != expectedDefaultCapacity) {
       failFmt("ChainedArrays convenience constructor:\n"+
               "expectedDefaultCapacity: "+expectedDefaultCapacity +"\n"+
               "actualDefaultCapacity: "+actualDefaultCapacity+"\n"+"");
  }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_isEmpty1() {
  // test getNode(idx, lower,upper) out of range
  ChainedArrays<Integer> C = new ChainedArrays<Integer>();
  boolean actualIsEmpty = C.isEmpty();
  boolean expectedIsEmpty = true;

  if(actualIsEmpty != expectedIsEmpty) {
       failFmt("ChainedArrays isEmpty:\n"+
               "expectedIsEmpty: "+expectedIsEmpty +"\n"+
               "actualIsEmpty: "+actualIsEmpty+"\n"+"");
  }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_isEmpty2() {
  // test getNode(idx, lower,upper) out of range
  ChainedArrays<Integer> C = new ChainedArrays<Integer>();
  C.add(1);
  boolean actualIsEmpty = C.isEmpty();
  boolean expectedIsEmpty = false;

  if(actualIsEmpty != expectedIsEmpty) {
       failFmt("ChainedArrays isEmpty:\n"+
               "expectedIsEmpty: "+expectedIsEmpty +"\n"+
               "actualIsEmpty: "+actualIsEmpty+"\n"+"");
  }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_size1() {
  // test getNode(idx, lower,upper) out of range
  ChainedArrays<Integer> C = new ChainedArrays<Integer>();
  int actualsize = C.size();
  int expectedsize = 0;

  if(actualsize != expectedsize) {
       failFmt("ChainedArrays size:\n"+
               "expectedsize: "+expectedsize +"\n"+
               "actualsize: "+actualsize+"\n"+"");
  }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_size2() {
  // test getNode(idx, lower,upper) out of range
  ChainedArrays<Integer> C = new ChainedArrays<Integer>();
  C.add(1);
  int actualsize = C.size();
  int expectedsize = 1;

  if(actualsize != expectedsize) {
       failFmt("ChainedArrays size:\n"+
               "expectedsize: "+expectedsize +"\n"+
               "actualsize: "+actualsize+"\n"+"");
  }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_size3() {
  // test getNode(idx, lower,upper) out of range
  ChainedArrays<Integer> C = new ChainedArrays<Integer>();
  C.add(1);
  C.remove(1);
  int actualsize = C.size();
  int expectedsize = 0;

  if(actualsize != expectedsize) {
       failFmt("ChainedArrays size:\n"+
               "expectedsize: "+expectedsize +"\n"+
               "actualsize: "+actualsize+"\n"+"");
  }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_size4() {
  // test getNode(idx, lower,upper) out of range
  ChainedArrays<Integer> C = new ChainedArrays<Integer>();
  C.add(1);
  C.removeFirst();
  int actualsize = C.size();
  int expectedsize = 0;

  if(actualsize != expectedsize) {
       failFmt("ChainedArrays size:\n"+
               "expectedsize: "+expectedsize +"\n"+
               "actualsize: "+actualsize+"\n"+"");
  }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_size5() {
  // test getNode(idx, lower,upper) out of range
  ChainedArrays<Integer> C = new ChainedArrays<Integer>();
  C.add(1);
  C.removeLast();
  int actualsize = C.size();
  int expectedsize = 0;

  if(actualsize != expectedsize) {
       failFmt("ChainedArrays size:\n"+
               "expectedsize: "+expectedsize +"\n"+
               "actualsize: "+actualsize+"\n"+"");
  }
  }

  @SuppressWarnings("unchecked")
  @Test(timeout=1000) public void ChainedArrays_clear1() {
  // test getNode(idx, lower,upper) out of range
  ChainedArrays<Integer> C = new ChainedArrays<Integer>();
  C.add(1);
  C.clear();
  int actualsize = C.size();
  int expectedsize = 0;

  if(actualsize != expectedsize) {
       failFmt("ChainedArrays clear:\n"+
               "expectedsize: "+expectedsize +"\n"+
               "actualsize: "+actualsize+"\n"+"");
  }
  }





// test MyHashTable.constructors

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_construct1() {
// test default capacity
  MyHashTable T = new MyHashTable();
  Object[] table = T.getTable();
  int actualCapacity = table.length;
  int expectedCapacity = 101; //default

  if(actualCapacity != expectedCapacity) {
       failFmt("MyHashTable constructor:\n"+
               "expectedCapacity: "+expectedCapacity +"\n"+
               "actualCapacity: "+actualCapacity+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_construct2() {
// test size initially 0
  MyHashTable T = new MyHashTable();
  int actualSize = T.size();
  int expectedSize = 0;

  if(actualSize != expectedSize) {
       failFmt("MyHashTable constructor:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_construct3() {
// test begin marker links
  MyHashTable T = new MyHashTable();
  MyHashTable.MyListNode beginMarker = T.beginMarker;
  MyHashTable.MyListNode endMarker = T.endMarker;

  if(beginMarker.next != endMarker) {
       failFmt("MyHashTable constructor:\n"+
               "beginMarker.next: != endMarker\n");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_construct4() {
// test end marker links
  MyHashTable T = new MyHashTable(2);
  Object[] table = T.getTable();
  MyHashTable.MyListNode beginMarker = T.beginMarker;
  MyHashTable.MyListNode endMarker = T.endMarker;

  if(endMarker.prev != beginMarker) {
       failFmt("MyHashTable constructor:\n"+
               "endMarker.prev: != beginMarker\n");
  }
  }

// test MyHashTable.MyListNode

/*
Here is class Foo, which is defined at the end of this file:

  class Foo implements Comparable<Foo> {
    int x;
    int hc;
    Foo(int value, int hashCode) {this.x=value; this.hc = hashCode;}
  	 public int hashCode() {return hc;}
    public int compareTo(Foo other) {
		return x - other.x;
    }
    public boolean equals(Object other) {
      if (this == other) return true;
      if (!(other instanceof Foo)) return false;
      Foo that = (Foo) other; 
      return this.x == that.x;
    }
    public String toString() { return new Integer(x).toString();}
  }

*/

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_MyListNode1() {
// test hashCode

  Foo f1 = new Foo(1,1); // value is 1; hashCode is 1
  MyHashTable.MyListNode N = new MyHashTable.MyListNode (f1,null,null);
  int actualValue = N.hashCode();
  int expectedValue = 1;
  if(actualValue != expectedValue) {
       failFmt("MyHashTable.MyListNode.hashCode:\n"+
               "expectedValue: "+expectedValue +"\n"+
               "actualValue: "+actualValue+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_MyListNode2() {
// test equals - true

  Foo f1 = new Foo(1,1);
  Foo f2 = new Foo(1,1);
  MyHashTable.MyListNode N1 = new MyHashTable.MyListNode (f1,null,null);
  MyHashTable.MyListNode N2 = new MyHashTable.MyListNode (f2,null,null);
  boolean actualValue = N1.equals(N2);
  boolean expectedValue = true;
  if(actualValue != expectedValue) {
       failFmt("MyHashTable.MyListNode.equals:\n"+
               "expectedValue: "+expectedValue +"\n"+
               "actualValue: "+actualValue+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_MyListNode3() {
// test equals - false

  Foo f1 = new Foo(1,1);
  Foo f2 = new Foo(2,1);
  MyHashTable.MyListNode N1 = new MyHashTable.MyListNode (f1,null,null);
  MyHashTable.MyListNode N2 = new MyHashTable.MyListNode (f2,null,null);
  boolean actualValue = N1.equals(N2);
  boolean expectedValue = false;
  if(actualValue != expectedValue) {
       failFmt("MyHashTable.MyListNode.equals:\n"+
               "expectedValue: "+expectedValue +"\n"+
               "actualValue: "+actualValue+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_MyListNode4() {
// test isEqual - true

  Foo f1 = new Foo(1,1);
  Foo f2 = new Foo(1,1);
  MyHashTable.MyListNode N1 = new MyHashTable.MyListNode (f1,null,null);
  MyHashTable.MyListNode N2 = new MyHashTable.MyListNode (f2,null,null);
  boolean actualValue = N1.isEqual(N1,N2);
  boolean expectedValue = true;
  if(actualValue != expectedValue) {
       failFmt("MyHashTable.MyListNode.isEqual:\n"+
               "expectedValue: "+expectedValue +"\n"+
               "actualValue: "+actualValue+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_MyListNode5() {
// test isEqual - false

  Foo f1 = new Foo(1,1);
  Foo f2 = new Foo(2,1);
  MyHashTable.MyListNode N1 = new MyHashTable.MyListNode (f1,null,null);
  MyHashTable.MyListNode N2 = new MyHashTable.MyListNode (f2,null,null);
  boolean actualValue = N1.isEqual(N1,N2);
  boolean expectedValue = false;
  if(actualValue != expectedValue) {
       failFmt("MyHashTable.MyListNode.isEqual:\n"+
               "expectedValue: "+expectedValue +"\n"+
               "actualValue: "+actualValue+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_MyListNode6() {
// test isEqual - false

  Foo f1 = new Foo(1,1);
  MyHashTable.MyListNode N1 = new MyHashTable.MyListNode (f1,null,null);
  boolean actualValue = N1.isEqual(N1,null);
  boolean expectedValue = false;
  if(actualValue != expectedValue) {
       failFmt("MyHashTable.MyListNode.isEqual:\n"+
               "expectedValue: "+expectedValue +"\n"+
               "actualValue: "+actualValue+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_MyListNode7() {
// test isEqual - false
  Foo f1 = new Foo(1,1);
  MyHashTable.MyListNode N1 = new MyHashTable.MyListNode (f1,null,null);
  boolean actualValue = N1.isEqual(null,N1);
  boolean expectedValue = false;
  if(actualValue != expectedValue) {
       failFmt("MyHashTable.MyListNode.isEqual:\n"+
               "expectedValue: "+expectedValue +"\n"+
               "actualValue: "+actualValue+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_MyListNode8() {
// test compareTo : 0

  Foo f1 = new Foo(1,1);
  Foo f2 = new Foo(1,1);
  MyHashTable.MyListNode N1 = new MyHashTable.MyListNode (f1,null,null);
  MyHashTable.MyListNode N2 = new MyHashTable.MyListNode (f2,null,null);
  int actualValue = N1.compareTo(N2);
  int expectedValue = 0;
  if(actualValue != expectedValue) {
       failFmt("MyHashTable.MyListNode.compareTo:\n"+
               "expectedValue: "+expectedValue +"\n"+
               "actualValue: "+actualValue+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_MyListNode9() {
// test compareTO : -1

  Foo f1 = new Foo(1,1);
  Foo f2 = new Foo(2,1);
  MyHashTable.MyListNode N1 = new MyHashTable.MyListNode (f1,null,null);
  MyHashTable.MyListNode N2 = new MyHashTable.MyListNode (f2,null,null);
  int actualValue = N1.compareTo(N2);
  int expectedValue = -1;
  if(actualValue != expectedValue) {
       failFmt("MyHashTable.MyListNode.compareTo:\n"+
               "expectedValue: "+expectedValue +"\n"+
               "actualValue: "+actualValue+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_MyListNode10() {
// test compareTo : 1
  Foo f1 = new Foo(1,1);
  Foo f2 = new Foo(0,1);
  MyHashTable.MyListNode N1 = new MyHashTable.MyListNode (f1,null,null);
  MyHashTable.MyListNode N2 = new MyHashTable.MyListNode (f2,null,null);
  int actualValue = N1.compareTo(N2);
  int expectedValue = 1;
  if(actualValue != expectedValue) {
       failFmt("MyHashTable.MyListNode.compareTo:\n"+
               "expectedValue: "+expectedValue +"\n"+
               "actualValue: "+actualValue+"\n"+"");
  }
  }
 
 

// Test MyHashTable.insert

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_insert1() {
// insert into tmepty table

  MyHashTable<Foo> T = new MyHashTable<Foo>(3);
  Foo f2 = new Foo(2,1); // both hash to 1
  T.insert(f2);
  Object[] table = T.getTable();
  int hashVal = f2.hashCode( ) % 3; if( hashVal < 0 ) hashVal += 3;
  ChainedArrays C_1 = (ChainedArrays) table[hashVal];
  ChainedArrays.ArrayNode current = C_1.getNode(0);

  int actualArraySize1 = current.getArraySize();
  int expectedArraySize1 = 1;

  if(actualArraySize1 != expectedArraySize1) {
       failFmt("MyHashTable insert:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
  }

  Comparable actualFirstValue1 = current.getFirst();
  MyHashTable.MyListNode expectedFirstValue1 = new MyHashTable.MyListNode(f2,null,null);
  if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
      failFmt("MyHashTable insert:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
  }
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_insert2() {
// insert two elements - both hash to 1

  MyHashTable<Foo> T = new MyHashTable<Foo>(3);
  Foo f2 = new Foo(2,1); // both hash to 1
  Foo f3 = new Foo(3,1); // both hash to 1
  T.insert(f2);
  T.insert(f3);
  Object[] table = T.getTable();
  int hashVal = f2.hashCode( ) % 3; if( hashVal < 0 ) hashVal += 3;
  ChainedArrays C_1 = (ChainedArrays) table[hashVal];
  ChainedArrays.ArrayNode current = C_1.getNode(0);

  int actualArraySize1 = current.getArraySize();
  int expectedArraySize1 = 2;

  if(actualArraySize1 != expectedArraySize1) {
       failFmt("MyHashTable insert:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
  }

  Comparable actualFirstValue1 = current.getFirst();
  MyHashTable.MyListNode expectedFirstValue1 = new MyHashTable.MyListNode(f2,null,null);
  if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
      failFmt("MyHashTable insert:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
  }

  Comparable actualLastValue1 = current.getLast();
  MyHashTable.MyListNode expectedLastValue1 = new MyHashTable.MyListNode(f3,null,null);
  if (actualLastValue1.compareTo(expectedLastValue1)!=0) {
      failFmt("MyHashTable insert:\n"+
               "expectedLastValue1: " + expectedLastValue1 +"\n"+
               "actualLastValue1: " + actualLastValue1 + "");
  }

}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_insert3() {
// insert 2 elements with different hash values

  MyHashTable<Foo> T = new MyHashTable<Foo>(3);
  Foo f2 = new Foo(2,1); //  hash to 1
  Foo f3 = new Foo(3,3); //  hash to 3
  T.insert(f2);
  T.insert(f3);

  Object[] table = T.getTable();
  int hashValf2 = f2.hashCode( ) % 3; if( hashValf2 < 0 ) hashValf2 += 3;
  ChainedArrays C_1 = (ChainedArrays) table[hashValf2];
  ChainedArrays.ArrayNode current = C_1.getNode(0);

  int actualArraySize1 = current.getArraySize();
  int expectedArraySize1 = 1;

  if(actualArraySize1 != expectedArraySize1) {
       failFmt("MyHashTable insert:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
  }

  Comparable actualFirstValue1 = current.getFirst();
  MyHashTable.MyListNode expectedFirstValue1 = new MyHashTable.MyListNode(f2,null,null);
  if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
      failFmt("MyHashTable insert:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
  }

  int hashValf3 = f3.hashCode( ) % 3; if( hashValf3 < 0 ) hashValf3 += 3;
  ChainedArrays C_0 = (ChainedArrays) table[hashValf3];
  current = C_0.getNode(0);

  int actualArraySize2 = current.getArraySize();
  int expectedArraySize2 = 1;

  if(actualArraySize2 != expectedArraySize2) {
       failFmt("MyHashTable insert:\n"+
               "expectedArraySize2: "+expectedArraySize2 +"\n"+
               "actualArraySize2: "+actualArraySize2+"\n"+"");
  }
  Comparable actualLastValue1 = current.getLast();
  MyHashTable.MyListNode expectedLastValue1 = new MyHashTable.MyListNode(f3,null,null);
  if (actualLastValue1.compareTo(expectedLastValue1)!=0) {
      failFmt("MyHashTable insert:\n"+
               "expectedLastValue1: " + expectedLastValue1 +"\n"+
               "actualLastValue1: " + actualLastValue1 + "");
  }
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_insert4() {
// insert null throws exception 
  MyHashTable<Integer> T = new MyHashTable<Integer>(3);
  boolean thrown = false;
  try {T.insert(null);}
  catch (IllegalArgumentException e) {
    thrown = true;
  }
  if(!thrown) {
       failFmt("gMyHashTable insert:\n"+
               "Expect: "+"IllegalArgumentException" +"\n"+
               "Actual: "+" IllegalArgumentException not thrown"+"\n"+"");
    }
}

// test MyHashTable.clear

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_clear1() {
// test MyHashTable.clear : doesn't change capacity
  MyHashTable T = new MyHashTable();
  T.insert(1);
  T.clear();
  Object[] table = T.getTable();
  int actualCapacity = table.length;
  int expectedCapacity = 101; //default

  if(actualCapacity != expectedCapacity) {
       failFmt("MyHashTable clear:\n"+
               "expectedCapacity: "+expectedCapacity +"\n"+
               "actualCapacity: "+actualCapacity+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_clear2() {
// test clear - reset size
  MyHashTable T = new MyHashTable();
  Object[] table = T.getTable();
  T.insert(1);
  T.clear();
  int actualSize = T.size();
  int expectedSize = 0;

  if(actualSize != expectedSize) {
       failFmt("MyHashTable clear:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_clear3() {
// test clear - beginMarker links
  MyHashTable T = new MyHashTable();
  MyHashTable.MyListNode beginMarker = T.beginMarker;
  MyHashTable.MyListNode endMarker = T.endMarker;

  if(beginMarker.next != endMarker) {
       failFmt("MyHashTable clear:\n"+
               "beginMarker.next: != endMarker\n");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_clear4() {
// test clear - endMarker links
  MyHashTable T = new MyHashTable(2);
  Object[] table = T.getTable();
  T.insert(1);
  T.clear();
  MyHashTable.MyListNode beginMarker = T.beginMarker;
  MyHashTable.MyListNode endMarker = T.endMarker;

  if(endMarker.prev != beginMarker) {
       failFmt("MyHashTable clear:\n"+
               "endMarker.prev: != beginMarker\n");
  }
  }

// test MyHashTable remove

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_remove1() {
// insert item and remove it

  MyHashTable<Foo> T = new MyHashTable<Foo>(3);
  Foo f2 = new Foo(2,1); // both hash to 1
  T.insert(f2);
  Object[] table = T.getTable();
  int hashVal = f2.hashCode( ) % 3; if( hashVal < 0 ) hashVal += 3;
  ChainedArrays C_1 = (ChainedArrays) table[hashVal];
  ChainedArrays.ArrayNode current = C_1.getNode(0);

  int actualArraySize1 = current.getArraySize();
  int expectedArraySize1 = 1;

  if(actualArraySize1 != expectedArraySize1) {
       failFmt("MyHashTable remove:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
  }

  Comparable actualFirstValue1 = current.getFirst();
  MyHashTable.MyListNode expectedFirstValue1 = new MyHashTable.MyListNode(f2,null,null);
  if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
      failFmt("MyHashTable remove:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
  }

  T.remove(f2);

  int actualSize = T.size();
  int expectedSize = 0;

  if(actualSize != expectedSize) {
       failFmt("MyHashTable remove:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }
}

// test MyHashTable remove
@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_remove2() {
// insert 2 items and remove 1

  MyHashTable<Foo> T = new MyHashTable<Foo>(3);
  Foo f2 = new Foo(2,1); //  hash to 1
  Foo f3 = new Foo(3,1); //  hash to 1
  T.insert(f2);
  T.insert(f3);
  Object[] table = T.getTable();
  int hashVal = f2.hashCode( ) % 3; if( hashVal < 0 ) hashVal += 3;
  ChainedArrays C_1 = (ChainedArrays) table[hashVal];
  ChainedArrays.ArrayNode current = C_1.getNode(0);

  int actualArraySize1 = current.getArraySize();
  int expectedArraySize1 = 2;

  if(actualArraySize1 != expectedArraySize1) {
       failFmt("MyHashTable remove:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
  }

  Comparable actualFirstValue1 = current.getFirst();
  MyHashTable.MyListNode expectedFirstValue1 = new MyHashTable.MyListNode(f2,null,null);
  if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
      failFmt("MyHashTable remove:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
  }

  T.remove(f2);
  C_1 = (ChainedArrays) table[hashVal];
  current = C_1.getNode(0);

  int actualArraySize2 = current.getArraySize();
  int expectedArraySize2 = 1;

  if(actualArraySize2 != expectedArraySize2) {
       failFmt("MyHashTable remove:\n"+
               "expectedArraySize2: "+expectedArraySize2 +"\n"+
               "actualArraySize2: "+actualArraySize2+"\n"+"");
  }
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_remove3() {
// remove null throws excpetion
  MyHashTable<Integer> T = new MyHashTable<Integer>(3);
  boolean thrown = false;
  T.insert(1);
  try {T.remove(null);}
  catch (IllegalArgumentException e) {
    thrown = true;
  }
  if(!thrown) {
       failFmt("gMyHashTable remove:\n"+
               "Expect: "+"IllegalArgumentException" +"\n"+
               "Actual: "+" IllegalArgumentException not thrown"+"\n"+"");
    }
}

// test MyHashTable.contains

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_contains1() {
// insert(x) and check contains(x)

  MyHashTable<Foo> T = new MyHashTable<Foo>(3);
  Foo f2 = new Foo(2,1); //  hash to 1
  T.insert(f2);
  Object[] table = T.getTable();
  int hashVal = f2.hashCode( ) % 3; if( hashVal < 0 ) hashVal += 3;
  ChainedArrays C_1 = (ChainedArrays) table[hashVal];
  ChainedArrays.ArrayNode current = C_1.getNode(0);

  int actualArraySize1 = current.getArraySize();
  int expectedArraySize1 = 1;

  if(actualArraySize1 != expectedArraySize1) {
       failFmt("MyHashTable contains:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
  }

  Comparable actualFirstValue1 = current.getFirst();
  MyHashTable.MyListNode expectedFirstValue1 = new MyHashTable.MyListNode(f2,null,null);
  if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
      failFmt("MMyHashTable contains:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
  }

  boolean actualValue = T.contains(f2);
  boolean expectedValue = true;

  if (actualValue != expectedValue) {
      failFmt("MyHashTable contains:\n"+
               "expectedValue: " + expectedValue +"\n"+
               "actualValue: " + actualValue + "");
  }
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_contains2() {
// insert(x) but contains(y) - false

  MyHashTable<Foo> T = new MyHashTable<Foo>(3);
  Foo f2 = new Foo(2,1); //  hash to 1
  Foo f3 = new Foo(3,1); //  hash to 1
  T.insert(f2);
  Object[] table = T.getTable();
  int hashVal = f2.hashCode( ) % 3; if( hashVal < 0 ) hashVal += 3;
  ChainedArrays C_1 = (ChainedArrays) table[hashVal];
  ChainedArrays.ArrayNode current = C_1.getNode(0);

  int actualArraySize1 = current.getArraySize();
  int expectedArraySize1 = 1;

  if(actualArraySize1 != expectedArraySize1) {
       failFmt("MyHashTable contains:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
  }

  Comparable actualFirstValue1 = current.getFirst();
  MyHashTable.MyListNode expectedFirstValue1 = new MyHashTable.MyListNode(f2,null,null);
  if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
      failFmt("MMyHashTable contains:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
  }

  boolean actualValue = T.contains(f3);
  boolean expectedValue = false;

  if (actualValue != expectedValue) {
      failFmt("MyHashTable contains:\n"+
               "expectedValue: " + expectedValue +"\n"+
               "actualValue: " + actualValue + "");
  }
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_contains3() {
// contains null throws exception
  MyHashTable<Integer> T = new MyHashTable<Integer>(3);
  boolean thrown = false;
  T.insert(1);
  try {T.contains(null);}
  catch (IllegalArgumentException e) {
    thrown = true;
  }
  if(!thrown) {
       failFmt("gMyHashTable contains:\n"+
               "Expect: "+"IllegalArgumentException" +"\n"+
               "Actual: "+" IllegalArgumentException not thrown"+"\n"+"");
    }
}

// test MyHashTable.getMatch

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_getMatch1() {
// insert(x) getMatch(x)

  MyHashTable<Foo> T = new MyHashTable<Foo>(3);
  Foo f2 = new Foo(2,1); //  hash to 1
  T.insert(f2);
  Object[] table = T.getTable();
  int hashVal = f2.hashCode( ) % 3; if( hashVal < 0 ) hashVal += 3;
  ChainedArrays C_1 = (ChainedArrays) table[hashVal];
  ChainedArrays.ArrayNode current = C_1.getNode(0);

  int actualArraySize1 = current.getArraySize();
  int expectedArraySize1 = 1;

  if(actualArraySize1 != expectedArraySize1) {
       failFmt("MyHashTable getMatch:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
  }

  Comparable actualFirstValue1 = current.getFirst();
  MyHashTable.MyListNode expectedFirstValue1 = new MyHashTable.MyListNode(f2,null,null);
  if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
      failFmt("MMyHashTable getMatch:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
  }

  Foo actualValue = T.getMatch(f2);
  Foo expectedValue = f2;

  if (actualValue.compareTo(expectedValue) != 0) {
      failFmt("MyHashTable getMatch:\n"+
               "expectedValue: " + expectedValue +"\n"+
               "actualValue: " + actualValue + "");
  }
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_getMatch2() {
// insert(x) getMAtch(y) - false

  MyHashTable<Foo> T = new MyHashTable<Foo>(3);
  Foo f2 = new Foo(2,1); // both hash to 1
  Foo f3 = new Foo(3,1);
  T.insert(f2);
  Object[] table = T.getTable();
  int hashVal = f2.hashCode( ) % 3; if( hashVal < 0 ) hashVal += 3;
  ChainedArrays C_1 = (ChainedArrays) table[hashVal];
  ChainedArrays.ArrayNode current = C_1.getNode(0);

  int actualArraySize1 = current.getArraySize();
  int expectedArraySize1 = 1;

  if(actualArraySize1 != expectedArraySize1) {
       failFmt("MyHashTable getMatch:\n"+
               "expectedArraySize1: "+expectedArraySize1 +"\n"+
               "actualArraySize1: "+actualArraySize1+"\n"+"");
  }

  Comparable actualFirstValue1 = current.getFirst();
  MyHashTable.MyListNode expectedFirstValue1 = new MyHashTable.MyListNode(f2,null,null);
  if (actualFirstValue1.compareTo(expectedFirstValue1)!=0) {
      failFmt("MMyHashTable getMatch:\n"+
               "expectedFirstValue1: " + expectedFirstValue1 +"\n"+
               "actualFirstValue1: " + actualFirstValue1 + "");
  }

  Foo actualValue = T.getMatch(f3);
  Foo expectedValue = null;

  if (actualValue != expectedValue) {
      failFmt("MyHashTable getMatch:\n"+
               "expectedValue: " + expectedValue +"\n"+
               "actualValue: " + actualValue + "");
  }
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_getMatch4() {
// getMatch null is false
  MyHashTable<Integer> T = new MyHashTable<Integer>(3);
  boolean thrown = false;
  T.insert(1);
  try {T.getMatch(null);}
  catch (IllegalArgumentException e) {
    thrown = true;
  }
  if(!thrown) {
       failFmt("gMyHashTable getMatch:\n"+
               "Expect: "+"IllegalArgumentException" +"\n"+
               "Actual: "+" IllegalArgumentException not thrown"+"\n"+"");
    }
}

// Test MyHashTable.tableToString

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_tableToString1() {
// toString : ignore spaces

  MyHashTable<Foo> T = new MyHashTable<Foo>(3);
  Foo f2 = new Foo(2,1); // both hash to 1
  Foo f3 = new Foo(3,3);
  T.insert(f2);
  T.insert(f3);

  String actualString = T.tableToString().replaceAll("\\s+",""); // removes all whitespaces and non visible characters
  String expectedString = new String("Table:\n0:|3|\n1:|2|\n2:").replaceAll("\\s+","");

  if(actualString.compareTo(expectedString)!=0) {
       failFmt("MyHashTable toString:\n"+
               "expectedString: "+expectedString +"\n"+
               "actualString: "+actualString+"\n"+"");
  }
}

// Test MyHashTable.tableToString

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_toString1() {
// toString : ignore spaces

  MyHashTable<Foo> T = new MyHashTable<Foo>(3);
  Foo f2 = new Foo(2,1); // both hash to 1
  Foo f3 = new Foo(3,3);
  T.insert(f2);
  T.insert(f3);

  String actualString = T.toString().replaceAll("\\s+",""); // removes all whitespaces and non visible characters
  String expectedString = new 
	String("Table:\n0:|3|\n1:|2|\n2:\nLinked List:\n2,3").replaceAll("\\s+","");

  if(actualString.compareTo(expectedString)!=0) {
       failFmt("MyHashTable toString:\n"+
               "expectedString: "+expectedString +"\n"+
               "actualString: "+actualString+"\n"+"");
  }
}

// test MyHashTable isEmpty

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_isEmpty1() {
// isEmpty on empty table - true
  MyHashTable<Integer> T = new MyHashTable<Integer>(3);

  boolean actual = T.isEmpty();
  boolean expected = true;
  if(actual != expected) {
       failFmt("MyHashTable isEmpty:\n"+
               "expected: "+expected +"\n"+
               "actual: "+actual+"\n"+"");
  }
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_isEmpty2() {
// insert(x); isEmpty is false
  MyHashTable<Integer> T = new MyHashTable<Integer>(3);
  T.insert(1);
  boolean actual = T.isEmpty();
  boolean expected = false;
  if(actual != expected) {
       failFmt("MyHashTable isEmpty:\n"+
               "expected: "+expected +"\n"+
               "actual: "+actual+"\n"+"");
  }
}

// test MyHashTable size

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_size1() {
// size of empty table - 0
  MyHashTable<Integer> T = new MyHashTable<Integer>(3);
  int actual = T.size();
  int expected = 0;
  if(actual != expected) {
       failFmt("MyHashTable size:\n"+
               "expected: "+expected +"\n"+
               "actual: "+actual+"\n"+"");
  }
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_size2() {
// insert(1); size is 1
  MyHashTable<Integer> T = new MyHashTable<Integer>(3);
  T.insert(1);
  int actual = T.size();
  int expected = 1;
  if(actual != expected) {
       failFmt("MyHashTable size:\n"+
               "expected: "+expected +"\n"+
               "actual: "+actual+"\n"+"");
  }
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_size3() {
// insert(x); remove(x); isEmpty is true.
  MyHashTable<Integer> T = new MyHashTable<Integer>(3);
  T.insert(1);
  T.remove(1);
  int actual = T.size();
  int expected = 0;
  if(actual != expected) {
       failFmt("MyHashTable size:\n"+
               "expected: "+expected +"\n"+
               "actual: "+actual+"\n"+"");
  }
}

// test MyHashTable.insertListNodeAfter

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_insertListNodeAfter1() {
// build f1 --> f2

  Foo f1 = new Foo(1,1);
  Foo f2 = new Foo(2,1);
  MyHashTable T = new MyHashTable(3);
  MyHashTable.MyListNode returedNode = T.insertListNodeAfter(T.beginMarker,f1);
  T.insertListNodeAfter(returedNode,f2);
  Comparable actualFirstFoo = T.beginMarker.next.data;
  Comparable expectedFirstFoo = f1;
  if(actualFirstFoo.compareTo(expectedFirstFoo) != 0) {
       failFmt("MyHashTable insertListNodeAfter:\n"+
               "expectedFirstFoo: "+expectedFirstFoo +"\n"+
               "actualFirstFoo: "+actualFirstFoo+"\n"+"");
  }

  MyHashTable.MyListNode actualFirstFooPrev = T.beginMarker.next.prev;
  MyHashTable.MyListNode expectedFirstFooPrev = T.beginMarker;
  if(actualFirstFooPrev != expectedFirstFooPrev) {
       failFmt("MyHashTable insertListNodeAfter:\n"+
               "expectedFirstFooPrev: "+expectedFirstFooPrev +"\n"+
               "actualFirstFooPrev: "+actualFirstFooPrev+"\n"+"");
  }

  Comparable actualSecondFoo = T.beginMarker.next.next.data;
  Comparable expectedSecondFoo = f2;
  if(actualSecondFoo.compareTo(expectedSecondFoo) != 0) {
       failFmt("MyHashTable insertListNodeAfter:\n"+
               "expectedSecondFoo: "+expectedSecondFoo +"\n"+
               "actualSecondFoo: "+actualSecondFoo+"\n"+"");
  }

  MyHashTable.MyListNode actualSecondFooPrev = T.beginMarker.next.next.prev;
  MyHashTable.MyListNode expectedSecondFooPrev = T.beginMarker.next;
  if(!actualSecondFooPrev.equals(expectedSecondFooPrev)) {
       failFmt("MyHashTable insertListNodeAfter:\n"+
               "expectedSecondFooPrev: "+expectedSecondFooPrev +"\n"+
               "actualSecondFooPrev: "+actualSecondFooPrev+"\n"+"");
  }

  Comparable actualLastNode = T.beginMarker.next.next.next;
  Comparable expectedLastNode = T.endMarker;
  if(actualLastNode != expectedLastNode) {
       failFmt("MyHashTable insertListNodeAfter:\n"+
               "expectedLastNode: "+expectedLastNode +"\n"+
               "actualLastNode: "+actualLastNode+"\n"+"");
  }
  }

// test MyHashTable insertListNodeBefore

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_insertListNodeBefore1() {
// build f1 --> f2

  Foo f1 = new Foo(1,1);
  Foo f2 = new Foo(2,1);
  MyHashTable T = new MyHashTable(3);
  MyHashTable.MyListNode returedNode = T.insertListNodeBefore(T.endMarker,f2);
  T.insertListNodeBefore(returedNode,f1);
  Comparable actualFirstFoo = T.beginMarker.next.data;
  Comparable expectedFirstFoo = f1;
  if(actualFirstFoo.compareTo(expectedFirstFoo) != 0) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedFirstFoo: "+expectedFirstFoo +"\n"+
               "actualFirstFoo: "+actualFirstFoo+"\n"+"");
  }

  MyHashTable.MyListNode actualFirstFooPrev = T.beginMarker.next.prev;
  MyHashTable.MyListNode expectedFirstFooPrev = T.beginMarker;
  if(actualFirstFooPrev != expectedFirstFooPrev) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedFirstFooPrev: "+expectedFirstFooPrev +"\n"+
               "actualFirstFooPrev: "+actualFirstFooPrev+"\n"+"");
  }

  Comparable actualSecondFoo = T.beginMarker.next.next.data;
  Comparable expectedSecondFoo = f2;
  if(actualSecondFoo.compareTo(expectedSecondFoo) != 0) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedSecondFoo: "+expectedSecondFoo +"\n"+
               "actualSecondFoo: "+actualSecondFoo+"\n"+"");
  }

  MyHashTable.MyListNode actualSecondFooPrev = T.beginMarker.next.next.prev;
  MyHashTable.MyListNode expectedSecondFooPrev = T.beginMarker.next;
  if(!actualSecondFooPrev.equals(expectedSecondFooPrev)) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedSecondFooPrev: "+expectedSecondFooPrev +"\n"+
               "actualSecondFooPrev: "+actualSecondFooPrev+"\n"+"");
  }

  Comparable actualLastNode = T.beginMarker.next.next.next;
  Comparable expectedLastNode = T.endMarker;
  if(actualLastNode != expectedLastNode) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedLastNode: "+expectedLastNode +"\n"+
               "actualLastNode: "+actualLastNode+"\n"+"");
  }
  }

// test MyHashTable removeListNode

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_removeListNode1() {
// build begin --> f1 --> end; remove f1 ==> begin --> end

  Foo f1 = new Foo(1,1);
  MyHashTable T = new MyHashTable(3);
  MyHashTable.MyListNode returedNode = T.insertListNodeAfter(T.beginMarker,f1);
  T.removeListNode(returedNode);

  MyHashTable.MyListNode beginMarker = T.beginMarker;
  MyHashTable.MyListNode endMarker = T.endMarker;

  if(beginMarker.next != endMarker) {
       failFmt("MyHashTable removeListNode:\n"+
               "beginMarker.next: != endMarker\n");
  }

  if(endMarker.prev != beginMarker) {
       failFmt("MyHashTable removeListNode:\n"+
               "endMarker.prev != beginMarker\n");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_listNodesToString1() {
 // test displayListNodes: 1 --> 2 outputs "1, 2"

  Foo f1 = new Foo(1,1);
  Foo f2 = new Foo(2,1);
  MyHashTable T = new MyHashTable(3);
  MyHashTable.MyListNode returedNode = T.insertListNodeAfter(T.beginMarker,f1);
  T.insertListNodeAfter(returedNode,f2);
  // 1 --> 2
  String actualString = T.listNodesToString().replaceAll("\\s+","");
  String expectedString = new String("1, 2").replaceAll("\\s+","");
  if(!actualString.equals(expectedString)) {
       failFmt("MyHashTable listNodesToString:\n"+
               "expectedString: "+expectedString +"\n"+
               "actualString: "+actualString+"\n"+"");
  }
  }

// Test MyHashTable insert + remove + linked lists

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_insertremoveLL1() {
// insert(f1); insert(f2) ==> begin --> f1 --> f2 --> end

  Foo f1 = new Foo(1,1);
  Foo f2 = new Foo(2,1);
  MyHashTable T = new MyHashTable(3);
  T.insert(f1);
  T.insert(f2);

  Comparable actualFirstFoo = T.beginMarker.next.data;
  Comparable expectedFirstFoo = f1;
  if(actualFirstFoo.compareTo(expectedFirstFoo) != 0) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedFirstFoo: "+expectedFirstFoo +"\n"+
               "actualFirstFoo: "+actualFirstFoo+"\n"+"");
  }

  MyHashTable.MyListNode actualFirstFooPrev = T.beginMarker.next.prev;
  MyHashTable.MyListNode expectedFirstFooPrev = T.beginMarker;
  if(actualFirstFooPrev != expectedFirstFooPrev) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedFirstFooPrev: "+expectedFirstFooPrev +"\n"+
               "actualFirstFooPrev: "+actualFirstFooPrev+"\n"+"");
  }

  Comparable actualSecondFoo = T.beginMarker.next.next.data;
  Comparable expectedSecondFoo = f2;
  if(actualSecondFoo.compareTo(expectedSecondFoo) != 0) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedSecondFoo: "+expectedSecondFoo +"\n"+
               "actualSecondFoo: "+actualSecondFoo+"\n"+"");
  }

  MyHashTable.MyListNode actualSecondFooPrev = T.beginMarker.next.next.prev;
  MyHashTable.MyListNode expectedSecondFooPrev = T.beginMarker.next;
  if(!actualSecondFooPrev.equals(expectedSecondFooPrev)) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedSecondFooPrev: "+expectedSecondFooPrev +"\n"+
               "actualSecondFooPrev: "+actualSecondFooPrev+"\n"+"");
  }

  Comparable actualLastNode = T.beginMarker.next.next.next;
  Comparable expectedLastNode = T.endMarker;
  if(actualLastNode != expectedLastNode) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedLastNode: "+expectedLastNode +"\n"+
               "actualLastNode: "+actualLastNode+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_insertremoveLL2() {
// insert(f1; insert(f2); insert(f3); remove(f3) ==> begin --> f1 --> f2 --> end

  Foo f1 = new Foo(1,1);
  Foo f2 = new Foo(2,1);
  Foo f3 = new Foo(3,1);

  MyHashTable T = new MyHashTable(3);
  T.insert(f1);
  T.insert(f2);
  T.insert(f3);
  T.remove(f3);

  Comparable actualFirstFoo = T.beginMarker.next.data;
  Comparable expectedFirstFoo = f1;
  if(actualFirstFoo.compareTo(expectedFirstFoo) != 0) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedFirstFoo: "+expectedFirstFoo +"\n"+
               "actualFirstFoo: "+actualFirstFoo+"\n"+"");
  }

  MyHashTable.MyListNode actualFirstFooPrev = T.beginMarker.next.prev;
  MyHashTable.MyListNode expectedFirstFooPrev = T.beginMarker;
  if(actualFirstFooPrev != expectedFirstFooPrev) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedFirstFooPrev: "+expectedFirstFooPrev +"\n"+
               "actualFirstFooPrev: "+actualFirstFooPrev+"\n"+"");
  }

  Comparable actualSecondFoo = T.beginMarker.next.next.data;
  Comparable expectedSecondFoo = f2;
  if(actualSecondFoo.compareTo(expectedSecondFoo) != 0) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedSecondFoo: "+expectedSecondFoo +"\n"+
               "actualSecondFoo: "+actualSecondFoo+"\n"+"");
  }

  MyHashTable.MyListNode actualSecondFooPrev = T.beginMarker.next.next.prev;
  MyHashTable.MyListNode expectedSecondFooPrev = T.beginMarker.next;
  if(!actualSecondFooPrev.equals(expectedSecondFooPrev)) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedSecondFooPrev: "+expectedSecondFooPrev +"\n"+
               "actualSecondFooPrev: "+actualSecondFooPrev+"\n"+"");
  }

  Comparable actualLastNode = T.beginMarker.next.next.next;
  Comparable expectedLastNode = T.endMarker;
  if(actualLastNode != expectedLastNode) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedLastNode: "+expectedLastNode +"\n"+
               "actualLastNode: "+actualLastNode+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_insertremoveLL3() {
// same as preceding only begin --> f1 --> f3 --> end

  Foo f1 = new Foo(1,1);
  Foo f2 = new Foo(2,1);
  Foo f3 = new Foo(3,1);

  MyHashTable T = new MyHashTable(3);
  T.insert(f1);
  T.insert(f2);
  T.insert(f3);
  T.remove(f2);

  Comparable actualFirstFoo = T.beginMarker.next.data;
  Comparable expectedFirstFoo = f1;
  if(actualFirstFoo.compareTo(expectedFirstFoo) != 0) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedFirstFoo: "+expectedFirstFoo +"\n"+
               "actualFirstFoo: "+actualFirstFoo+"\n"+"");
  }

  MyHashTable.MyListNode actualFirstFooPrev = T.beginMarker.next.prev;
  MyHashTable.MyListNode expectedFirstFooPrev = T.beginMarker;
  if(actualFirstFooPrev != expectedFirstFooPrev) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedFirstFooPrev: "+expectedFirstFooPrev +"\n"+
               "actualFirstFooPrev: "+actualFirstFooPrev+"\n"+"");
  }

  Comparable actualSecondFoo = T.beginMarker.next.next.data;
  Comparable expectedSecondFoo = f3;
  if(actualSecondFoo.compareTo(expectedSecondFoo) != 0) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedSecondFoo: "+expectedSecondFoo +"\n"+
               "actualSecondFoo: "+actualSecondFoo+"\n"+"");
  }

  MyHashTable.MyListNode actualSecondFooPrev = T.beginMarker.next.next.prev;
  MyHashTable.MyListNode expectedSecondFooPrev = T.beginMarker.next;
  if(!actualSecondFooPrev.equals(expectedSecondFooPrev)) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedSecondFooPrev: "+expectedSecondFooPrev +"\n"+
               "actualSecondFooPrev: "+actualSecondFooPrev+"\n"+"");
  }

  Comparable actualLastNode = T.beginMarker.next.next.next;
  Comparable expectedLastNode = T.endMarker;
  if(actualLastNode != expectedLastNode) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedLastNode: "+expectedLastNode +"\n"+
               "actualLastNode: "+actualLastNode+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_insertremoveLL4() {
// same as preceding only begin --> f2 --> f3 --> end

  Foo f1 = new Foo(1,1);
  Foo f2 = new Foo(2,1);
  Foo f3 = new Foo(3,1);

  MyHashTable T = new MyHashTable(3);
  T.insert(f1);
  T.insert(f2);
  T.insert(f3);
  T.remove(f1);

  Comparable actualFirstFoo = T.beginMarker.next.data;
  Comparable expectedFirstFoo = f2;
  if(actualFirstFoo.compareTo(expectedFirstFoo) != 0) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedFirstFoo: "+expectedFirstFoo +"\n"+
               "actualFirstFoo: "+actualFirstFoo+"\n"+"");
  }

  MyHashTable.MyListNode actualFirstFooPrev = T.beginMarker.next.prev;
  MyHashTable.MyListNode expectedFirstFooPrev = T.beginMarker;
  if(actualFirstFooPrev != expectedFirstFooPrev) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedFirstFooPrev: "+expectedFirstFooPrev +"\n"+
               "actualFirstFooPrev: "+actualFirstFooPrev+"\n"+"");
  }

  Comparable actualSecondFoo = T.beginMarker.next.next.data;
  Comparable expectedSecondFoo = f3;
  if(actualSecondFoo.compareTo(expectedSecondFoo) != 0) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedSecondFoo: "+expectedSecondFoo +"\n"+
               "actualSecondFoo: "+actualSecondFoo+"\n"+"");
  }

  MyHashTable.MyListNode actualSecondFooPrev = T.beginMarker.next.next.prev;
  MyHashTable.MyListNode expectedSecondFooPrev = T.beginMarker.next;
  if(!actualSecondFooPrev.equals(expectedSecondFooPrev)) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedSecondFooPrev: "+expectedSecondFooPrev +"\n"+
               "actualSecondFooPrev: "+actualSecondFooPrev+"\n"+"");
  }

  Comparable actualLastNode = T.beginMarker.next.next.next;
  Comparable expectedLastNode = T.endMarker;
  if(actualLastNode != expectedLastNode) {
       failFmt("MyHashTable insertListNodeBefore:\n"+
               "expectedLastNode: "+expectedLastNode +"\n"+
               "actualLastNode: "+actualLastNode+"\n"+"");
  }
  }

  // test MyHashTable iterator

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_iterator1() {
// iterate over empty table

   MyHashTable<Foo> T = new MyHashTable<Foo>(3);
	Iterator<Foo> i = T.iterator();

   boolean actualHasNext1 = i.hasNext();
	boolean expectedHasNext1 = false;
   if (actualHasNext1 != expectedHasNext1) {
       failFmt("MyHashTable iterator:\n"+
               "expectedHasNext1: " + expectedHasNext1 +"\n"+
               "actualHasNext1: " + actualHasNext1 + "");
   }
   }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_iterator2() {
// iterate over f3 --> f2 --> f1; note: iterate uses insertion order

   MyHashTable<Foo> T = new MyHashTable<Foo>(3);

   Foo f1 = new Foo(1,0);
   Foo f2 = new Foo(2,1);
   Foo f3 = new Foo(3,2);
   T.insert(f3);
   T.insert(f2);
   T.insert(f1);

	Iterator<Foo> i = T.iterator();

   boolean actualHasNext1 = i.hasNext();
	boolean expectedHasNext1 = true;
   if (actualHasNext1 != expectedHasNext1) {
       failFmt("MyHashTable iterator:\n"+
               "expectedHasNext1: " + expectedHasNext1 +"\n"+
               "actualHasNext1: " + actualHasNext1 + "");
   }
   Foo actualNext1 = i.next();
	Foo expectedNext1 = f3;
   if (actualNext1.compareTo(expectedNext1) != 0) {
       failFmt("MyHashTable iterator:\n"+
               "expectedNext1: " + expectedNext1 +"\n"+
               "actualNext1: " + actualNext1 + "");
   }
	
   boolean actualHasNext2 = i.hasNext();
	boolean expectedHasNext2 = true;
   if (actualHasNext2 != expectedHasNext2) {
       failFmt("MyHashTable iterator:\n"+
               "expectedHasNext2: " + expectedHasNext2 +"\n"+
               "actualHasNext2: " + actualHasNext2 + "");
   }
   Foo actualNext2 = i.next();
	Foo expectedNext2 = f2;
   if (actualNext2.compareTo(expectedNext2) != 0) {
       failFmt("MyHashTable iterator:\n"+
               "expectedNext2: " + expectedNext2 +"\n"+
               "actualNext2: " + actualNext2 + "");
   }

   boolean actualHasNext3 = i.hasNext();
	boolean expectedHasNext3 = true;
   if (actualHasNext3 != expectedHasNext3) {
       failFmt("MyHashTable iterator:\n"+
               "expectedHasNext3: " + expectedHasNext3 +"\n"+
               "actualHasNext3: " + actualHasNext3 + "");
   }
   Foo actualNext3 = i.next();
	Foo expectedNext3 = f1;
   if (actualNext3.compareTo(expectedNext3) != 0) {
       failFmt("MyHashTable iterator:\n"+
               "expectedNext3: " + expectedNext3 +"\n"+
               "actualNext3: " + actualNext3 + "");
   }

   boolean actualHasNext4 = i.hasNext();
	boolean expectedHasNext4 = false;
   if (actualHasNext4 != expectedHasNext4) {
       failFmt("MyHashTable iterator:\n"+
               "expectedHasNext4: " + expectedHasNext4 +"\n"+
               "actualHasNext4: " + actualHasNext4 + "");
   }
   }


@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_iterator3() {
// iterate over a single element 

   MyHashTable<Foo> T = new MyHashTable<Foo>(3);

   Foo f1 = new Foo(1,0);
   T.insert(f1);

	Iterator<Foo> i = T.iterator();

   boolean actualHasNext1 = i.hasNext();
	boolean expectedHasNext1 = true;
   if (actualHasNext1 != expectedHasNext1) {
       failFmt("MyHashTable iterator:\n"+
               "expectedHasNext1: " + expectedHasNext1 +"\n"+
               "actualHasNext1: " + actualHasNext1 + "");
   }
   Foo actualNext1 = i.next();
	Foo expectedNext1 = f1;
   if (actualNext1.compareTo(expectedNext1) != 0) {
       failFmt("MyHashTable iterator:\n"+
               "expectedNext1: " + expectedNext1 +"\n"+
               "actualNext1: " + actualNext1 + "");
   }
	
   boolean actualHasNext2 = i.hasNext();
	boolean expectedHasNext2 = false;
   if (actualHasNext2 != expectedHasNext2) {
       failFmt("MyHashTable iterator:\n"+
               "expectedHasNext2: " + expectedHasNext2 +"\n"+
               "actualHasNext2: " + actualHasNext2 + "");
   }
   }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_iterator4() {
// iterate over a single element 

   MyHashTable<Foo> T = new MyHashTable<Foo>(3);

   Foo f1 = new Foo(1,0);
   Foo f2 = new Foo(2,1);
   T.insert(f1);

	Iterator<Foo> i = T.iterator();
   boolean thrown = false;
   boolean hasN = i.hasNext();
   T.insert(f2);
   try {i.hasNext();}
   catch (ConcurrentModificationException e) {
      thrown = true;
   }

   boolean actualThrown = thrown;
   boolean expectedThrown = true;  // remove(4) did not modify C
   if(!thrown) {
       failFmt("MyHashTable iterator:\n"+
               "Expect: "+"ConcurrentModificationException" +"\n"+
               "Actual: "+"ConcurrentModificationException not thrown"+"\n"+"");
   }
   }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_iterator5() {
// iterate over a single element 

   MyHashTable<Foo> T = new MyHashTable<Foo>(3);

   Foo f1 = new Foo(1,0);
   T.insert(f1);

	Iterator<Foo> i = T.iterator();
   boolean thrown = false;
   boolean hasN = i.hasNext();
   T.remove(f1);
   try {i.hasNext();}
   catch (ConcurrentModificationException e) {
      thrown = true;
   }

   boolean actualThrown = thrown;
   boolean expectedThrown = true;  // remove(4) did not modify C
   if(!thrown) {
       failFmt("MyHashTable iterator:\n"+
               "Expect: "+"ConcurrentModificationException" +"\n"+
               "Actual: "+"ConcurrentModificationException not thrown"+"\n"+"");
   }
   }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashTable_iterator6() {
// iterate over a single element 

   MyHashTable<Foo> T = new MyHashTable<Foo>(3);

   Foo f1 = new Foo(1,0);
   T.insert(f1);

	Iterator<Foo> i = T.iterator();
   boolean thrown = false;
   boolean hasN = i.hasNext();
   T.clear();
   try {i.hasNext();}
   catch (ConcurrentModificationException e) {
      thrown = true;
   }

   boolean actualThrown = thrown;
   boolean expectedThrown = true;  // remove(4) did not modify C
   if(!thrown) {
       failFmt("MyHashTable iterator:\n"+
               "Expect: "+"ConcurrentModificationException" +"\n"+
               "Actual: "+"ConcurrentModificationException not thrown"+"\n"+"");
   }
   }

// test MyHashMap constructor

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_construct1() {
// test initial size 0

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  int actualSize = M.size();
  int expectedSize = 0;

  if(actualSize != expectedSize) {
       failFmt("MyHashMap constructor:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }
  }

// test MyHashMap put

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_put1() {
// test put

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  M.put(f1,"f1");
  int actualSize = M.getItems().size();
  int expectedSize = 1;

  if(actualSize != expectedSize) {
       failFmt("MyHashMap put:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_put2() {
// test put null

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  boolean thrown = false;
  try {M.put(f1,null);}
  catch (IllegalArgumentException e) {
    thrown = true;
  }
  if(!thrown) {
       failFmt("MyHashTable put:\n"+
               "Expect: "+"IllegalArgumentException" +"\n"+
               "Actual: "+" IllegalArgumentException not thrown"+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_put3() {
// test put null

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  boolean thrown = false;
  try {M.put(null,"f1");}
  catch (IllegalArgumentException e) {
    thrown = true;
  }
  if(!thrown) {
       failFmt("MyHashTable put:\n"+
               "Expect: "+"IllegalArgumentException" +"\n"+
               "Actual: "+" IllegalArgumentException not thrown"+"\n"+"");
  }
  }

// test MyHashMap get

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_get1() {
// test get return non-null
  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  M.put(f1,"f1");
  String actual = M.get(f1);
  String expected = "f1";
  if(actual != expected) {
       failFmt("MyHashMap get:\n"+
               "expected: "+expected +"\n"+
               "actual: "+actual+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_get2() {
// test get return null

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  M.put(f1,"f1");
  Foo f2 = new Foo(2,2);
  String actual = M.get(f2);
  String expected = null;
  if(actual != expected) {
       failFmt("MyHashMap get:\n"+
               "expected: "+expected +"\n"+
               "actual: "+actual+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_get3() {
// test get null

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  boolean thrown = false;
  try {M.get(null);}
  catch (IllegalArgumentException e) {
    thrown = true;
  }
  if(!thrown) {
       failFmt("MyHashTable get:\n"+
               "Expect: "+"IllegalArgumentException" +"\n"+
               "Actual: "+" IllegalArgumentException not thrown"+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_get4() {
// test get null

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  boolean thrown = false;
  try {M.get(null);}
  catch (IllegalArgumentException e) {
    thrown = true;
  }
  if(!thrown) {
       failFmt("MyHashTable get:\n"+
               "Expect: "+"IllegalArgumentException" +"\n"+
               "Actual: "+" IllegalArgumentException not thrown"+"\n"+"");
  }
  }

// test MyHashMap.Entry

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_entry1() {
// test hashCode

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  MyHashMap.Entry e1 = new MyHashMap.Entry(f1,"f1");

  int actualhashCode = e1.hashCode();
  int expectedhashCode = 1;
  if(actualhashCode != expectedhashCode) {
       failFmt("MMyHashMap.Entry hashCode:\n"+
               "expectedhashCode: "+expectedhashCode +"\n"+
               "actualhashCode: "+actualhashCode+"\n"+"");
  } 
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_entry2() {
// test equals true

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  MyHashMap.Entry e1 = new MyHashMap.Entry(f1,"f1");

  boolean actualEquals = e1.equals(e1);
  boolean expectedEquals = true;
  if(actualEquals != expectedEquals) {
       failFmt("MyHashMap.Entry equals:\n"+
               "expectedEquals: "+expectedEquals +"\n"+
               "actualEquals: "+actualEquals+"\n"+"");
  } 
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_entry3() {
// test equals false

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  MyHashMap.Entry e1 = new MyHashMap.Entry(f1,"f1");
  Foo f2 = new Foo(2,1);
  MyHashMap.Entry e2 = new MyHashMap.Entry(f2,"f2");

  boolean actualEquals = e1.equals(e2);
  boolean expectedEquals = false;
  if(actualEquals != expectedEquals) {
       failFmt("MMyHashMap.Entry equals:\n"+
               "expectedEquals: "+expectedEquals +"\n"+
               "actualEquals: "+actualEquals+"\n"+"");
  } 
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_entry4() {
// test getKey

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  MyHashMap.Entry e1 = new MyHashMap.Entry(f1,"f1");

  Foo actual = (Foo) e1.getKey();
  Foo expected = f1;
  if(actual != expected) {
       failFmt("MyHashMap.Entry getKey:\n"+
               "expectedEquals: "+expected +"\n"+
               "actual: "+actual+"\n"+"");
  } 
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_entry5() {
// test getValue

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  MyHashMap.Entry e1 = new MyHashMap.Entry(f1,"f1");

  String actual = (String) e1.getValue();
  String expected = "f1";
  if(actual != expected) {
       failFmt("MyHashMap.Entry getValue:\n"+
               "expectedEquals: "+expected +"\n"+
               "actual: "+actual+"\n"+"");
  } 
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_entry6() {
// test compareTo : 0

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  MyHashMap.Entry e1 = new MyHashMap.Entry(f1,"f1");

  int actual = e1.compareTo(e1);
  int expected = 0;
  if(actual != expected) {
       failFmt("MyHashMap.Entry compareTo:\n"+
               "expected: "+expected +"\n"+
               "actual: "+actual+"\n"+"");
  } 
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_entry7() {
// test compareTo: -1

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  MyHashMap.Entry e1 = new MyHashMap.Entry(f1,"f1");
  Foo f2 = new Foo(2,1);
  MyHashMap.Entry e2 = new MyHashMap.Entry(f2,"f2");

  int actual = e1.compareTo(e2);
  int expected = -1;
  if(actual != expected) {
       failFmt("MyHashMap.Entry compareTo:\n"+
               "expected: "+expected +"\n"+
               "actual: "+actual+"\n"+"");
  }  
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_entry8() {
// test compareTo: 1

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  MyHashMap.Entry e1 = new MyHashMap.Entry(f1,"f1");
  Foo f2 = new Foo(0,1);
  MyHashMap.Entry e2 = new MyHashMap.Entry(f2,"f2");

  int actual = e1.compareTo(e2);
  int expected = 1;
  if(actual != expected) {
       failFmt("MyHashMap.Entry compareTo:\n"+
               "expected: "+expected +"\n"+
               "actual: "+actual+"\n"+"");
  }  
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_entry9() {
// test toString "(1, f1)"

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  MyHashMap.Entry e1 = new MyHashMap.Entry(f1,"f1");

  String actual = e1.toString().replaceAll("\\s+","");
  String expected = "(1, f1)".replaceAll("\\s+","");
  if(!actual.equals(expected)) {
       failFmt("MyHashMap.Entry toString:\n"+
               "expected: "+expected +"\n"+
               "actual: "+actual+"\n"+"");
  }  
  }

// test MyHashMap entrySet

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_entrySet1() {
// test entrySet with Set of 2 Entries - order of entry of 
// underlying hash table is not required/checked

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  M.put(f1,"f1");
  Foo f2 = new Foo(2,2);
  M.put(f2,"f2");
  Set s = M.entrySet();

  int actualSize = s.size();
  int expectedSize = 2;
  if(actualSize != expectedSize) {
       failFmt("MyHashMap entrySet:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }

  MyHashMap.Entry e1 = new MyHashMap.Entry(f1,"f1");

  boolean actualcontainsf1 = s.contains(e1);
  boolean expectedcontainsf1 = true;
  if(actualcontainsf1 != expectedcontainsf1) {
       failFmt("MyHashMap entrySet:\n"+
               "expectedcontainsf1: "+expectedcontainsf1 +"\n"+
               "actualcontainsf1: "+actualcontainsf1+"\n"+"");
  }

  MyHashMap.Entry e2 = new MyHashMap.Entry(f2,"f2");

  boolean actualcontainsf2 = s.contains(e1);
  boolean expectedcontainsf2 = true;
  if(actualcontainsf2 != expectedcontainsf2) {
       failFmt("MyHashMap entrySet:\n"+
               "expectedcontainsf2: "+expectedcontainsf2 +"\n"+
               "actualcontainsf2: "+actualcontainsf2+"\n"+"");
  }
  }

// test MyHashMap clear

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_clear1() {
// test initial size 0

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  M.put(f1,"f1");
  M.clear();
  
  int actualSize = M.size();
  int expectedSize = 0;

  if(actualSize != expectedSize) {
       failFmt("MyHashMap clear:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }
  }

// test MyHashMap size

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_size1() {
// test size after put

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  M.put(f1,"f1");
  int actualSize = M.size();
  int expectedSize = 1;

  if(actualSize != expectedSize) {
       failFmt("MyHashMap size:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }
  }

// test MyHashMap isEmpty

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_isEmpty1() {
// test initial isEmpty 0

  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  boolean actual = M.isEmpty();
  boolean expected = true;

  if(actual != expected) {
       failFmt("MyHashMap isEmpty:\n"+
               "expected: "+expected +"\n"+
               "actual: "+actual+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void MyHashMap_isEmpty2() {
// test isEmpty after put
  MyHashMap<Foo,String> M = new MyHashMap<Foo,String>();
  Foo f1 = new Foo(1,1);
  M.put(f1,"f1");
  boolean actual = M.isEmpty();
  boolean expected = false;

  if(actual != expected) {
       failFmt("MyHashMap isEmpty:\n"+
               "expected: "+expected +"\n"+
               "actual: "+actual+"\n"+"");
  }
  }


// test StockExchange.Orders equals  // given in the spec

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_Order_equals1() {
// equal orders
  StockExchange.Order FBOrder1 = new StockExchange.Order(new String("FB"),(short)10221,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));
  StockExchange.Order FBOrder2 = new StockExchange.Order(new String("FB"),(short)10221,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));

  boolean actualEquals = FBOrder1.equals(FBOrder2);
  boolean expectedEquals = true;
  if(actualEquals != expectedEquals) {
       failFmt("StockExchange.Order equals:\n"+
               "expectedEquals: "+expectedEquals +"\n"+
               "actualEquals: "+actualEquals+"\n"+"");
  } 
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_Order_equals2() {
// unequal orders due to symbol
  StockExchange.Order FBOrder1 = new StockExchange.Order(new String("FB"),(short)10221,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));
  StockExchange.Order FBOrder2 = new StockExchange.Order(new String("B"),(short)10221,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));

  boolean actualEquals = FBOrder1.equals(FBOrder2);
  boolean expectedEquals = false;
  if(actualEquals != expectedEquals) {
       failFmt("StockExchange.Order equals:\n"+
               "expectedEquals: "+expectedEquals +"\n"+
               "actualEquals: "+actualEquals+"\n"+"");
  } 
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_Order_equals3() {
// unequal orders due to price
  StockExchange.Order FBOrder1 = new StockExchange.Order(new String("FB"),(short)10221,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));
  StockExchange.Order FBOrder2 = new StockExchange.Order(new String("FB"),(short)10220,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));

  boolean actualEquals = FBOrder1.equals(FBOrder2);
  boolean expectedEquals = false;
  if(actualEquals != expectedEquals) {
       failFmt("StockExchange.Order equals:\n"+
               "expectedEquals: "+expectedEquals +"\n"+
               "actualEquals: "+actualEquals+"\n"+"");
  } 
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_Order_equals4() {
// unequal orders due to shares
  StockExchange.Order FBOrder1 = new StockExchange.Order(new String("FB"),(short)10221,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));
  StockExchange.Order FBOrder2 = new StockExchange.Order(new String("FB"),(short)10221,99,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));

  boolean actualEquals = FBOrder1.equals(FBOrder2);
  boolean expectedEquals = false;
  if(actualEquals != expectedEquals) {
       failFmt("StockExchange.Order equals:\n"+
               "expectedEquals: "+expectedEquals +"\n"+
               "actualEquals: "+actualEquals+"\n"+"");
  } 
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_Order_equals5() {
// unequal orders due to type
  StockExchange.Order FBOrder1 = new StockExchange.Order(new String("FB"),(short)10221,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));
  StockExchange.Order FBOrder2 = new StockExchange.Order(new String("FB"),(short)10221,100,StockExchange.Order.ordertype.BUY,new String("ETRADE"),new String("Schwab"));

  boolean actualEquals = FBOrder1.equals(FBOrder2);
  boolean expectedEquals = false;
  if(actualEquals != expectedEquals) {
       failFmt("StockExchange.Order equals:\n"+
               "expectedEquals: "+expectedEquals +"\n"+
               "actualEquals: "+actualEquals+"\n"+"");
  } 
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_Order_equals6() {
// unequal orders due to buyer
  StockExchange.Order FBOrder1 = new StockExchange.Order(new String("FB"),(short)10221,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));
  StockExchange.Order FBOrder2 = new StockExchange.Order(new String("FB"),(short)10221,100,StockExchange.Order.ordertype.TRADE,new String("E"),new String("Schwab"));

  boolean actualEquals = FBOrder1.equals(FBOrder2);
  boolean expectedEquals = false;
  if(actualEquals != expectedEquals) {
       failFmt("StockExchange.Order equals:\n"+
               "expectedEquals: "+expectedEquals +"\n"+
               "actualEquals: "+actualEquals+"\n"+"");
  } 
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_Order_equals7() {
// unequal orders due to seller
  StockExchange.Order FBOrder1 = new StockExchange.Order(new String("FB"),(short)10221,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));
  StockExchange.Order FBOrder2 = new StockExchange.Order(new String("FB"),(short)10221,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("S"));

  boolean actualEquals = FBOrder1.equals(FBOrder2);
  boolean expectedEquals = false;
  if(actualEquals != expectedEquals) {
       failFmt("StockExchange.Order equals:\n"+
               "expectedEquals: "+expectedEquals +"\n"+
               "actualEquals: "+actualEquals+"\n"+"");
  } 
}

// test StockExchange.Order compareTo

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_compareTo1() {
// test compareTo : 0

  StockExchange.Order FBOrder1 = new StockExchange.Order(new String("FB"),(short)1,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));
  StockExchange.Order FBOrder2 = new StockExchange.Order(new String("FB"),(short)1,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));

  
  int actualValue = FBOrder1.compareTo(FBOrder2);
  int expectedValue = 0;
  if(actualValue != expectedValue) {
       failFmt("StockExchange.Order.compareTo:\n"+
               "expectedValue: "+expectedValue +"\n"+
               "actualValue: "+actualValue+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_compareTo2() {
// test compareTo : -1

  StockExchange.Order FBOrder1 = new StockExchange.Order(new String("FB"),(short)1,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));
  StockExchange.Order FBOrder2 = new StockExchange.Order(new String("FB"),(short)2,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));

  
  int actualValue = FBOrder1.compareTo(FBOrder2);
  int expectedValue = -1;
  if(actualValue != expectedValue) {
       failFmt("StockExchange.Order.compareTo:\n"+
               "expectedValue: "+expectedValue +"\n"+
               "actualValue: "+actualValue+"\n"+"");
  }
  }

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_compareTo3() {
// test compareTo : 1

  StockExchange.Order FBOrder1 = new StockExchange.Order(new String("FB"),(short)1,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));
  StockExchange.Order FBOrder2 = new StockExchange.Order(new String("FB"),(short)0,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));

  
  int actualValue = FBOrder1.compareTo(FBOrder2);
  int expectedValue = 1;
  if(actualValue != expectedValue) {
       failFmt("StockExchange.Order.compareTo:\n"+
               "expectedValue: "+expectedValue +"\n"+
               "actualValue: "+actualValue+"\n"+"");
  }
  }


// test StockExchange.Orders toString  // given in the spec

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_Order_toString1() {
  StockExchange.Order FBOrder = new StockExchange.Order("FB",(short)10221,100,StockExchange.Order.ordertype.TRADE,"ETRADE","Schwab");
  String actualString = FBOrder.toString().replaceAll("\\s+","");
  String expectedString = new String("FB,TRADE,10221,100,ETRADE,Schwab").replaceAll("\\s+","");
  if(!actualString.equals(expectedString)) {
       failFmt("StockExchange.Order toString:\n"+
               "expectedString: "+expectedString +"\n"+
               "actualString: "+actualString+"\n"+"");
  } 
}

// test StockExchange.Orders hashCode 

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_Order_equalhashCodes() {
// equal orders must have equal hashCodes
  StockExchange.Order FBOrder1 = new StockExchange.Order(new String("FB"),(short)10221,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));
  StockExchange.Order FBOrder2 = new StockExchange.Order(new String("FB"),(short)10221,100,StockExchange.Order.ordertype.TRADE,new String("ETRADE"),new String("Schwab"));

  boolean actualEquals = FBOrder1.equals(FBOrder2);
  boolean expectedEquals = true;
  if(actualEquals != expectedEquals) {
       failFmt("StockExchange.Order equals:\n"+
               "expectedEquals: "+expectedEquals +"\n"+
               "actualEquals: "+actualEquals+"\n"+"");
  } 

  boolean actualEqualhashCodes = FBOrder1.hashCode() == FBOrder2.hashCode();
  boolean expectedEqualhashCodes = true;
  if(actualEqualhashCodes != expectedEqualhashCodes) {
       failFmt("StockExchange.Order equal hashCodes:\n"+
               "expectedEqualhashCodes: "+expectedEqualhashCodes +"\n"+
               "actualEqualhashCodes: "+actualEqualhashCodes+"\n"+"");
  } 
}


// test StockExchange getLowestSellOrderPrice

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_getLowestSellOrderPrice1() {

  StockExchange E = new StockExchange();
  E.lowestSellOrderPrice = 10;
  int actualPrice = E.getLowestSellOrderPrice();
  int expectedPrice = 10;

  if(actualPrice != expectedPrice) {
       failFmt("StockExchange getLowestSellOrderPrice:\n"+
               "expectedPrice: "+expectedPrice +"\n"+
               "actualPrice: "+actualPrice+"\n"+"");
  }

}

// test StockExchange getHighestBuyOrderPrice

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_getHighestBuyOrderPrice1() {

  StockExchange E = new StockExchange();
  E.highestBuyOrderPrice = 10;
  int actualPrice = E.getHighestBuyOrderPrice();
  int expectedPrice = 10;

  if(actualPrice != expectedPrice) {
       failFmt("StockExchange getHighestBuyOrderPrice:\n"+
               "expectedPrice: "+expectedPrice +"\n"+
               "actualPrice: "+actualPrice+"\n"+"");
  }
}

// test StockExchange readOrder

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_readOrder1() {

  StockExchange E = new StockExchange();
  String orderString = "GOOG buy 30000 75 ETRADE Seller";
  Scanner s = new Scanner(orderString);
  StockExchange.Order actualOrder = E.readOrder(s);
  StockExchange.Order expectedOrder = 
    new StockExchange.Order("GOOG",(short)30000,75,StockExchange.Order.ordertype.BUY,"ETRADE","Seller");

  if(!actualOrder.equals(expectedOrder)) {
       failFmt("StockExchange readOrder:\n"+
               "expectedOrder: "+expectedOrder +"\n"+
               "actualOrder: "+actualOrder+"\n"+"");
  }
}

// test StockExchange readAllOrders

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_readAllOrders1() {
// test readAllOrders with Scanner containing 3 lines: number of lines + 2 orders
  StockExchange E = new StockExchange();
  String orderString = "2" + "\n" + "GOOG buy 30000 75 ETRADE Seller" + "\n" + "FB sell 10219 100 Buyer Schwab";
  Scanner s = new Scanner(orderString);
  List<StockExchange.Order> actualOrderList = E.readAllOrders(s);

  int actualSize = actualOrderList.size();
  int expectedSize = 2;

  if(actualSize != expectedSize) {
       failFmt("StockExchange readAllOrders:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }

  StockExchange.Order GOOGOrder = new StockExchange.Order("GOOG",(short)30000,75,StockExchange.Order.ordertype.BUY,"ETRADE","Seller");
  boolean actualContains = actualOrderList.contains(GOOGOrder);
  boolean expectedContains = true;

  if(actualContains != expectedContains) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedContains: "+expectedContains +"\n"+
               "actualContains: "+actualContains+"\n"+"");
  } 

  StockExchange.Order FBOrder = new StockExchange.Order("FB",(short)10219,100,StockExchange.Order.ordertype.SELL,"Buyer","Schwab");
  boolean actualContains1 = actualOrderList.contains(FBOrder);
  boolean expectedContains1 = true;

  if(actualContains1 != expectedContains1) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedContains1: "+expectedContains1 +"\n"+
               "actualContains1: "+actualContains1+"\n"+"");
  } 
}


// test StockExchange tradeAll

/*
5
GOOG buy 30000 75 ETrade Seller 
FB sell 10219 100 Buyer Schwab 
GOOG sell 29999 50 Buyer Schwab
FB buy 10221 100 ETrade Seller
GOOG sell 29950 25 ETrade Seller 
*/


@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_tradeAll1() {
// matching buy and sell
  StockExchange E = new StockExchange();
  List<StockExchange.Order> orders = new ArrayList<StockExchange.Order>();
  orders.add(new StockExchange.Order("FB",(short)10219,100,StockExchange.Order.ordertype.SELL,"Buyer","Schwab"));
  orders.add(new StockExchange.Order("FB",(short)10221,100,StockExchange.Order.ordertype.BUY,"ETRADE","Seller"));
  E.lowestSellOrderPrice = 10219;
  E.highestBuyOrderPrice = 10221;

  E.tradeAll(orders);
  MyHashMap<String,ArrayList<StockExchange.Order>> trades = E.getTrades();
  ArrayList<StockExchange.Order> tradeList = trades.get("FB");

  int actualSize = tradeList.size();
  int expectedSize = 1;

  if(actualSize != expectedSize) {
       failFmt("StockExchange tradeAll:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }

  StockExchange.Order FBTrade = tradeList.get(0);
  String actualString = FBTrade.toString().replaceAll("\\s+","");
  String expectedString = new String("FB,TRADE,10219,100,ETRADE,Schwab").replaceAll("\\s+","");
  if(!actualString.equals(expectedString)) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedString: "+expectedString +"\n"+
               "actualString: "+actualString+"\n"+"");
  } 
  
}


@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_tradeAll2() {
// matching buy and sell
  StockExchange E = new StockExchange();
  List<StockExchange.Order> orders = new ArrayList<StockExchange.Order>();
  orders.add(new StockExchange.Order("GOOG",(short)30000,75,StockExchange.Order.ordertype.BUY,"ETRADE","Seller"));
  orders.add(new StockExchange.Order("GOOG",(short)29999,25,StockExchange.Order.ordertype.SELL,"Buyer","Schwab"));
  E.lowestSellOrderPrice = 29999;
  E.highestBuyOrderPrice = 30000;

  E.tradeAll(orders);
  MyHashMap<String,ArrayList<StockExchange.Order>> trades = E.getTrades();
  ArrayList<StockExchange.Order> tradeList = trades.get("GOOG");

  int actualSize = tradeList.size();
  int expectedSize = 1;

  if(actualSize != expectedSize) {
       failFmt("StockExchange tradeAll:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }

  StockExchange.Order GOOGTrade = tradeList.get(0);
  String actualString = GOOGTrade.toString().replaceAll("\\s+","");
  String expectedString = new String("GOOG,TRADE,30000,25,ETRADE,Schwab").replaceAll("\\s+","");
  if(!actualString.equals(expectedString)) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedString: "+expectedString +"\n"+
               "actualString: "+actualString+"\n"+"");
  } 
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_tradeAll3() {
// matching buy and sell
  StockExchange E = new StockExchange();
  List<StockExchange.Order> orders = new ArrayList<StockExchange.Order>();
  orders.add(new StockExchange.Order("GOOG",(short)30000,50,StockExchange.Order.ordertype.BUY,"ETRADE","Seller"));
  orders.add(new StockExchange.Order("GOOG",(short)29950,50,StockExchange.Order.ordertype.SELL,"Buyer","Schwab"));
  E.lowestSellOrderPrice = 29950;
  E.highestBuyOrderPrice = 30000;

  E.tradeAll(orders);
  MyHashMap<String,ArrayList<StockExchange.Order>> trades = E.getTrades();
  ArrayList<StockExchange.Order> tradeList = trades.get("GOOG");

  int actualSize = tradeList.size();
  int expectedSize = 1;

  if(actualSize != expectedSize) {
       failFmt("StockExchange tradeAll:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }

  StockExchange.Order GOOGTrade = tradeList.get(0);
  String actualString = GOOGTrade.toString().replaceAll("\\s+","");
  String expectedString = new String("GOOG,TRADE,30000,50,ETRADE,Schwab").replaceAll("\\s+","");
  if(!actualString.equals(expectedString)) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedString: "+expectedString +"\n"+
               "actualString: "+actualString+"\n"+"");
  } 
  
}


@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_tradeAll4() {
// matching buys and sells: 75 - 25 = 50 for second match
  StockExchange E = new StockExchange();
  List<StockExchange.Order> orders = new ArrayList<StockExchange.Order>();
  orders.add(new StockExchange.Order("GOOG",(short)30000,75,StockExchange.Order.ordertype.BUY,"ETRADE","Seller"));
  orders.add(new StockExchange.Order("GOOG",(short)29999,25,StockExchange.Order.ordertype.SELL,"Buyer","Schwab"));
  orders.add(new StockExchange.Order("GOOG",(short)29950,50,StockExchange.Order.ordertype.SELL,"Buyer","Schwab"));
  E.lowestSellOrderPrice = 29950;
  E.highestBuyOrderPrice = 30000;

  E.tradeAll(orders);
  MyHashMap<String,ArrayList<StockExchange.Order>> trades = E.getTrades();
  ArrayList<StockExchange.Order> tradeList = trades.get("GOOG");

  int actualSize = tradeList.size();
  int expectedSize = 2;

  if(actualSize != expectedSize) {
       failFmt("StockExchange tradeAll:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }
  //System.out.println();
  //System.out.println(tradeList.get(0));
  //System.out.println(tradeList.get(1));
  StockExchange.Order GOOGTrade = new StockExchange.Order("GOOG",(short)30000,25,StockExchange.Order.ordertype.TRADE,"ETRADE","Schwab");
  boolean actualContains = tradeList.contains(GOOGTrade);
  boolean expectedContains = true;

  if(actualContains != expectedContains) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedContains: "+expectedContains +"\n"+
               "actualContains: "+actualContains+"\n"+"");
  } 

  StockExchange.Order GOOGTrade1 = new StockExchange.Order("GOOG",(short)30000,50,StockExchange.Order.ordertype.TRADE,"ETRADE","Schwab");
  boolean actualContains1 = tradeList.contains(GOOGTrade1);
  boolean expectedContains1 = true;

  if(actualContains1 != expectedContains1) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedContains1: "+expectedContains1 +"\n"+
               "actualContains1: "+actualContains1+"\n"+"");
  } 
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_tradeAll5() {
// matching buy and sell
  StockExchange E = new StockExchange();
  List<StockExchange.Order> orders = new ArrayList<StockExchange.Order>();
  orders.add(new StockExchange.Order("FB",(short)10221,100,StockExchange.Order.ordertype.BUY,"ETRADE","Seller"));
  orders.add(new StockExchange.Order("FB",(short)10219,100,StockExchange.Order.ordertype.SELL,"Buyer","Schwab"));
  E.lowestSellOrderPrice = 10219;
  E.highestBuyOrderPrice = 10221;

  E.tradeAll(orders);
  MyHashMap<String,ArrayList<StockExchange.Order>> trades = E.getTrades();
  ArrayList<StockExchange.Order> tradeList = trades.get("FB");

  int actualSize = tradeList.size();
  int expectedSize = 1;

  if(actualSize != expectedSize) {
       failFmt("StockExchange tradeAll:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }

  StockExchange.Order FBTrade = tradeList.get(0);
  String actualString = FBTrade.toString().replaceAll("\\s+","");
  String expectedString = new String("FB,TRADE,10221,100,ETRADE,Schwab").replaceAll("\\s+","");
  if(!actualString.equals(expectedString)) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedString: "+expectedString +"\n"+
               "actualString: "+actualString+"\n"+"");
  } 
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_tradeAll6() {
// matching buy and sell
  StockExchange E = new StockExchange();
  List<StockExchange.Order> orders = new ArrayList<StockExchange.Order>();
  orders.add(new StockExchange.Order("GOOG",(short)29999,75,StockExchange.Order.ordertype.SELL,"Buyer","Schwab"));
  orders.add(new StockExchange.Order("GOOG",(short)30000,25,StockExchange.Order.ordertype.BUY,"ETRADE","Seller"));
  E.lowestSellOrderPrice = 29999;
  E.highestBuyOrderPrice = 30000;

  E.tradeAll(orders);
  MyHashMap<String,ArrayList<StockExchange.Order>> trades = E.getTrades();
  ArrayList<StockExchange.Order> tradeList = trades.get("GOOG");

  int actualSize = tradeList.size();
  int expectedSize = 1;

  if(actualSize != expectedSize) {
       failFmt("StockExchange tradeAll:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }

  StockExchange.Order GOOGTrade = tradeList.get(0);
  String actualString = GOOGTrade.toString().replaceAll("\\s+","");
  String expectedString = new String("GOOG,TRADE,29999,25,ETRADE,Schwab").replaceAll("\\s+","");
  if(!actualString.equals(expectedString)) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedString: "+expectedString +"\n"+
               "actualString: "+actualString+"\n"+"");
  } 
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_tradeAll7() {
// matching buy and sell
  StockExchange E = new StockExchange();
  List<StockExchange.Order> orders = new ArrayList<StockExchange.Order>();
  orders.add(new StockExchange.Order("GOOG",(short)29950,50,StockExchange.Order.ordertype.SELL,"Buyer","Schwab"));
  orders.add(new StockExchange.Order("GOOG",(short)30000,50,StockExchange.Order.ordertype.BUY,"ETRADE","Seller"));
  E.lowestSellOrderPrice = 29950;
  E.highestBuyOrderPrice = 30000;

  E.tradeAll(orders);
  MyHashMap<String,ArrayList<StockExchange.Order>> trades = E.getTrades();
  ArrayList<StockExchange.Order> tradeList = trades.get("GOOG");

  int actualSize = tradeList.size();
  int expectedSize = 1;

  if(actualSize != expectedSize) {
       failFmt("StockExchange tradeAll:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }

  StockExchange.Order GOOGTrade = tradeList.get(0);
  String actualString = GOOGTrade.toString().replaceAll("\\s+","");
  String expectedString = new String("GOOG,TRADE,29950,50,ETRADE,Schwab").replaceAll("\\s+","");
  if(!actualString.equals(expectedString)) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedString: "+expectedString +"\n"+
               "actualString: "+actualString+"\n"+"");
  } 
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_tradeAll8() {
// matching buy and sell
  StockExchange E = new StockExchange();
  List<StockExchange.Order> orders = new ArrayList<StockExchange.Order>();
  orders.add(new StockExchange.Order("GOOG",(short)29950,75,StockExchange.Order.ordertype.SELL,"Buyer","Schwab"));
  orders.add(new StockExchange.Order("GOOG",(short)30000,25,StockExchange.Order.ordertype.BUY,"ETRADE","Seller"));
  orders.add(new StockExchange.Order("GOOG",(short)29999,50,StockExchange.Order.ordertype.BUY,"ETRADE","Seller"));
  E.lowestSellOrderPrice = 29950;
  E.highestBuyOrderPrice = 30000;

  E.tradeAll(orders);
  MyHashMap<String,ArrayList<StockExchange.Order>> trades = E.getTrades();
  ArrayList<StockExchange.Order> tradeList = trades.get("GOOG");

  int actualSize = tradeList.size();
  int expectedSize = 2;

  if(actualSize != expectedSize) {
       failFmt("StockExchange tradeAll:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }

  StockExchange.Order GOOGTrade = new StockExchange.Order("GOOG",(short)29950,25,StockExchange.Order.ordertype.TRADE,"ETRADE","Schwab");
  boolean actualContains = tradeList.contains(GOOGTrade);
  boolean expectedContains = true;

  if(actualContains != expectedContains) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedContains: "+expectedContains +"\n"+
               "actualContains: "+actualContains+"\n"+"");
  } 

  StockExchange.Order GOOGTrade1 = new StockExchange.Order("GOOG",(short)29950,50,StockExchange.Order.ordertype.TRADE,"ETRADE","Schwab");
  boolean actualContains1 = tradeList.contains(GOOGTrade1);
  boolean expectedContains1 = true;

  if(actualContains1 != expectedContains1) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedContains1: "+expectedContains1 +"\n"+
               "actualContains1: "+actualContains1+"\n"+"");
  } 
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_tradeAll9() {
// matching buy and sell (similar to example from spec)
  StockExchange E = new StockExchange();
  List<StockExchange.Order> orders = new ArrayList<StockExchange.Order>();
  orders.add(new StockExchange.Order("GOOG",(short)29950,75,StockExchange.Order.ordertype.SELL,"Buyer","Schwab"));
  orders.add(new StockExchange.Order("FB",(short)10219,100,StockExchange.Order.ordertype.SELL,"Buyer","Schwab"));
  orders.add(new StockExchange.Order("GOOG",(short)30000,25,StockExchange.Order.ordertype.BUY,"ETRADE","Seller"));
  orders.add(new StockExchange.Order("FB",(short)10221,100,StockExchange.Order.ordertype.BUY,"ETRADE","Seller"));
  orders.add(new StockExchange.Order("GOOG",(short)29999,50,StockExchange.Order.ordertype.BUY,"ETRADE","Seller"));

  E.lowestSellOrderPrice = 10219;
  E.highestBuyOrderPrice = 30000;

  E.tradeAll(orders);
  MyHashMap<String,ArrayList<StockExchange.Order>> trades = E.getTrades();

  ArrayList<StockExchange.Order> tradeList = trades.get("GOOG");

  int actualSize = tradeList.size();
  int expectedSize = 2;

  if(actualSize != expectedSize) {
       failFmt("StockExchange tradeAll:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }

  StockExchange.Order GOOGTrade = new StockExchange.Order("GOOG",(short)29950,25,StockExchange.Order.ordertype.TRADE,"ETRADE","Schwab");
  boolean actualContains = tradeList.contains(GOOGTrade);
  boolean expectedContains = true;

  if(actualContains != expectedContains) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedContains: "+expectedContains +"\n"+
               "actualContains: "+actualContains+"\n"+"");
  } 

  StockExchange.Order GOOGTrade1 = new StockExchange.Order("GOOG",(short)29950,50,StockExchange.Order.ordertype.TRADE,"ETRADE","Schwab");
  boolean actualContains1 = tradeList.contains(GOOGTrade1);
  boolean expectedContains1 = true;

  if(actualContains1 != expectedContains1) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedContains1: "+expectedContains1 +"\n"+
               "actualContains1: "+actualContains1+"\n"+"");
  }

  tradeList = trades.get("FB");

  int actualSize1 = tradeList.size();
  int expectedSize1 = 1;

  if(actualSize1 != expectedSize1) {
       failFmt("StockExchange tradeAll:\n"+
               "expectedSize1: "+expectedSize1 +"\n"+
               "actualSize1: "+actualSize1+"\n"+"");
  }

  StockExchange.Order FBTrade = new StockExchange.Order("FB",(short)10219,100,StockExchange.Order.ordertype.TRADE,"ETRADE","Schwab");
  boolean actualContains2 = tradeList.contains(FBTrade);
  boolean expectedContains2 = true;

  if(actualContains2 != expectedContains2) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedContains2: "+expectedContains2 +"\n"+
               "actualContains2: "+actualContains2+"\n"+"");
  } 
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_tradeAll10() {
// no match
  StockExchange E = new StockExchange();
  List<StockExchange.Order> orders = new ArrayList<StockExchange.Order>();
  StockExchange.Order FB_sell = new StockExchange.Order("FB",(short)10219,100,StockExchange.Order.ordertype.SELL,"Buyer","Schwab");
  E.lowestSellOrderPrice = 10219;
  E.highestBuyOrderPrice = 32767;

  orders.add(FB_sell);
  E.tradeAll(orders);
  MyHashMap<String,ArrayList<StockExchange.Order>> trades = E.getTrades();

  int actualSize = trades.size();
  int expectedSize = 0;

  if(actualSize != expectedSize) {
       failFmt("StockExchange tradeAll:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }

  ArrayList<ArrayList<StockExchange.Order>> submittedOrders = E.getSubmittedOrders();
  ArrayList<StockExchange.Order> actualOrderList = submittedOrders.get(10219);
  StockExchange.Order actualOrder = actualOrderList.get(0);

  if(actualOrder == null || !actualOrder.equals(FB_sell)) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedOrder: "+FB_sell +"\n"+
               "actualOrder: "+actualOrder+"\n"+"");
  } 
}


@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_tradeAll11() {
// no match
  StockExchange E = new StockExchange();
  List<StockExchange.Order> orders = new ArrayList<StockExchange.Order>();
  StockExchange.Order FB_buy =  new StockExchange.Order("FB",(short)10221,100,StockExchange.Order.ordertype.BUY,"ETRADE","Seller");
  E.lowestSellOrderPrice = 0;
  E.highestBuyOrderPrice = 10221;

  orders.add(FB_buy);
  E.lowestSellOrderPrice = 10221;

  E.tradeAll(orders);
  MyHashMap<String,ArrayList<StockExchange.Order>> trades = E.getTrades();

  int actualSize = trades.size();
  int expectedSize = 0;

  if(actualSize != expectedSize) {
       failFmt("StockExchange tradeAll:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }

  ArrayList<ArrayList<StockExchange.Order>> submittedOrders = E.getSubmittedOrders();
  ArrayList<StockExchange.Order> actualOrderList = submittedOrders.get(10221);
  StockExchange.Order actualOrder = actualOrderList.get(0);

  if(actualOrder == null || !actualOrder.equals(FB_buy)) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedOrder: "+FB_buy +"\n"+
               "actualOrder: "+actualOrder+"\n"+"");
  } 
}

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_tradeAll12() {
// matching 25 + 25 buys with 75 - 50 shares left over
  StockExchange E = new StockExchange();
  List<StockExchange.Order> orders = new ArrayList<StockExchange.Order>();

  orders.add(new StockExchange.Order("GOOG",(short)29950,75,StockExchange.Order.ordertype.SELL,"Buyer","Schwab"));
  orders.add(new StockExchange.Order("GOOG",(short)30000,25,StockExchange.Order.ordertype.BUY,"ETRADE","Seller"));
  orders.add(new StockExchange.Order("GOOG",(short)29999,25,StockExchange.Order.ordertype.BUY,"ETRADE","Seller"));
  E.lowestSellOrderPrice = 29950;
  E.highestBuyOrderPrice = 30000;

  E.tradeAll(orders);
  MyHashMap<String,ArrayList<StockExchange.Order>> trades = E.getTrades();

  ArrayList<StockExchange.Order> tradeList = trades.get("GOOG");
  int actualSize = tradeList.size();
  int expectedSize = 2;

  if(actualSize != expectedSize) {
       failFmt("StockExchange tradeAll:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }

  ArrayList<ArrayList<StockExchange.Order>> submittedOrders = E.getSubmittedOrders();
  ArrayList<StockExchange.Order> actualOrderList = submittedOrders.get(29950);
  StockExchange.Order actualOrder = actualOrderList.get(0);

  StockExchange.Order GOOG_sell =  
     new StockExchange.Order("GOOG",(short)29950,25,StockExchange.Order.ordertype.SELL,"Buyer","Schwab");

  if(actualOrder == null || !actualOrder.equals(GOOG_sell)) {
       failFmt("StockExchange.Order tradeAll:\n"+
               "expectedOrder: "+GOOG_sell +"\n"+
               "actualOrder: "+actualOrder+"\n"+"");
  } 
}

// test StockExchange tradesToString

@SuppressWarnings("unchecked")
@Test(timeout=1000) public void StockExchange_tradesToString1() {
// Example from Spec

  StockExchange E = new StockExchange();
  List<StockExchange.Order> orders = new ArrayList<StockExchange.Order>();
  orders.add(new StockExchange.Order("GOOG",(short)30000,75,StockExchange.Order.ordertype.BUY,"ETRADE","Seller"));
  orders.add(new StockExchange.Order("FB",(short)10219,100,StockExchange.Order.ordertype.SELL,"Buyer","Schwab"));
  orders.add(new StockExchange.Order("GOOG",(short)29999,25,StockExchange.Order.ordertype.SELL,"Buyer","Schwab"));
  orders.add(new StockExchange.Order("FB",(short)10221,100,StockExchange.Order.ordertype.BUY,"ETRADE","Seller"));
  orders.add(new StockExchange.Order("GOOG",(short)29950,50,StockExchange.Order.ordertype.SELL,"Buyer","Schwab"));

  E.lowestSellOrderPrice = 10219;
  E.highestBuyOrderPrice = 30000;

  E.tradeAll(orders);
  MyHashMap<String,ArrayList<StockExchange.Order>> trades = E.getTrades();

  ArrayList<StockExchange.Order> tradeList = trades.get("GOOG");

  int actualSize = tradeList.size();
  int expectedSize = 2;

  if(actualSize != expectedSize) {
       failFmt("StockExchange tradesToString:\n"+
               "expectedSize: "+expectedSize +"\n"+
               "actualSize: "+actualSize+"\n"+"");
  }

  StockExchange.Order GOOGTrade = new StockExchange.Order("GOOG",(short)30000,25,StockExchange.Order.ordertype.TRADE,"ETRADE","Schwab");
  boolean actualContains = tradeList.contains(GOOGTrade);
  boolean expectedContains = true;

  if(actualContains != expectedContains) {
       failFmt("StockExchange.Order tradesToString:\n"+
               "expectedContains: "+expectedContains +"\n"+
               "actualContains: "+actualContains+"\n"+"");
  } 

  StockExchange.Order GOOGTrade1 = new StockExchange.Order("GOOG",(short)30000,50,StockExchange.Order.ordertype.TRADE,"ETRADE","Schwab");
  boolean actualContains1 = tradeList.contains(GOOGTrade1);
  boolean expectedContains1 = true;

  if(actualContains1 != expectedContains1) {
       failFmt("StockExchange.Order tradesToString:\n"+
               "expectedContains1: "+expectedContains1 +"\n"+
               "actualContains1: "+actualContains1+"\n"+"");
  }

  tradeList = trades.get("FB");

  int actualSize1 = tradeList.size();
  int expectedSize1 = 1;

  if(actualSize1 != expectedSize1) {
       failFmt("StockExchange tradesToString:\n"+
               "expectedSize1: "+expectedSize1 +"\n"+
               "actualSize1: "+actualSize1+"\n"+"");
  }

  StockExchange.Order FBTrade = new StockExchange.Order("FB",(short)10219,100,StockExchange.Order.ordertype.TRADE,"ETRADE","Schwab");
  boolean actualContains2 = tradeList.contains(FBTrade);
  boolean expectedContains2 = true;

  if(actualContains2 != expectedContains2) {
       failFmt("StockExchange.Order tradesToString:\n"+
               "expectedContains2: "+expectedContains2 +"\n"+
               "actualContains2: "+actualContains2+"\n"+"");
  } 

  // ignore white space
  String actualString = E.tradesToString().replaceAll("\\s+","");
  String expectedString =   "Symbol:FB" + "\n"   + "FB,TRADE,10219,100,ETRADE,Schwab" + "\n"
    + "Symbol:GOOG" + "\n"  + "GOOG,TRADE,30000,25,ETRADE,Schwab" + "\n" 
    + "GOOG,TRADE,30000,50,ETRADE,Schwab" + "\n";  // last line ends with println()
  expectedString = expectedString.replaceAll("\\s+","");

  if(!actualString.equals(expectedString)) {
       failFmt("StockExchange.Order tradesToString:\n"+
               "expectedString:"+ "\n" + expectedString +"\n"+
               "actualString: "+ "\n" + actualString+"\n"+"");
  } 
}


// utility functions

  static String printArray(Object[] array) {
		StringBuilder B = new StringBuilder();
		B.append("[ ");
		for(Object o: array)
			B.append(o + " ");
		B.append("]");
		return B.toString();
  }

  public static void failFmt(String fmt, Object... args){
    fail(String.format(fmt,args));
  }

  class Foo implements Comparable<Foo> {
    int x;
    int hc;
    Foo(int value, int hashCode) {this.x=value; this.hc = hashCode;}
  	 public int hashCode() {return hc;}
    public int compareTo(Foo other) {
		return x - other.x;
    }
    public boolean equals(Object other) {
      if (this == other) return true;
      if (!(other instanceof Foo)) return false;
      Foo that = (Foo) other; 
      return this.x == that.x;
    }
    public String toString() { return new Integer(x).toString();}
  }
}
